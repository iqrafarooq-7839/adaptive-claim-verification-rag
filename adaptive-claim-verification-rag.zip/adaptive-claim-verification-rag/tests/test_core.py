import math
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.claims import extract_claims, to_hypothesis  # noqa: E402
from acv.data import build_sentence_corpus, clean_and_sample_halubench, split_dev_test  # noqa: E402
from acv.generation import REFUSAL, build_prompt, is_refusal  # noqa: E402
from acv.ir_metrics import average_precision_at_k, evaluate_run, ndcg_at_k  # noqa: E402
from acv.judge import ANSWER_LABELS, CLAIM_LABELS, parse_label  # noqa: E402
from acv.metrics import (answer_metrics, auroc, benjamini_hochberg, expected_calibration_error,  # noqa: E402
                         mcnemar_exact, prf)
from acv.retrieval import BM25Index, fuse_combmnz, fuse_linear, fuse_rrf, minmax, rerank_blend  # noqa: E402
from acv.verifier import Calibrator, build_premise, decide, key_tokens, uncertainty  # noqa: E402


# --- retrieval metrics (hand-computed) ---------------------------------------
def test_average_precision_matches_trec_definition():
    rel = {"a": 1, "b": 1, "c": 1}
    # hits at ranks 1 and 3 out of 3 relevant: (1/1 + 2/3) / 3
    assert math.isclose(average_precision_at_k(["a", "x", "b", "y"], rel, 3), (1 + 2 / 3) / 3)
    assert average_precision_at_k(["x", "y"], rel, 2) == 0.0


def test_ndcg_binary():
    rel = {"a": 1, "b": 1}
    dcg = 1 / math.log2(3)  # relevant at rank 2
    idcg = 1 + 1 / math.log2(3)
    assert math.isclose(ndcg_at_k(["x", "a", "y"], rel, 3), dcg / idcg)
    assert ndcg_at_k(["a", "b"], rel, 2) == 1.0


def test_evaluate_run_skips_queries_without_relevant_docs():
    res = evaluate_run({"q1": ["a"], "q2": ["b"]}, {"q1": {"a": 1}, "q2": {}}, [3])
    assert res["n_queries"] == 1 and res["mean"]["MAP@3"] == 1.0


# --- fusion ------------------------------------------------------------------
def test_minmax_and_linear_fusion():
    assert minmax({1: 2.0, 2: 4.0}) == {1: 0.0, 2: 1.0}
    fused = dict(fuse_linear([[(1, 10.0), (2, 5.0)], [(2, 0.9), (3, 0.1)]], [0.7, 0.3]))
    assert math.isclose(fused[1], 0.7) and math.isclose(fused[2], 0.3) and math.isclose(fused[3], 0.0)


def test_combmnz_rewards_agreement():
    fused = dict(fuse_combmnz([[(1, 3.0), (2, 2.0), (4, 1.0)], [(2, 9.0), (3, 5.0), (5, 1.0)]]))
    assert fused[2] > fused[1]  # retrieved by both lists


def test_rrf_order():
    ranked = fuse_rrf([[(1, 0), (2, 0)], [(2, 0), (1, 0)]], eps=60)
    assert {d for d, _ in ranked} == {1, 2} and math.isclose(ranked[0][1], ranked[1][1])


def test_rerank_blend_uses_cross_encoder():
    texts = ["cats purr", "dogs bark", "cats and dogs"]
    out = rerank_blend("dogs", [(0, 1.0), (1, 0.5), (2, 0.2)], texts,
                       lambda q, docs: np.array([0.0, 1.0, 0.5]), pool=3, beta=0.85)
    assert out[0][0] == 1


def test_bm25_ranks_matching_document_first():
    idx = BM25Index().fit(["the cat sat", "dogs bark loudly", "a cat and a dog"])
    hits = idx.search(["barking dogs"], 2)[0]
    assert hits[0][0] == 1


# --- data --------------------------------------------------------------------
def test_sentence_corpus_dedup_and_qrels():
    ex = [{"id": "q1", "titles": ["A", "B", "C"], "sentences": [["A one.", "A two."], ["B one."], ["C one."]],
           "sf_titles": ["A", "B"], "sf_sent_ids": [1, 0]},
          {"id": "q2", "titles": ["A", "D"], "sentences": [["A one.", "A two."], ["D one.", "D two."]],
           "sf_titles": ["A", "D"], "sf_sent_ids": [0, 5]}]  # 5 is out of range and must be ignored
    ids, texts, qrels = build_sentence_corpus(ex, "supporting")
    assert texts.count("A one.") == 1 and "C one." not in texts
    assert len(qrels["q1"]) == 2 and len(qrels["q2"]) == 1


def test_halubench_cleaning_and_split():
    rows = [{"id": i, "passage": "p", "question": f"q{i % 5}", "answer": "a", "label": "FAIL" if i % 2 else "PASS",
             "source_ds": "S1" if i < 10 else "S2"} for i in range(20)]
    rows.append({"id": 99, "passage": "", "question": "x", "answer": "y", "label": "PASS", "source_ds": "S1"})
    clean = clean_and_sample_halubench(rows, per_source=None)
    assert all(r["passage"] for r in clean) and len(clean) == 5  # empty row and duplicates removed
    dev, test = split_dev_test(clean, 0.3, 1)
    assert not ({r["id"] for r in dev} & {r["id"] for r in test})


# --- generation / judge ------------------------------------------------------
def test_prompt_and_refusal():
    p = build_prompt("Who?", ["ctx one", "ctx two"])
    assert "[context 2] - ctx two" in p and REFUSAL in p
    assert is_refusal(REFUSAL) and not is_refusal("Paris is the capital.")


def test_parse_label():
    assert parse_label('{"label": "Correct", "explanation": "x"}', ANSWER_LABELS)["label"] == "Correct"
    assert parse_label("label: insufficient context", ANSWER_LABELS)["label"] == "Insufficient Context"
    assert parse_label('{"label": "maybe"}', CLAIM_LABELS)["label"] is None


# --- claims and verifier -----------------------------------------------------
def test_claim_extraction_handles_steps_and_refusals():
    out = ("Step 1: The question asks where Ada was born. Step 2: The contexts provide sufficient information. "
           "Step 3: Ada was born in Lahore in 1990. Lahore is a city in Pakistan. Final answer: Pakistan.")
    claims = extract_claims(out)
    assert "Ada was born in Lahore in 1990." in claims and "Lahore is a city in Pakistan." in claims
    assert not any("question asks" in c.lower() for c in claims)
    assert extract_claims(REFUSAL) == []
    assert extract_claims("1998") == ["1998"]
    assert to_hypothesis("1998", "When?").startswith("The answer to the question")


def test_key_tokens_numbers_and_entities():
    toks = key_tokens("Ada was born in Lahore in 1,990.")
    assert "1990" in toks and "lahore" in toks and "ada" not in toks  # first word ignored


def test_gate_and_decisions():
    p = np.array([0.95, 0.5, 0.1])
    v = np.array([0.9, 0.2, 0.9])
    assert np.allclose(uncertainty(p), [0.1, 1.0, 0.2])
    z, s, esc = decide(p, v, "adaptive", theta=0.5, tau=0.5)
    assert esc.tolist() == [False, True, False] and z.tolist() == [0, 1, 1]
    z_cheap, _, esc_c = decide(p, None, "cheap")
    assert z_cheap.tolist() == [0, 0, 1] and not esc_c.any()
    with pytest.raises(ValueError):
        decide(p, None, "adaptive", theta=0.0)


def test_premise_keeps_document_order():
    sents = ["s0", "s1", "s2", "s3"]
    assert build_premise(sents, np.array([0.1, 0.9, 0.2, 0.8]), 2) == "s1 s3"


def test_calibrator_learns_direction():
    rng = np.random.default_rng(0)
    phi = rng.random((200, 4))
    y = (phi[:, 0] + 0.1 * rng.standard_normal(200) > 0.5).astype(int)
    cal = Calibrator("logistic").fit(phi, y)
    p = cal.predict(np.array([[0.9, 0.5, 0.5, 0.5], [0.1, 0.5, 0.5, 0.5]]))
    assert p[0] > 0.7 and p[1] < 0.3


# --- metrics -----------------------------------------------------------------
def test_answer_metrics_match_base_paper_definition():
    m = answer_metrics(["Correct"] * 3 + ["Hallucinated"] + ["Insufficient Context"] * 4 + [None])
    assert m["n"] == 8 and math.isclose(m["accuracy"], 37.5) and math.isclose(m["adjusted_accuracy"], 75.0)
    # Table 5 of the base paper: Qwen-4B + Contriever 37.78 / 9.34 -> 80.18
    assert math.isclose(100 * 37.78 / (37.78 + 9.34), 80.18, abs_tol=0.01)


def test_prf_auroc_ece_mcnemar_bh():
    r = prf([1, 1, 0, 0], [1, 0, 1, 0])
    assert r["precision"] == 0.5 and r["recall"] == 0.5
    assert auroc([0, 0, 1, 1], [0.1, 0.2, 0.8, 0.9]) == 1.0
    assert expected_calibration_error([0.9, 0.9], [1, 1]) == pytest.approx(0.1)
    assert mcnemar_exact([1, 1, 0], [1, 1, 0], [1, 1, 0])["p_value"] == 1.0
    adj = benjamini_hochberg([0.01, 0.04, 0.03])
    assert adj[0] == pytest.approx(0.03) and all(a <= 1 for a in adj)
