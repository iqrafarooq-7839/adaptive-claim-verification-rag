"""Integration tests with tiny, randomly initialised models built on the spot (no downloads).

They run the real code paths (SPLADE, dense encoders, cross-encoder, NLI verifier, batched
generation, local judge, the whole retrieval pipeline and the verifier experiment) against the
installed versions of torch / transformers / sentence-transformers, so library changes show up
here and not in the middle of a long GPU session. The numbers are meaningless.
"""

import sys
from pathlib import Path

import numpy as np
import pytest

torch = pytest.importorskip("torch")
transformers = pytest.importorskip("transformers")
pytest.importorskip("tokenizers")

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.utils import load_config  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]

CORPUS = [
    "Ada Brook was born in Lahore in 1990.", "Lahore is a city in Pakistan.", "Omar Haq founded a small press in Porto.",
    "Porto is a city in Portugal.", "The press published poetry and short stories.", "Kyoto hosts a river festival.",
    "Which country is the city where Ada Brook was born in?", "The answer to the question is Pakistan.",
    "The context does not provide sufficient information to answer the question.",
    "Step 1: read the question. Step 2: the contexts are sufficient. Step 3: answer.",
    "Return exactly one JSON object with a label and an explanation: Correct, Hallucinated, Supported, Unsupported.",
]


@pytest.fixture(scope="session")
def tiny(tmp_path_factory):
    from tokenizers import BertWordPieceTokenizer
    from transformers import (BertConfig, BertForMaskedLM, BertForSequenceClassification, BertModel, GPT2Config,
                              GPT2LMHeadModel)

    try:
        from transformers import BertTokenizerFast as BertTok
    except ImportError:  # newer transformers: one tokenizer class
        from transformers import BertTokenizer as BertTok

    root = tmp_path_factory.mktemp("tiny_models")
    wp = BertWordPieceTokenizer(lowercase=True)
    wp.train_from_iterator(CORPUS * 3, vocab_size=400, min_frequency=1,
                           special_tokens=["[PAD]", "[UNK]", "[CLS]", "[SEP]", "[MASK]"])
    vocab_dir = root / "vocab"
    vocab_dir.mkdir()
    wp.save_model(str(vocab_dir))
    tok = BertTok(vocab_file=str(vocab_dir / "vocab.txt"), do_lower_case=True)
    vocab = len(tok)
    torch.manual_seed(0)
    cfg = dict(vocab_size=vocab, hidden_size=32, num_hidden_layers=1, num_attention_heads=2, intermediate_size=64,
               max_position_embeddings=128)
    paths = {}
    for name, model in {
        "mlm": BertForMaskedLM(BertConfig(**cfg)),
        "enc": BertModel(BertConfig(**cfg)),
        "ce": BertForSequenceClassification(BertConfig(**cfg, num_labels=1)),
        "nli": BertForSequenceClassification(BertConfig(
            **cfg, num_labels=3, id2label={0: "contradiction", 1: "entailment", 2: "neutral"},
            label2id={"contradiction": 0, "entailment": 1, "neutral": 2})),
        "lm": GPT2LMHeadModel(GPT2Config(vocab_size=vocab, n_positions=512, n_embd=32, n_layer=1, n_head=2,
                                         bos_token_id=tok.cls_token_id, eos_token_id=tok.sep_token_id)),
    }.items():
        d = root / name
        model.save_pretrained(str(d))
        tok.save_pretrained(str(d))
        paths[name] = str(d)
    return paths


def test_splade_and_sparse_index(tiny):
    from acv.retrieval import SparseVectorIndex, SpladeEncoder

    enc = SpladeEncoder(tiny["mlm"], device="cpu", batch_size=4, max_terms=16)
    docs = enc.encode(CORPUS)
    assert docs.shape[0] == len(CORPUS) and docs.nnz > 0 and (docs.getnnz(axis=1) <= 16).all()
    hits = SparseVectorIndex(docs).search(enc.encode(["Where was Ada Brook born?", "Porto"]), k=3)
    assert len(hits) == 2 and all(len(h) <= 3 for h in hits)
    assert all(h[i][1] >= h[i + 1][1] for h in hits for i in range(len(h) - 1))   # sorted by score


@pytest.mark.parametrize("pooling", ["mean", "st"])
def test_dense_encoder(tiny, pooling):
    pytest.importorskip("sentence_transformers")
    from acv.retrieval import DenseEncoder, DenseIndex

    enc = DenseEncoder(tiny["enc"], pooling=pooling, device="cpu", batch_size=4)
    emb = enc.encode(CORPUS)
    assert emb.shape[0] == len(CORPUS) and np.allclose(np.linalg.norm(emb, axis=1), 1.0, atol=1e-4)
    hits = DenseIndex(emb, use_torch=True).search(enc.encode(CORPUS[:2]), k=3)
    assert hits[0][0][0] == 0 and hits[1][0][0] == 1            # each sentence retrieves itself first


def test_cross_encoder_and_nli(tiny):
    pytest.importorskip("sentence_transformers")
    from acv.retrieval import CrossEncoderReranker
    from acv.verifier import NLIVerifier

    scores = CrossEncoderReranker(tiny["ce"], device="cpu").score("Where was Ada born?", CORPUS[:4])
    assert scores.shape == (4,) and np.isfinite(scores).all()
    nli = NLIVerifier(tiny["nli"], device="cpu", batch_size=2)
    assert nli.entail_idx == 1
    long_premise = " ".join(CORPUS * 20)                         # longer than the model's input limit
    p = nli.entail_prob([CORPUS[0], long_premise, ""], ["Ada was born in Lahore.", "Porto is in Portugal.", "x"])
    assert p.shape == (3,) and ((p >= 0) & (p <= 1)).all() and nli.calls == 3


def test_batched_generation_matches_single(tiny):
    from acv.generation import HFGenerator, build_prompt, resolve_dtype

    assert resolve_dtype("float32") == torch.float32 and resolve_dtype("fp16") == torch.float16
    assert resolve_dtype("auto") in (torch.float32, torch.float16, torch.bfloat16)
    prompts = [build_prompt("Where was Ada Brook born?", CORPUS[:k]) for k in (1, 3, 5)] + ["Answer:"]
    one = HFGenerator(tiny["lm"], max_new_tokens=8, dtype="float32", batch_size=1)
    many = HFGenerator(tiny["lm"], max_new_tokens=8, dtype="float32", batch_size=3)
    assert one.tok.padding_side == "left" and one.tok.pad_token_id is not None
    a, b = one.generate_many(prompts), many.generate_many(prompts)
    assert len(a) == len(b) == 4 and all(isinstance(t, str) for t in b)
    assert a == b                                                # left padding must not change greedy outputs
    assert one.generate(prompts[0]) == a[0]


def test_local_judge_runs_without_chat_template(tiny, tmp_path):
    from acv.generation import load_causal_lm
    from acv.judge import HFJudge

    tok, lm, _ = load_causal_lm(tiny["lm"], dtype="float32")
    j = HFJudge("tiny/judge", max_new_tokens=6, cache_dir=str(tmp_path), batch_size=2, tok=tok, lm=lm)
    out = j.judge_answers([("q1", "a", "b"), ("q2", "a", "b"), ("q1", "a", "b")])
    assert len(out) == 3 and all(o["label"] in (None, "Correct", "Hallucinated", "Insufficient Context") for o in out)
    assert len(j.cache) == 2                                     # the repeated item was judged once
    assert len(j.judge_claims([("Ada was born in Lahore.", "Ada was born in Lahore.")])) == 1


def test_full_retrieval_pipeline_with_real_backends(tiny, tmp_path):
    pytest.importorskip("sentence_transformers")
    from acv.pipeline import HYBRID, SINGLE, default_backends, run_methods

    cfg = load_config(ROOT / "configs" / "free_gpu.yaml")
    cfg["retrieval"]["models"] = {"splade": tiny["mlm"], "mpnet": tiny["enc"], "mpnet_qa": tiny["enc"],
                                  "contriever": tiny["enc"], "reranker": tiny["ce"]}
    cfg["retrieval"].update(candidate_depth=6, batch_size=4, splade_max_terms=16)
    cfg["retrieval"]["hybrid"]["rerank_pool"] = 5
    qids = ["q0", "q1", "q2"]
    queries = ["Where was Ada Brook born?", "Which country is Porto in?", "What did the press publish?"]
    qrels = {"q0": {"d0": 1}, "q1": {"d3": 1}, "q2": {"d4": 1}}
    res = run_methods(CORPUS, qids, queries, qrels, list(SINGLE) + list(HYBRID), cfg, default_backends(cfg),
                      log=lambda s: None, cache_dir=tmp_path / "cache")
    assert set(res) == set(SINGLE) | set(HYBRID)
    for r in res.values():
        assert all(len(r["run"][q]) <= 10 for q in qids) and 0 <= r["eval"]["mean"]["MAP@10"] <= 1
    assert "d0" in res["bm25"]["run"]["q0"][:2]                 # the lexical retriever finds the obvious match
    assert len(list((tmp_path / "cache").glob("*.pkl"))) == 6


def test_verifier_experiment_with_real_model_classes(tiny):
    st = pytest.importorskip("sentence_transformers")
    from acv.experiments import run_verifier_experiment
    from acv.verifier import NLIVerifier

    emb = st.SentenceTransformer(tiny["enc"], device="cpu")

    def embed_fn(texts):
        return emb.encode(list(texts), batch_size=8, normalize_embeddings=True, convert_to_numpy=True,
                          show_progress_bar=False)

    rows = []
    for i in range(48):
        ok = i % 2 == 0
        rows.append({"id": f"r{i}", "source": "DROP" if i % 4 < 2 else "halueval",
                     "passage": "Ada Brook was born in Lahore in 1990. Lahore is a city in Pakistan. Porto is a city in Portugal.",
                     "question": "Where was Ada Brook born?",
                     "answer": ["Lahore", "Ada Brook was born in Lahore in 1990."][i % 3 == 0] if ok
                     else ["Kyoto", "Omar Haq was born in Kyoto in 1890."][i % 3 == 0],
                     "unsupported": 0 if ok else 1})
    cfg = load_config(ROOT / "configs" / "free_gpu.yaml")
    artifacts = {}
    res = run_verifier_experiment(rows[:16], rows[16:], embed_fn, NLIVerifier(tiny["nli"], device="cpu"), cfg,
                                  log=lambda s: None, artifacts=artifacts)
    for k in ("B1_cheap", "B2_uniform_nli", "B3_adaptive"):
        assert 0 <= res[k]["f1"] <= 1 and 0 <= res[k]["call_rate"] <= 1
    assert res["B1_cheap"]["call_rate"] == 0 and res["B2_uniform_nli"]["call_rate"] == 1
    assert set(res["ablations"]) >= {"no_calibration_raw_similarity", "single_sentence_premise"}
    assert {"calibrator", "tau", "theta"} <= set(artifacts)
    import json

    json.dumps(res)                                              # results must be serialisable
