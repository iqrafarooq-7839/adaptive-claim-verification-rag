"""Tests for the pieces added for free-GPU runs: config inheritance, local datasets, caching, judges."""

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.claims import extract_claims, to_hypothesis  # noqa: E402
from acv.judge import AnthropicJudge, HFJudge, _CachedJudge, make_judge  # noqa: E402
from acv.pipeline import HYBRID, SINGLE, run_methods  # noqa: E402
from acv.retrieval import BM25Index, DenseIndex, LuceneEnglishAnalyzer  # noqa: E402
from acv.toy import HashingEmbedder, lexical_rerank_scores  # noqa: E402
from acv.utils import deep_merge, load_config, retrieval_run_dir  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


# --- configuration -----------------------------------------------------------
def test_free_gpu_config_extends_default():
    base = load_config(ROOT / "configs" / "default.yaml")
    free = load_config(ROOT / "configs" / "free_gpu.yaml")
    assert "extends" not in free
    assert free["hotpotqa"]["max_queries"] == 10000 and base["hotpotqa"]["max_queries"] is None
    assert free["retrieval"]["models"] == base["retrieval"]["models"]          # inherited
    assert free["generation"]["per_model"]["gemma2_2b"]["dtype"] == "float32"   # overridden
    assert free["judge"]["backend"] == "hf" and free["judge"]["model"] == base["judge"]["model"]


def test_deep_merge_and_run_dir():
    assert deep_merge({"a": {"b": 1, "c": 2}, "d": 3}, {"a": {"b": 9}}) == {"a": {"b": 9, "c": 2}, "d": 3}
    cfg = load_config(ROOT / "configs" / "free_gpu.yaml")
    assert retrieval_run_dir(cfg).as_posix().endswith("retrieval/train_q10000")
    cfg["hotpotqa"]["max_queries"] = None
    assert retrieval_run_dir(cfg, "validation").as_posix().endswith("retrieval/validation")


def test_generation_settings_per_model():
    from acv.generation import model_settings

    gc = load_config(ROOT / "configs" / "free_gpu.yaml")["generation"]
    assert model_settings(gc, "llama31_8b") == {"dtype": "float16", "batch_size": 4, "load_in_4bit": False}
    assert model_settings({"batch_size": 2}, "anything") == {"dtype": "auto", "batch_size": 2, "load_in_4bit": False}


# --- local datasets (written in the same layout and schema as the Hugging Face files) ------
def _write_hf_like_parquet(data_dir: Path):
    pa = pytest.importorskip("pyarrow")
    import pyarrow.parquet as pq

    ctx_t = pa.struct([("title", pa.list_(pa.string())), ("sentences", pa.list_(pa.list_(pa.string())))])
    sf_t = pa.struct([("title", pa.list_(pa.string())), ("sent_id", pa.list_(pa.int32()))])
    rows = [{"id": "5a7a", "question": "Which magazine was started first?", "answer": "Arthur's Magazine",
             "type": "comparison", "level": "medium",
             "supporting_facts": {"title": ["Arthur's Magazine", "First for Women"], "sent_id": [0, 0]},
             "context": {"title": ["Radio City", "Arthur's Magazine", "First for Women"],
                         "sentences": [["Radio City is a station.", " It plays songs."],
                                       ["Arthur's Magazine (1844-1846) was a periodical.", " Edited by T.S. Arthur."],
                                       ["First for Women is a magazine.", " It started in 1989."]]}}]
    schema = pa.schema([("id", pa.string()), ("question", pa.string()), ("answer", pa.string()), ("type", pa.string()),
                        ("level", pa.string()), ("supporting_facts", sf_t), ("context", ctx_t)])
    d = data_dir / "hotpot_qa" / "distractor"
    d.mkdir(parents=True)
    pq.write_table(pa.Table.from_pylist(rows, schema=schema), d / "train-00000-of-00001.parquet")
    hb = [{"id": str(i), "passage": f"Passage {i}. Ada was born in 19{i:02d}.", "question": "When was Ada born?",
           "answer": f"19{i:02d}", "label": "PASS" if i % 2 else "FAIL", "source_ds": "DROP" if i < 6 else "halueval"}
          for i in range(12)]
    h = data_dir / "halubench" / "data"
    h.mkdir(parents=True)
    pq.write_table(pa.Table.from_pylist(hb), h / "test-00000-of-00001.parquet")


def test_loaders_read_local_parquet(tmp_path):
    pytest.importorskip("datasets")
    from acv.data import build_sentence_corpus, load_halubench, load_hotpotqa

    _write_hf_like_parquet(tmp_path)
    ex = load_hotpotqa(split="train", data_dir=str(tmp_path), keep_paragraphs="supporting")
    assert len(ex) == 1 and ex[0]["titles"] == ["Arthur's Magazine", "First for Women"]   # distractor dropped
    assert ex[0]["sf_sent_ids"] == [0, 0]
    _, texts, qrels = build_sentence_corpus(ex, "supporting")
    assert len(texts) == 4 and len(qrels["5a7a"]) == 2
    full = load_hotpotqa(split="train", data_dir=str(tmp_path), keep_paragraphs="all")
    assert len(full[0]["titles"]) == 3
    rows = load_halubench(per_source=4, data_dir=str(tmp_path))
    assert len(rows) == 8 and {r["source"] for r in rows} == {"DROP", "halueval"}
    assert {r["unsupported"] for r in rows} == {0, 1}


def test_hotpot_example_accepts_list_of_dicts():
    from acv.data import hotpot_example_from_hf

    ex = {"id": "q", "question": "?", "answer": "a",
          "context": [{"title": "A", "sentences": ["s1", "s2"]}, {"title": "B", "sentences": ["s3"]}],
          "supporting_facts": [{"title": "B", "sent_id": 0}]}
    out = hotpot_example_from_hf(ex, "supporting")
    assert out["titles"] == ["B"] and out["sentences"] == [["s3"]] and out["sf_sent_ids"] == [0]


# --- retrieval ---------------------------------------------------------------
def test_lucene_analyzer_stems_and_removes_stop_words():
    toks = LuceneEnglishAnalyzer()("The magazines were started in Philadelphia's centre")
    assert "the" not in toks and "in" not in toks
    assert "magazin" in toks and "start" in toks and "philadelphia" in toks


def test_pipeline_cache_resumes(tmp_path):
    docs = [f"Person {i} was born in city {i}." for i in range(30)] + [f"City {i} is in country {i % 5}." for i in range(30)]
    qids = [f"q{i}" for i in range(10)]
    queries = [f"Where was person {i} born?" for i in range(10)]
    qrels = {f"q{i}": {f"d{i}": 1} for i in range(10)}
    cfg = load_config(ROOT / "configs" / "default.yaml")
    cfg["retrieval"]["candidate_depth"] = 10
    calls = {"n": 0}
    emb = HashingEmbedder()

    def dense(doc_texts, qs, depth):
        calls["n"] += 1
        return DenseIndex(emb(doc_texts), use_torch=False).search(emb(qs), depth)

    def bm25(doc_texts, qs, depth):
        calls["n"] += 1
        return BM25Index().fit(doc_texts).search(qs, depth)

    backends = {"bm25": bm25, "splade": bm25, "mpnet": dense, "mpnet_qa": dense, "contriever": dense,
                "reranker": lambda: lexical_rerank_scores}
    methods = list(SINGLE) + list(HYBRID)
    steps = []
    r1 = run_methods(docs, qids, queries, qrels, methods, cfg, backends, log=lambda s: None,
                     cache_dir=tmp_path / "cache", on_step=lambda: steps.append(1))
    assert calls["n"] == 5 and len(steps) == 6            # five retrievers + reranking
    r2 = run_methods(docs, qids, queries, qrels, methods, cfg, backends, log=lambda s: None, cache_dir=tmp_path / "cache")
    assert calls["n"] == 5                                 # nothing recomputed
    assert r1["hybrid_li_rerank"]["run"] == r2["hybrid_li_rerank"]["run"]
    assert r1["bm25"]["eval"]["mean"]["MAP@10"] > 0.5
    # a different query set must not reuse the cache
    run_methods(docs, qids[:5], queries[:5], qrels, ["bm25"], cfg, backends, log=lambda s: None, cache_dir=tmp_path / "cache")
    assert calls["n"] == 6


# --- claims on real answer shapes seen in HaluBench ----------------------------
def test_answer_spans_become_propositions():
    q = "How was the survey designed?"
    assert extract_claims("in accordance with WHO recommendations") == ["in accordance with WHO recommendations"]
    assert to_hypothesis("in accordance with WHO recommendations", q).startswith("The answer to the question")
    assert to_hypothesis("['Rams', 'second', 'Marc Bulger', 'Kevin Curtis']", q).startswith("The answer to")
    assert extract_claims("2, 2") == ["2, 2"]
    full = "GP ablation did not prove to be beneficial for postoperative stable NSR."
    assert to_hypothesis(full, q) == full
    assert extract_claims("No. " + full) == [full]


# --- judges --------------------------------------------------------------------
class _Block:
    type = "text"

    def __init__(self, text):
        self.text = text


class _Resp:
    stop_reason = "end_turn"

    def __init__(self, text):
        self.content = [_Block(text)]


class _FakeMessages:
    def __init__(self, behaviour):
        self.behaviour, self.calls = behaviour, 0

    def create(self, **kw):
        self.calls += 1
        return self.behaviour(kw)


class _FakeClient:
    def __init__(self, behaviour):
        self.messages = _FakeMessages(behaviour)


def test_anthropic_judge_caches_and_parses(tmp_path):
    client = _FakeClient(lambda kw: _Resp('{"label": "Hallucinated", "explanation": "differs"}'))
    j = AnthropicJudge("m", cache_dir=str(tmp_path), client=client)
    assert j.judge_answer("q", "a", "b")["label"] == "Hallucinated"
    assert j.judge_answer("q", "a", "b")["label"] == "Hallucinated" and client.messages.calls == 1
    j2 = AnthropicJudge("m", cache_dir=str(tmp_path), client=client)      # cache survives a new session
    assert j2.judge_answers([("q", "a", "b"), ("q2", "a", "b")])[0]["label"] == "Hallucinated"
    assert client.messages.calls == 2


def test_anthropic_judge_fails_fast_on_bad_key_or_retired_model(tmp_path):
    class AuthError(Exception):
        status_code = 401

    def boom(kw):
        raise AuthError("invalid x-api-key")

    client = _FakeClient(boom)
    j = AnthropicJudge("m", cache_dir=str(tmp_path), client=client)
    with pytest.raises(RuntimeError, match="will not succeed on retry"):
        j.judge_answer("q", "a", "b")
    assert client.messages.calls == 1          # no retries, no waiting


def test_anthropic_judge_retries_rate_limits(tmp_path, monkeypatch):
    import acv.judge as jm

    monkeypatch.setattr(jm.time, "sleep", lambda s: None)

    class RateLimit(Exception):
        status_code = 429

    state = {"n": 0}

    def flaky(kw):
        state["n"] += 1
        if state["n"] < 3:
            raise RateLimit("slow down")
        return _Resp('{"label": "Correct", "explanation": "ok"}')

    j = AnthropicJudge("m", cache_dir=str(tmp_path), client=_FakeClient(flaky))
    assert j.judge_answer("q", "a", "b")["label"] == "Correct" and state["n"] == 3


def test_cached_judge_batches_and_dedups(tmp_path):
    class Echo(_CachedJudge):
        def __init__(self, cache_dir):
            super().__init__("echo/model", cache_dir)
            self.seen = []

        def _complete(self, pairs):
            self.seen.append(len(pairs))
            return [{"text": '{"label": "Supported"}' if "sky is blue" in u else '{"label": "Unsupported"}',
                     "stop_reason": "end_turn"} for _, u in pairs]

    j = Echo(str(tmp_path))
    out = j.judge_claims([("The sky is blue.", "c1"), ("Grass is green.", "c2"), ("The sky is blue.", "c1")])
    assert [o["label"] for o in out] == ["Supported", "Unsupported", "Supported"] and j.seen == [2]
    assert (tmp_path / "echo_model.jsonl").exists()


def test_make_judge_rejects_unknown_backend():
    cfg = load_config(ROOT / "configs" / "default.yaml")
    with pytest.raises(ValueError):
        make_judge(cfg, backend="nope")
    assert HFJudge.name == "hf"


def test_sync_is_off_by_default(monkeypatch, tmp_path):
    from acv import sync

    monkeypatch.delenv("ACV_SYNC", raising=False)
    assert sync.enabled() is False
    assert sync.push({"paths": {"out_dir": str(tmp_path)}}) is None and sync.pull({"paths": {"out_dir": str(tmp_path)}}) is None


def test_uncertainty_gate_extremes():
    from acv.verifier import decide

    p = np.array([0.9, 0.55, 0.2])
    v = np.array([0.1, 0.1, 0.9])
    assert not decide(p, v, "adaptive", theta=1.0)[2].any()          # theta = 1: cheap only
    assert decide(p, v, "adaptive", theta=0.0)[2].all()              # theta = 0: every uncertain claim verified


def test_prefix_stripping_keeps_words_that_start_with_so():
    out = extract_claims("Some may be entitled to overtime under certain conditions. So, Lahore is in Pakistan. "
                         "Therefore the answer is Pakistan.")
    assert out[0].startswith("Some may be entitled") and "Lahore is in Pakistan." in out
    assert "the answer is Pakistan." in out
