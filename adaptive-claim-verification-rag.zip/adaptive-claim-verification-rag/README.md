# Detecting Unsupported Claims in Multi-Hop RAG with Calibrated Cheap Scoring and Selective NLI Verification

Code for the paper *Detecting Unsupported Claims in Multi-Hop RAG with Calibrated Cheap Scoring and
Selective NLI Verification* (Iqra Farooq, FAST-NUCES, Islamabad).

The repository does two things:

1. **Reproduces the base paper**: C. S. Mala, G. Gezici and F. Giannotti, "Disentangling faithfulness
   hallucinations in retrieval-augmented generation: A systematic benchmark and analysis," *Machine
   Learning*, vol. 115, no. 8, art. 187, 2026, doi:10.1007/s10994-026-07121-y
   (original code: https://github.com/chandanasreemala/Beyond_Retrieval).
   Sparse, dense and hybrid retrieval on HotpotQA (Tables 1 and 3), answer generation with three
   open-weight LLMs and LLM-as-a-judge evaluation (Table 5).
2. **Implements and evaluates the proposed method**: an adaptive claim-level verifier that extracts
   claims from an answer, scores them with a calibrated cheap evidence-support model, and sends only
   uncertain claims to a natural-language-inference (NLI) verifier with a multi-hop premise.

## Method in one paragraph

For an answer `a` with retrieved context `D`, claims `C = E(a)` are extracted (reasoning steps
included). Each claim gets cheap features `phi = [s_max, s_top3, lex_cov, key_cov]` (embedding
similarity to the best and top-3 context sentences, content-word coverage, and coverage of
numbers and named entities), and a logistic calibrator gives `p = P(supported | phi)`. The gate
computes `u = 1 - |2p - 1|`; only claims with `u > theta` are verified by the NLI model on a premise
made of the top-`m` context sentences in document order. A claim is unsupported if
`p < 0.5` (not escalated) or `v < tau` (escalated). `tau` and `theta` are chosen on a dev split by
minimising `(1 - F1) + lambda * call_rate`.

## Repository layout

```
configs/default.yaml        all settings (exact base-paper protocol)
configs/free_gpu.yaml       overrides for free T4 GPUs (Kaggle / Colab)
src/acv/
  data.py                   HotpotQA, HaluBench, sentence-level corpus and qrels
  retrieval.py              BM25, SPLADE, dense encoders, LI / CombMNZ / RRF fusion, reranking
  pipeline.py               runs the retrieval methods and evaluates them
  ir_metrics.py             MAP@k and NDCG@k (trec_eval definitions)
  generation.py             chain-of-thought prompt and greedy generation
  judge.py                  LLM-as-a-judge: Claude API or local open-weight model, cached
  sync.py                   optional backup of outputs/ to a private HF dataset
  claims.py                 claim extraction
  verifier.py               proposed adaptive verifier (cheap scorer, calibrator, gate, NLI)
  experiments.py            experiment E2 protocol (selection, baselines, ablations, timing)
  metrics.py                answer metrics, P/R/F1, AUROC, ECE, bootstrap, McNemar, Wilcoxon, BH
  plotting.py               black-and-white figures in Times New Roman
  reported.py               numbers from the base paper's Tables 1, 3 and 5
  toy.py                    toy models for tests only
scripts/
  00_download_data.py       download HotpotQA and HaluBench into data/
  check_setup.py            check GPU, libraries, model access and keys
  sync_outputs.py           save/restore outputs/ in a private HF dataset
  01_retrieval.py           Tables 1 and 3 (reproduction)
  02_generate.py            answers for 1,200 HotpotQA questions (reproduction)
  03_judge.py               judge labels and Table 5 (reproduction)
  export_for_annotation.py  human check of the judge on a random subset
  04_verify_halubench.py    E2: proposed verifier vs baselines on HaluBench
  05_verify_hotpotqa.py     E3: proposed verifier on the reproduced HotpotQA answers
  06_tables_figures.py      Markdown tables and PDF/PNG figures for the paper
  smoke_test.py             end-to-end check with toy models (no downloads)
tests/                      43 tests (unit + tiny-model integration, CPU only)
notebooks/run_on_kaggle.ipynb free Kaggle GPU runner (stages A, B, C)
notebooks/run_on_colab.ipynb  same for Colab
```

## Running on a free GPU (recommended: Kaggle)

Everything runs on free hardware. Kaggle gives two T4 GPUs (16 GB each), 12-hour sessions, about 30 GPU
hours a week, and keeps running after you close the browser; Colab's free T4 also works but stops when
the tab closes.

1. Open `notebooks/run_on_kaggle.ipynb` on Kaggle (*Create → New Notebook → File → Import Notebook*, paste
   the GitHub link of the notebook).
2. *Session options*: Accelerator **GPU T4 x2**, Internet **On**.
3. *Add-ons → Secrets*: `HF_TOKEN` (Hugging Face token with **write** permission). Accept the licences of
   `google/gemma-2-2b-it` and `meta-llama/Llama-3.1-8B-Instruct` on huggingface.co.
4. Set `STAGE = "A"` and click *Save Version → Save & Run All*. Repeat with `"B"`, then `"C"`.

| Stage | Work | Time on T4 x2 |
|---|---|---|
| A | datasets, proposed verifier on HaluBench, retrieval reproduction | 2–3 h |
| B | Qwen3-4B and Gemma-2-2B answers (both retrievers) | 2–4 h |
| C | Llama-3.1-8B answers, judge, verifier on HotpotQA, tables | 3–5 h |

With `HF_TOKEN` set, results are copied to a private dataset `<your-hf-name>/acv-outputs` after every step,
so an interrupted session simply resumes. Total: about 8–12 GPU hours, under one week of Kaggle quota.

`configs/free_gpu.yaml` holds the free-GPU settings and lists every difference from the exact protocol
(retrieval scored on 10,000 sampled questions against the full corpus, batched 16-bit generation, local
open-weight judge `Qwen/Qwen2.5-7B-Instruct` unless `--backend anthropic`). State them in the paper.

## Setup (own machine)

```bash
git clone https://github.com/iqrafarooq-7839/adaptive-claim-verification-rag.git
cd adaptive-claim-verification-rag
pip install -r requirements.txt && pip install -e . --no-deps
pytest -q                                            # 43 tests, CPU, no downloads
python scripts/check_setup.py --config configs/free_gpu.yaml
```

## Running the experiments

```bash
CFG="--config configs/free_gpu.yaml"       # or configs/default.yaml for the exact protocol (24 GB+ GPU)
python scripts/00_download_data.py $CFG    # HotpotQA (360 MB) + HaluBench (7.5 MB) into data/
python scripts/04_verify_halubench.py $CFG # proposed method, E2 (no API key, ~15 min)
python scripts/01_retrieval.py $CFG        # Tables 1 and 3 of the base paper
for m in qwen3_4b gemma2_2b llama31_8b; do python scripts/02_generate.py $CFG --model $m; done
python scripts/03_judge.py $CFG            # --backend anthropic for the Claude judge
python scripts/05_verify_hotpotqa.py $CFG --claim-judge-n 100
python scripts/06_tables_figures.py $CFG
```

Every step caches its finished work and resumes after an interruption.

## Where each result goes in the paper

| Paper section | Produced by |
|---|---|
| 4.3 Reproduced retrieval (Tables 1 and 3 of the base paper) | `01_retrieval.py` |
| 4.3 Reproduced end-to-end results (Table 5 of the base paper) | `02_generate.py`, `03_judge.py` |
| 4.4 Detection of unsupported answers, cost, significance | `04_verify_halubench.py` |
| 4.4 Transfer to reproduced HotpotQA answers (RQ1) | `05_verify_hotpotqa.py` |
| 4.5 Ablations, theta sweep, calibration, per-source results | `04_verify_halubench.py` |
| Figures | `06_tables_figures.py` |

## Deviations from the base implementation

- BM25 is implemented with a sparse matrix (Lucene idf, k1 = 0.9, b = 0.4, the Pyserini defaults) and a
  Lucene-style English analyzer (stop words + Porter stemming) instead of calling Pyserini, so no Java is needed.
- SPLADE document vectors keep at most 256 terms per sentence (rarely binding for sentences).
- The LLM judge defaults to `claude-sonnet-4-5-20250929`, the judge used by the base paper. This model
  retires on 30 November 2026; after that run `03_judge.py --model-id claude-sonnet-5-5` and report the change.
- Free-GPU runs (`configs/free_gpu.yaml`): retrieval metrics on a random 10,000-question sample searched
  against the full corpus (reported with 95% confidence intervals); generation in batches of 4–8 in float16
  (Gemma in float32); a local open-weight judge. State whichever of these you use.
- `--max-questions` (smaller corpus) and 4-bit loading also change the numbers; state them if used.

## Citation

If you use this code, cite the paper above and the base paper by Mala et al. (2026).

## License

MIT
