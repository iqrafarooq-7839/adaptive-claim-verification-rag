# Adaptive Claim-Level Evidence Verification for Multi-Hop RAG

Code for the paper *Adaptive Claim-Level Evidence Verification for Reducing Unsupported Claims in
Multi-Hop Retrieval-Augmented Generation* (Umair Farooq, Air University, Islamabad).

The repository does two things:

1. **Reproduces the base paper**: C. S. Mala, G. Gezici and F. Giannotti, "Disentangling faithfulness
   hallucinations in retrieval-augmented generation: A systematic benchmark and analysis," *Machine
   Learning*, vol. 115, no. 8, art. 187, 2026, doi:10.1007/s10994-026-07121-y
   (original code: https://github.com/chandanasreemala/Beyond_Retrieval).
   Sparse, dense and hybrid retrieval on HotpotQA (Tables 1 and 3), answer generation with three
   open-weight LLMs and LLM-as-a-judge evaluation (Table 5).
2. **Implements and evaluates the proposed method**: an adaptive claim-level verifier that extracts
   claims from an answer, scores them with a calibrated cheap evidence-support model, and sends only
   uncertain claims to a natural-language-inference (NLI) verifier with a multi-hop premise.

## Method in one paragraph

For an answer `a` with retrieved context `D`, claims `C = E(a)` are extracted (reasoning steps
included). Each claim gets cheap features `phi = [s_max, s_top3, lex_cov, key_cov]` (embedding
similarity to the best and top-3 context sentences, content-word coverage, and coverage of
numbers and named entities), and a logistic calibrator gives `p = P(supported | phi)`. The gate
computes `u = 1 - |2p - 1|`; only claims with `u > theta` are verified by the NLI model on a premise
made of the top-`m` context sentences in document order. A claim is unsupported if
`p < 0.5` (not escalated) or `v < tau` (escalated). `tau` and `theta` are chosen on a dev split by
minimising `(1 - F1) + lambda * call_rate`.

## Repository layout

```
configs/default.yaml        all settings (models, weights, thresholds, seeds)
src/acv/
  data.py                   HotpotQA, HaluBench, sentence-level corpus and qrels
  retrieval.py              BM25, SPLADE, dense encoders, LI / CombMNZ / RRF fusion, reranking
  pipeline.py               runs the retrieval methods and evaluates them
  ir_metrics.py             MAP@k and NDCG@k (trec_eval definitions)
  generation.py             chain-of-thought prompt and greedy generation
  judge.py                  LLM-as-a-judge (Anthropic API) with on-disk cache
  claims.py                 claim extraction
  verifier.py               proposed adaptive verifier (cheap scorer, calibrator, gate, NLI)
  experiments.py            experiment E2 protocol (selection, baselines, ablations, timing)
  metrics.py                answer metrics, P/R/F1, AUROC, ECE, bootstrap, McNemar, Wilcoxon, BH
  plotting.py               black-and-white figures in Times New Roman
  reported.py               numbers from the base paper's Tables 1, 3 and 5
  toy.py                    toy models for tests only
scripts/
  01_retrieval.py           Tables 1 and 3 (reproduction)
  02_generate.py            answers for 1,200 HotpotQA questions (reproduction)
  03_judge.py               judge labels and Table 5 (reproduction)
  export_for_annotation.py  human check of the judge on a random subset
  04_verify_halubench.py    E2: proposed verifier vs baselines on HaluBench
  05_verify_hotpotqa.py     E3: proposed verifier on the reproduced HotpotQA answers
  06_tables_figures.py      Markdown tables and PDF/PNG figures for the paper
  smoke_test.py             end-to-end check with toy models (no downloads)
tests/test_core.py          unit tests
notebooks/run_on_colab.ipynb  the full pipeline on a Colab GPU
```

## Setup

```bash
git clone https://github.com/umair802/adaptive-claim-verification-rag.git
cd adaptive-claim-verification-rag
pip install -r requirements.txt
pip install -e .
pytest -q                      # unit tests
python scripts/smoke_test.py   # end-to-end check, CPU, no downloads
```

You also need:
- a GPU for the full runs (the 8B model needs about 17 GB in bf16; on a 16 GB GPU set
  `generation.load_in_4bit: true` and report it as a deviation);
- a Hugging Face token with access to `meta-llama/Llama-3.1-8B-Instruct` (`huggingface-cli login`);
- an Anthropic API key for the judge (`export ANTHROPIC_API_KEY=...`).

## Running the experiments

```bash
# Reproduction of the base paper
python scripts/01_retrieval.py --split train                    # Tables 1 and 3 (about 90k queries)
python scripts/01_retrieval.py --split train --max-questions 5000   # faster option (report it)
python scripts/01_retrieval.py --split validation --methods contriever hybrid_li_rerank
for m in gemma2_2b qwen3_4b llama31_8b; do
  for r in contriever hybrid_li_rerank; do python scripts/02_generate.py --model $m --retriever $r; done
done
python scripts/03_judge.py
python scripts/export_for_annotation.py export --n 120   # then fill human_agrees and run "score"

# Proposed method
python scripts/04_verify_halubench.py                      # E2
python scripts/05_verify_hotpotqa.py --claim-judge-n 300   # E3

# Tables and figures
python scripts/06_tables_figures.py
```

All outputs go to `outputs/`: `retrieval/<split>/metrics.csv`, `tables/table5_reproduction.csv`,
`verifier/halubench_results.json`, `verifier/hotpotqa_results.json`, `tables/paper_tables.md`
and `figures/*.pdf|png`.

## Where each result goes in the paper

| Paper section | Produced by |
|---|---|
| 4.3 Reproduced retrieval (Tables 1 and 3 of the base paper) | `01_retrieval.py` |
| 4.3 Reproduced end-to-end results (Table 5 of the base paper) | `02_generate.py`, `03_judge.py` |
| 4.4 Detection of unsupported answers, cost, significance | `04_verify_halubench.py` |
| 4.4 Transfer to reproduced HotpotQA answers (RQ1) | `05_verify_hotpotqa.py` |
| 4.5 Ablations, theta sweep, calibration, per-source results | `04_verify_halubench.py` |
| Figures | `06_tables_figures.py` |

## Deviations from the base implementation

- BM25 is implemented with a sparse matrix (Lucene idf, k1 = 0.9, b = 0.4, the Pyserini defaults)
  instead of calling Pyserini, so no Java installation is needed.
- SPLADE document vectors keep at most 256 terms per sentence (rarely binding for sentences).
- The LLM judge defaults to `claude-sonnet-4-5-20250929`, the judge used by the base paper. This model
  retires on 30 November 2026; after that run `03_judge.py --model-id claude-sonnet-5-5` and report the change.
- If you use `--max-questions` or 4-bit loading, state it in the paper; both change the numbers.

## Citation

If you use this code, cite the paper above and the base paper by Mala et al. (2026).

## License

MIT
