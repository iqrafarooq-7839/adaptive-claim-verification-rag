# Running the HotpotQA end-to-end experiment (E3) on your own GPU

1. **Get the two Kaggle outputs** (Kaggle → notebook → Output → "Download notebook output"):
   * HotpotQA run `notebookf1bed88cf9` → `hotpot_s1_results.zip` (or the whole output folder)
   * HaluBench run `notebooka9cf410887` → `halubench_v2_results.zip` (contains `v2_artifacts.pkl`)
2. **Install** (Python 3.10+, CUDA GPU with ≥ 8 GB):
   ```bash
   pip install torch --index-url https://download.pytorch.org/whl/cu121   # if torch is not installed yet
   pip install -r requirements.txt
   pip install -e . --no-deps
   ```
3. **Run** (about 2–3 h on one T4-class GPU; Windows: same commands in a terminal):
   ```bash
   python scripts/run_e3_local.py --s1 path/to/hotpot_s1_results.zip --s3 path/to/halubench_v2_results.zip
   ```
   Out of GPU memory? add `--judge-batch 2` (or 1). The judge is Qwen2.5-7B-Instruct in 4-bit;
   without `bitsandbytes` it loads in 16-bit and needs about 16 GB.
4. **Send back** the file `e3_results.zip` that appears in the repository folder.
   It holds `hotpot_endtoend.json` and the judged answers used for Section IV-F of the paper.
