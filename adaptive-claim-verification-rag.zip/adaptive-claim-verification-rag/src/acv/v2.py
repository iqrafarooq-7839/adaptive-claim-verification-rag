"""Second-round extensions of the adaptive verifier (reviewer remarks).

* contradiction-sensitive cheap features (small NLI cross-encoder on the best sentence, negation and
  number mismatch) and a generic logistic calibrator over any feature columns;
* premise construction strategies: top-k concatenation and a two-hop evidence chain;
* escalation strategies compared at matched verifier budgets (uncertainty/confidence, random,
  low-support-first, disagreement between independent support signals, uniform);
* chunked full-passage scorers for factual-consistency models (MiniCheck, HHEM) and any NLI model;
* error attribution for wrong answer-level decisions;
* LLM-based claim decomposition (atomic facts) with an open-weight chat model.
"""

from __future__ import annotations

import json
import math
import re
import time
from typing import Callable, Dict, List, Optional, Sequence

import numpy as np

from .claims import extract_claims, to_hypothesis
from .metrics import auroc, prf
from .utils import split_sentences
from .verifier import FEATURES, Item, content_tokens, context_vocab, coverage, key_tokens, uncertainty

EXT_FEATURES = FEATURES + ("small_entail", "small_contra", "neg_mismatch", "num_missing")
NEGATIONS = {"not", "no", "never", "none", "nor", "neither", "without", "cannot", "nobody", "nothing", "n't"}
_NUM = re.compile(r"\d[\d,.]*")
_WORD = re.compile(r"[A-Za-z']+")


# ---------------------------------------------------------------------------
# NLI with all three probabilities (works for any MNLI-style cross-encoder)
# ---------------------------------------------------------------------------

class NLIProbs:
    """Cross-encoder NLI model returning P(entailment), P(contradiction), P(neutral) for pairs."""

    def __init__(self, model_name: str, device: Optional[str] = None, batch_size: int = 32, max_length: int = 512,
                 fp16: bool = False):
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        from .utils import device_name

        self.torch = torch
        self.device = device or device_name()
        self.tok = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSequenceClassification.from_pretrained(model_name).to(self.device).eval()
        if fp16 and self.device.startswith("cuda"):
            self.model = self.model.half()
        labels = {i: str(l).lower() for i, l in self.model.config.id2label.items()}
        find = lambda key: next((i for i, l in labels.items() if key in l), None)  # noqa: E731
        self.idx = {"entail": find("entail"), "contra": find("contra"), "neutral": find("neutral")}
        if self.idx["entail"] is None:
            raise ValueError(f"{model_name}: no entailment label in {labels}")
        limit = getattr(self.model.config, "max_position_embeddings", max_length) or max_length
        self.batch_size, self.max_length = batch_size, min(max_length, limit)
        self.calls, self.seconds = 0, 0.0
        self.name = model_name

    def probs(self, premises: Sequence[str], hypotheses: Sequence[str]) -> np.ndarray:
        """Array (n, 3): entailment, contradiction, neutral (0 where the model has no such label)."""
        torch = self.torch
        t0 = time.perf_counter()
        out = np.zeros((len(premises), 3))
        order = np.argsort([len(p) + len(h) for p, h in zip(premises, hypotheses)])
        with torch.no_grad():
            for s in range(0, len(order), self.batch_size):
                ids = order[s:s + self.batch_size]
                enc = self.tok([premises[i] for i in ids], [hypotheses[i] for i in ids], padding=True,
                               truncation="only_first", max_length=self.max_length, return_tensors="pt").to(self.device)
                pr = torch.softmax(self.model(**enc).logits.float(), dim=-1).cpu().numpy()
                for j, key in enumerate(("entail", "contra", "neutral")):
                    if self.idx[key] is not None:
                        out[ids, j] = pr[:, self.idx[key]]
        self.calls += len(premises)
        self.seconds += time.perf_counter() - t0
        return out

    def entail_prob(self, premises: Sequence[str], hypotheses: Sequence[str]) -> np.ndarray:
        return self.probs(premises, hypotheses)[:, 0]


# ---------------------------------------------------------------------------
# Contradiction-sensitive cheap features
# ---------------------------------------------------------------------------

def negation_mismatch(claim: str, sentence: str) -> float:
    neg = lambda t: any(w.lower() in NEGATIONS or w.lower().endswith("n't") for w in _WORD.findall(t or ""))  # noqa: E731
    return float(neg(claim) != neg(sentence))


def number_missing(claim: str, ctx_vocab: set) -> float:
    nums = [n.strip(".,").replace(",", "") for n in _NUM.findall(claim or "")]
    nums = [n for n in nums if n]
    return 0.0 if not nums else float(np.mean([n not in ctx_vocab for n in nums]))


def add_extended_features(items: Sequence[Item], small_nli: Optional[NLIProbs]) -> None:
    """Store it.meta['phi_ext'] = [4 base features, small-NLI entail, small-NLI contra, negation mismatch,
    number missing]. The small NLI model reads only the single most similar sentence, so it stays cheap."""
    prem, hyp, owner = [], [], []
    for k, it in enumerate(items):
        if not it.claims:
            it.meta["phi_ext"] = np.zeros((0, len(EXT_FEATURES)))
            continue
        best = [it.ctx_sents[int(np.argmax(it.sims[i]))] if it.sims.shape[1] else "" for i in range(len(it.claims))]
        it.meta["best_sent"] = best
        for i, b in enumerate(best):
            prem.append(b); hyp.append(it.hypotheses[i]); owner.append((k, i))
    pr = small_nli.probs(prem, hyp) if (small_nli is not None and prem) else np.zeros((len(prem), 3))
    small = {}
    for (k, i), row in zip(owner, pr):
        small[(k, i)] = row
    for k, it in enumerate(items):
        if not it.claims:
            continue
        vocab = context_vocab(it.ctx_sents)
        ext = []
        for i, c in enumerate(it.claims):
            e, ct, _ = small.get((k, i), (0.0, 0.0, 0.0))
            ext.append([e, ct, negation_mismatch(c, it.meta["best_sent"][i]), number_missing(c, vocab)])
        it.meta["phi_ext"] = np.hstack([it.phi, np.asarray(ext)])


class FeatureCalibrator:
    """Standardised L2 logistic regression on chosen columns of "it.meta['phi_ext']" (or it.phi)."""

    def __init__(self, columns: Sequence[str], C: float = 1.0):
        self.columns = list(columns)
        self.cols = [EXT_FEATURES.index(c) for c in self.columns]
        self.C = C
        self.model = None

    def fit(self, X: np.ndarray, y: Sequence[int]) -> "FeatureCalibrator":
        from sklearn.linear_model import LogisticRegression
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler

        self.model = make_pipeline(StandardScaler(), LogisticRegression(C=self.C, max_iter=3000))
        self.model.fit(np.asarray(X)[:, self.cols], np.asarray(y, dtype=int))
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        if len(X) == 0:
            return np.zeros(0)
        return self.model.predict_proba(np.asarray(X)[:, self.cols])[:, 1]


def ext_matrix(it: Item) -> np.ndarray:
    m = it.meta.get("phi_ext")
    if m is None:
        m = np.hstack([it.phi, np.zeros((len(it.claims), len(EXT_FEATURES) - len(FEATURES)))])
    return m


def single_claim_xy(items: Sequence[Item]):
    X, y = [], []
    for it in items:
        if len(it.claims) == 1:
            X.append(ext_matrix(it)[0]); y.append(1 - int(it.meta["unsupported"]))
    return np.asarray(X), np.asarray(y)


def apply_calibrator(items: Sequence[Item], cal) -> None:
    for it in items:
        it.p = cal.predict(ext_matrix(it)) if it.claims else np.zeros(0)


# ---------------------------------------------------------------------------
# Premise construction
# ---------------------------------------------------------------------------

def premise_topk(ctx: Sequence[str], sims_row: np.ndarray, k: int) -> str:
    if not len(ctx):
        return ""
    idx = np.argsort(-sims_row)[: min(k, len(ctx))]
    return " ".join(ctx[j] for j in sorted(idx.tolist()))


def premise_chain(ctx: Sequence[str], sims_row: np.ndarray, claim: str, para: Optional[Sequence[int]] = None,
                  hops: int = 2, gamma: float = 0.5, extra: int = 1) -> str:
    """Two-hop evidence chain. Hop 1: the sentence most similar to the claim. Hop 2: the sentence that best
    combines similarity to the claim with overlap with the *bridge terms* of hop 1 (entities and content words
    of the hop-1 sentence that are not in the claim), taken from a different paragraph when paragraph ids are
    known. "extra" adds the next most similar sentences so short chains keep some context."""
    if not len(ctx):
        return ""
    sims_row = np.asarray(sims_row, dtype=float)
    chosen = [int(np.argmax(sims_row))]
    claim_terms = set(content_tokens(claim)) | set(key_tokens(claim))
    for _ in range(hops - 1):
        last = ctx[chosen[-1]]
        bridge = (set(content_tokens(last)) | set(key_tokens(last))) - claim_terms
        best, best_score = None, -1e9
        for j, s in enumerate(ctx):
            if j in chosen:
                continue
            if para is not None and para[j] in {para[c] for c in chosen} and len(set(para)) > 1:
                continue
            toks = set(content_tokens(s)) | set(key_tokens(s))
            ov = len(toks & bridge) / max(1, len(bridge)) if bridge else 0.0
            sc = sims_row[j] + gamma * ov
            if sc > best_score:
                best, best_score = j, sc
        if best is None:
            break
        chosen.append(best)
    for j in np.argsort(-sims_row):
        if len(chosen) >= hops + extra:
            break
        if int(j) not in chosen:
            chosen.append(int(j))
    return " ".join(ctx[j] for j in sorted(chosen))


def build_premises(items: Sequence[Item], strategy: str) -> List[List[str]]:
    """Premises for every claim of every item. strategy: top1, top2, top4, top8, chain, full."""
    out = []
    for it in items:
        ps = []
        for i, c in enumerate(it.claims):
            if strategy == "full":
                ps.append(" ".join(it.ctx_sents))
            elif strategy == "chain":
                ps.append(premise_chain(it.ctx_sents, it.sims[i], c, it.meta.get("para")))
            elif strategy.startswith("top"):
                ps.append(premise_topk(it.ctx_sents, it.sims[i], int(strategy[3:])))
            else:
                raise ValueError(strategy)
        out.append(ps)
    return out


def score_premises(items: Sequence[Item], premises: List[List[str]], scorer) -> List[np.ndarray]:
    """Verifier scores (support probability) for every claim with the given premises."""
    prem, hyp, owner = [], [], []
    for k, (it, ps) in enumerate(zip(items, premises)):
        for i, p in enumerate(ps):
            prem.append(p); hyp.append(it.hypotheses[i]); owner.append((k, i))
    v = scorer.entail_prob(prem, hyp) if prem else np.zeros(0)
    out = [np.zeros(len(it.claims)) for it in items]
    for (k, i), val in zip(owner, v):
        out[k][i] = val
    return out


# ---------------------------------------------------------------------------
# Chunked full-passage scorers (MiniCheck, HHEM, any NLI)
# ---------------------------------------------------------------------------

class ChunkedPairScorer:
    """Scores (document, claim) pairs with a model of limited input length: the document is split into
    sentence chunks that fit the budget together with the claim; the support score is the maximum over
    chunks (the aggregation used by MiniCheck)."""

    def __init__(self, tokenizer, score_fn, max_tokens, batch_size=16, name=""):
        self.tok, self.score_fn, self.max_tokens, self.bs, self.name = tokenizer, score_fn, max_tokens, batch_size, name
        self.calls, self.chunk_calls, self.seconds = 0, 0, 0.0
        self._len_cache: Dict[str, int] = {}

    def _len(self, s):
        n = self._len_cache.get(s)
        if n is None:
            n = len(self.tok.encode(s, add_special_tokens=False))
            if len(self._len_cache) < 500000:
                self._len_cache[s] = n
        return n

    def chunks(self, doc, claim):
        budget = max(64, self.max_tokens - self._len(claim) - 8)
        out, cur, n = [], [], 0
        for s in split_sentences(doc) or [doc]:
            k = self._len(s)
            if cur and n + k > budget:
                out.append(" ".join(cur)); cur, n = [], 0
            cur.append(s); n += k
        if cur:
            out.append(" ".join(cur))
        return out or [""]

    def entail_prob(self, docs, claims):
        t0 = time.perf_counter()
        pairs, owner = [], []
        for i, (d, c) in enumerate(zip(docs, claims)):
            for ch in self.chunks(d, c):
                pairs.append((ch, c)); owner.append(i)
        order = sorted(range(len(pairs)), key=lambda j: len(pairs[j][0]) + len(pairs[j][1]))
        scores = np.zeros(len(pairs))
        for s in range(0, len(order), self.bs):
            ids = order[s:s + self.bs]
            scores[ids] = self.score_fn([pairs[j] for j in ids])
        best = np.zeros(len(docs))
        for i, sc in zip(owner, scores):
            best[i] = max(best[i], float(sc))
        self.calls += len(docs); self.chunk_calls += len(pairs)
        self.seconds += time.perf_counter() - t0
        return best


def load_minicheck(name: str, device: str):
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    tok = AutoTokenizer.from_pretrained(name)
    model = AutoModelForSequenceClassification.from_pretrained(name).to(device).eval()
    sup = 1  # MiniCheck classifiers: label 1 = supported
    for i, l in model.config.id2label.items():
        if "support" in str(l).lower() or "entail" in str(l).lower():
            sup = i

    def score(pairs):
        with torch.no_grad():
            enc = tok([p[0] for p in pairs], [p[1] for p in pairs], truncation="only_first", max_length=512,
                      padding=True, return_tensors="pt").to(device)
            return torch.softmax(model(**enc).logits.float(), -1)[:, sup].cpu().numpy()

    return ChunkedPairScorer(tok, score, 512, batch_size=16, name=name)


def load_hhem(device: str):
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    model = AutoModelForSequenceClassification.from_pretrained("vectara/hallucination_evaluation_model",
                                                               trust_remote_code=True).to(device).eval()
    tok = AutoTokenizer.from_pretrained("google/flan-t5-base")

    def score(pairs):
        with torch.no_grad():
            out = model.predict(list(pairs))
        return out.float().cpu().numpy() if hasattr(out, "cpu") else np.asarray(out, dtype=float)

    return ChunkedPairScorer(tok, score, 1024, batch_size=4, name="vectara/hallucination_evaluation_model")


def chunked_nli(nli: NLIProbs) -> ChunkedPairScorer:
    def score(pairs):
        return nli.entail_prob([p[0] for p in pairs], [p[1] for p in pairs])
    return ChunkedPairScorer(nli.tok, score, nli.max_length, batch_size=nli.batch_size, name=nli.name)


# ---------------------------------------------------------------------------
# Decisions, escalation strategies and matched budgets
# ---------------------------------------------------------------------------

def answer_decisions(items: Sequence[Item], esc: List[np.ndarray], v: List[np.ndarray], tau: float):
    """Answer flags and risks for given per-claim escalation masks and verifier scores."""
    pred, risk = [], []
    for it, e, vv in zip(items, esc, v):
        if not it.claims:
            pred.append(0); risk.append(0.0)
            continue
        pp = np.asarray(it.p, dtype=float) if it.p is not None else np.ones(len(it.claims))
        support = np.where(e, vv, pp)
        z = np.where(e, vv < tau, pp < 0.5)
        pred.append(int(z.max())); risk.append(float(1 - support.min()))
    return pred, risk


def priorities(items: Sequence[Item], strategy: str, seed: int = 0) -> List[np.ndarray]:
    """Per-claim escalation priority (higher = escalate first)."""
    rng = np.random.default_rng(seed)
    out = []
    for it in items:
        p = np.asarray(it.p, dtype=float)
        if strategy in ("uncertainty", "confidence"):
            pr = uncertainty(p)
        elif strategy == "random":
            pr = rng.random(len(p))
        elif strategy == "low_support":
            pr = 1 - p
        elif strategy == "disagreement":
            ext = ext_matrix(it)
            s_small = (1 + ext[:, 4] - ext[:, 5]) / 2 if ext.shape[1] > 5 else p
            pr = np.maximum(uncertainty(p), np.abs(p - s_small))
        elif strategy == "uniform":
            pr = np.ones(len(p))
        else:
            raise ValueError(strategy)
        out.append(pr)
    return out


def escalate_budget(items: Sequence[Item], prio: List[np.ndarray], budget: float) -> List[np.ndarray]:
    """Escalate the top "budget" share of all claims, ranked globally by priority."""
    flat = np.concatenate([p for p in prio]) if prio else np.zeros(0)
    n = len(flat)
    k = int(round(budget * n))
    mask_flat = np.zeros(n, dtype=bool)
    if k > 0:
        mask_flat[np.argsort(-flat, kind="stable")[:k]] = True
    out, pos = [], 0
    for p in prio:
        out.append(mask_flat[pos:pos + len(p)]); pos += len(p)
    return out


def budget_curve(items: Sequence[Item], v: List[np.ndarray], tau: float, strategy: str,
                 budgets: Sequence[float], seeds: Sequence[int] = (0,), sec_per_call: float = 0.0,
                 cheap_sec_per_answer: float = 0.0) -> List[Dict]:
    y = [int(it.meta["unsupported"]) for it in items]
    n_claims = sum(len(it.claims) for it in items)
    rows = []
    for b in budgets:
        vals = []
        for sd in seeds:
            esc = escalate_budget(items, priorities(items, strategy, sd), b)
            pred, risk = answer_decisions(items, esc, v, tau)
            sc = prf(y, pred)
            calls = int(sum(e.sum() for e in esc))
            vals.append({"f1": sc["f1"], "precision": sc["precision"], "recall": sc["recall"],
                         "auroc": auroc(y, risk), "calls": calls})
        row = {"budget": b, "call_rate": (np.mean([x["calls"] for x in vals]) / n_claims) if n_claims else 0}
        for key in ("f1", "precision", "recall", "auroc"):
            row[key] = float(np.mean([x[key] for x in vals]))
            if len(seeds) > 1:
                row[key + "_sd"] = float(np.std([x[key] for x in vals]))
        row["latency_s_per_answer"] = cheap_sec_per_answer + row["call_rate"] * n_claims * sec_per_call / max(1, len(items))
        rows.append(row)
    return rows


def theta_curve(items: Sequence[Item], v: List[np.ndarray], tau: float, grid: Sequence[float],
                strategy: str = "uncertainty") -> List[Dict]:
    """Threshold form of the gate (escalate if priority > theta) — the deployed rule."""
    y = [int(it.meta["unsupported"]) for it in items]
    prio = priorities(items, strategy)
    n_claims = sum(len(it.claims) for it in items)
    rows = []
    for th in grid:
        esc = [pr > th for pr in prio]
        pred, risk = answer_decisions(items, esc, v, tau)
        sc = prf(y, pred)
        rows.append({"theta": float(th), "call_rate": sum(int(e.sum()) for e in esc) / max(1, n_claims),
                     "f1": sc["f1"], "precision": sc["precision"], "recall": sc["recall"], "auroc": auroc(y, risk)})
    return rows


def choose_tau_for(items: Sequence[Item], v: List[np.ndarray], grid: Sequence[float]) -> float:
    y = [int(it.meta["unsupported"]) for it in items]
    best, best_f1 = grid[0], -1
    for t in grid:
        pred, _ = answer_decisions(items, [np.ones(len(it.claims), bool) for it in items], v, t)
        f = prf(y, pred)["f1"]
        if f > best_f1:
            best, best_f1 = t, f
    return float(best)


def pick_theta(curve: Sequence[Dict], lam: float) -> Dict:
    return min(curve, key=lambda r: (1 - r["f1"]) + lam * r["call_rate"])


def paired_bootstrap(y, a, b, n_boot=2000, seed=42):
    """F1(a) - F1(b) on the same resampled answers; percentile CI and two-sided bootstrap p-value."""
    y, a, b = (np.asarray(x, dtype=int) for x in (y, a, b))
    rng = np.random.default_rng(seed)
    d = []
    for _ in range(n_boot):
        idx = rng.integers(0, len(y), len(y))
        d.append(prf(y[idx], a[idx])["f1"] - prf(y[idx], b[idx])["f1"])
    d = np.asarray(d)
    p = 2 * min((d <= 0).mean(), (d >= 0).mean())
    return {"diff": float(prf(y, a)["f1"] - prf(y, b)["f1"]), "ci": [float(np.percentile(d, 2.5)),
            float(np.percentile(d, 97.5))], "p_value": float(min(1.0, p))}


def macro_f1_by(items: Sequence[Item], pred: Sequence[int], key: str = "source") -> float:
    groups: Dict[str, List[int]] = {}
    for i, it in enumerate(items):
        groups.setdefault(str(it.meta.get(key, "")), []).append(i)
    y = np.asarray([int(it.meta["unsupported"]) for it in items]); p = np.asarray(pred)
    return float(np.mean([prf(y[ix], p[ix])["f1"] for ix in groups.values()]))


# ---------------------------------------------------------------------------
# Error analysis
# ---------------------------------------------------------------------------

def _cov(tokens, text) -> float:
    return coverage(tokens, context_vocab(split_sentences(text) or [text]))


def attribute_errors(items: Sequence[Item], esc: List[np.ndarray], v: List[np.ndarray], tau: float,
                     premises: List[List[str]], max_claims: int = 8) -> List[Dict]:
    """Assign every wrong answer-level decision to the first pipeline stage that explains it:
    extraction -> missing evidence in the premise -> confident cheap error -> borderline cheap error
    (calibration) -> verifier error."""
    pred, _ = answer_decisions(items, esc, v, tau)
    out = []
    for it, e, vv, ps, pr in zip(items, esc, v, premises, pred):
        gold = int(it.meta["unsupported"])
        if pr == gold:
            continue
        n_cand = len(extract_claims(it.answer, max_claims=1000)) if it.answer else 0
        rec = {"id": it.uid, "source": it.meta.get("source"), "gold": gold, "pred": pr, "n_claims": len(it.claims)}
        if not it.claims or (gold == 1 and n_cand > max_claims):
            rec["stage"] = "extraction"
            out.append(rec)
            continue
        support = np.where(e, vv, it.p)
        if pr == 1:   # false alarm: the claims that triggered the flag
            cand = [i for i in range(len(it.claims)) if (e[i] and vv[i] < tau) or (not e[i] and it.p[i] < 0.5)]
        else:         # miss: the least-supported claim
            cand = [int(np.argmin(support))]
        i = cand[0]
        terms = list(set(content_tokens(it.claims[i])) | set(key_tokens(it.claims[i])))
        full_cov = _cov(terms, " ".join(it.ctx_sents))
        prem_cov = _cov(terms, ps[i]) if ps and ps[i] else 0.0
        if e[i] and full_cov >= 0.8 and prem_cov < 0.5:
            rec["stage"] = "missing_evidence_in_premise"
        elif not e[i] and abs(2 * it.p[i] - 1) >= 0.5:
            rec["stage"] = "cheap_confident"
        elif not e[i]:
            rec["stage"] = "cheap_borderline"
        else:
            rec["stage"] = "verifier"
        rec.update(claim=it.claims[i], p=float(it.p[i]), escalated=bool(e[i]), v=float(vv[i]),
                   premise_coverage=prem_cov, passage_coverage=full_cov)
        out.append(rec)
    return out


def false_rejection_analysis(items: Sequence[Item], v: List[np.ndarray], premises: List[List[str]], tau: float,
                             short_words: int = 5) -> Dict:
    """Why does uniform verification flag supported answers? For every rejected claim of a supported answer:
    wrapped short answer (hypothesis template), evidence missing from the premise, or a model error with the
    evidence present."""
    cats = {"wrapped_short_answer": 0, "evidence_missing_in_premise": 0, "model_error_evidence_present": 0}
    n_ans, n_claims = 0, 0
    for it, vv, ps in zip(items, v, premises):
        if int(it.meta["unsupported"]) == 1 or not it.claims:
            continue
        rej = [i for i in range(len(it.claims)) if vv[i] < tau]
        if not rej:
            continue
        n_ans += 1
        for i in rej:
            n_claims += 1
            terms = list(set(content_tokens(it.claims[i])) | set(key_tokens(it.claims[i])))
            if it.hypotheses[i] != it.claims[i]:
                cats["wrapped_short_answer"] += 1
            elif _cov(terms, ps[i]) < 0.5 <= _cov(terms, " ".join(it.ctx_sents)):
                cats["evidence_missing_in_premise"] += 1
            else:
                cats["model_error_evidence_present"] += 1
    return {"flagged_supported_answers": n_ans, "rejected_claims": n_claims,
            **{k: c / max(1, n_claims) for k, c in cats.items()}, "counts": cats}


# ---------------------------------------------------------------------------
# LLM-based claim decomposition
# ---------------------------------------------------------------------------

DECOMP_SYSTEM = (
    "You split an answer into atomic factual claims.\n"
    "Rules: each claim is one short, self-contained declarative sentence that states exactly one fact; "
    "replace pronouns with the names they refer to; keep numbers, dates and names exactly as written; "
    "split sentences that contain several facts; ignore statements about the task, the question, the "
    "context or the reasoning process (for example 'Step 2: analyze the context'), and ignore refusals.\n"
    "If the answer is a bare value (for example '1998' or 'yes'), write one claim that states it as the "
    "answer to the question.\n"
    "Return only a JSON list of strings, for example [\"claim 1\", \"claim 2\"]."
)


def decomposition_prompt(question: str, answer: str) -> str:
    return f"QUESTION: {question}\n\nANSWER: {answer}\n\nReturn the JSON list of atomic claims."


def parse_claim_list(text: str, max_claims: int = 30) -> List[str]:
    m = re.search(r"\[.*\]", text or "", flags=re.S)
    if m:
        try:
            arr = json.loads(m.group(0))
            claims = [str(x).strip() for x in arr if str(x).strip()]
            return claims[:max_claims]
        except json.JSONDecodeError:
            pass
    lines = [re.sub(r"^\s*(?:[-*•]|\d+[.)])\s*", "", l).strip(" \"',") for l in (text or "").splitlines()]
    return [l for l in lines if len(l.split()) >= 3][:max_claims]


def llm_decompose(judge, pairs: Sequence[tuple], max_new_tokens: int = 320) -> List[List[str]]:
    """Atomic claims for (question, answer) pairs with the judge's chat model (cached like judge calls)."""
    old = getattr(judge, "max_new_tokens", None)
    if old is not None:
        judge.max_new_tokens = max_new_tokens
    try:
        raw = judge._run([(DECOMP_SYSTEM, decomposition_prompt(q, a)) for q, a in pairs])
    finally:
        if old is not None:
            judge.max_new_tokens = old
    return [parse_claim_list(r.get("text", "")) for r in raw]


def make_item_from_claims(scorer, uid: str, question: str, claims: Sequence[str], ctx: Sequence[str], meta=None,
                          answer: str = "") -> Item:
    """Item with externally supplied claims (LLM decomposition, synthetic multi-hop claims)."""
    it = Item(uid=uid, question=question, answer=answer, ctx_sents=list(ctx), meta=dict(meta or {}))
    it.claims = list(claims)
    it.hypotheses = [to_hypothesis(c, question) for c in it.claims]
    it.phi, it.sims = scorer.features(it.claims, it.hypotheses, it.ctx_sents)
    it.premises = [premise_topk(it.ctx_sents, it.sims[i], 4) for i in range(len(it.claims))]
    return it


def ece(probs: Sequence[float], outcomes: Sequence[int], n_bins: int = 10) -> float:
    from .metrics import expected_calibration_error
    return float(expected_calibration_error(list(probs), list(outcomes), n_bins))


def claim_level_scores(scores: Sequence[float], unsupported: Sequence[int], threshold: float) -> Dict:
    """Detection of unsupported claims from support scores (low score = unsupported)."""
    s = np.asarray(scores, dtype=float); y = np.asarray(unsupported, dtype=int)
    out = prf(y, (s < threshold).astype(int))
    out["auroc"] = auroc(y, 1 - s)
    return out


def best_threshold(scores: Sequence[float], unsupported: Sequence[int]) -> float:
    s = np.asarray(scores, dtype=float); y = np.asarray(unsupported, dtype=int)
    grid = np.unique(np.r_[np.linspace(0.02, 0.98, 49), np.quantile(s, np.linspace(0.02, 0.98, 49))]) if len(s) else [0.5]
    return float(max(grid, key=lambda t: prf(y, (s < t).astype(int))["f1"]))
