"""Retrieval orchestration for the base-paper reproduction (Tables 1 and 3).

Every single-retriever result list is cached on disk, so a run that is interrupted (free GPU
sessions end without warning) continues from the last finished retriever.
"""

from __future__ import annotations

import hashlib
import pickle
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, Sequence

from .ir_metrics import evaluate_run
from .retrieval import (BM25Index, DenseIndex, Hits, fuse_combmnz, fuse_linear, fuse_rrf, rerank_blend)
from .utils import free_gpu_memory

SINGLE = ("bm25", "splade", "mpnet", "mpnet_qa", "contriever")
HYBRID = ("hybrid_rrf", "hybrid_combmnz", "hybrid_li", "hybrid_li_rerank")


def default_backends(cfg: Dict) -> Dict[str, Callable]:
    """Factories for the real models (imported lazily)."""
    from .retrieval import CrossEncoderReranker, DenseEncoder, SpladeEncoder, SparseVectorIndex

    rc = cfg["retrieval"]
    m = rc["models"]

    def dense(name, pooling):
        def search(doc_texts, queries, depth):
            enc = DenseEncoder(m[name], pooling=pooling, batch_size=rc["batch_size"])
            index = DenseIndex(enc.encode(doc_texts))
            hits = index.search(enc.encode(queries), depth)
            del enc, index
            free_gpu_memory()
            return hits
        return search

    def splade(doc_texts, queries, depth):
        enc = SpladeEncoder(m["splade"], batch_size=max(8, rc["batch_size"] // 2), max_terms=rc["splade_max_terms"])
        doc_matrix = enc.encode(doc_texts)
        query_matrix = enc.encode(queries)
        del enc
        free_gpu_memory()
        return SparseVectorIndex(doc_matrix).search(query_matrix, depth)

    def bm25(doc_texts, queries, depth):
        return BM25Index(**rc["bm25"]).fit(doc_texts).search(queries, depth)

    def reranker():
        return CrossEncoderReranker(m["reranker"], batch_size=rc.get("rerank_batch_size", 256)).score

    return {"bm25": bm25, "splade": splade, "mpnet": dense("mpnet", "st"),
            "mpnet_qa": dense("mpnet_qa", "st"), "contriever": dense("contriever", "mean"),
            "reranker": reranker}


def _fingerprint(doc_texts: Sequence[str], qids: Sequence[str], depth: int, extra: str = "") -> str:
    h = hashlib.sha1()
    h.update(f"{len(doc_texts)}|{len(qids)}|{depth}|{extra}".encode())
    for t in list(doc_texts[:50]) + list(doc_texts[-50:]) + list(qids[:50]) + list(qids[-50:]):
        h.update(str(t).encode("utf-8", "ignore"))
    return h.hexdigest()[:16]


def _cached(cache_dir: Optional[Path], name: str, fp: str, compute: Callable[[], List[Hits]],
            log: Callable[[str], None]) -> List[Hits]:
    path = Path(cache_dir) / f"{name}.pkl" if cache_dir else None
    if path and path.exists():
        try:
            with open(path, "rb") as fh:
                saved = pickle.load(fh)
            if saved.get("fingerprint") == fp:
                log(f"[retrieval] {name}: loaded from cache")
                return saved["hits"]
        except Exception:
            pass  # unreadable cache file: recompute
    t0 = time.time()
    hits = compute()
    log(f"[retrieval] {name}: done in {(time.time() - t0) / 60:.1f} min")
    if path:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        with open(tmp, "wb") as fh:
            pickle.dump({"fingerprint": fp, "hits": hits}, fh, protocol=pickle.HIGHEST_PROTOCOL)
        tmp.replace(path)
    return hits


def run_methods(doc_texts: Sequence[str], qids: Sequence[str], queries: Sequence[str],
                qrels: Dict[str, Dict[str, int]], methods: Sequence[str], cfg: Dict,
                backends: Dict[str, Callable], log: Callable[[str], None] = print,
                cache_dir: Optional[str] = None,
                on_step: Optional[Callable[[], None]] = None) -> Dict[str, Dict]:
    """Run every requested method; returns {method: {"run": {qid: [doc_id,...]}, "eval": {...}}}.

    ``on_step`` is called after each retriever finishes (used to sync outputs off the machine).
    """
    rc = cfg["retrieval"]
    hc = rc["hybrid"]
    depth, top_k, cutoffs = rc["candidate_depth"], rc["top_k"], rc["cutoffs"]
    needed = set(m for m in methods if m in SINGLE)
    if any(m in HYBRID for m in methods):
        needed.update([hc["sparse"], hc["dense"]])
    cache = Path(cache_dir) if cache_dir else None
    lists: Dict[str, List[Hits]] = {}
    for name in [n for n in SINGLE if n in needed]:
        log(f"[retrieval] {name}: {len(queries)} queries over {len(doc_texts)} documents")
        extra = rc["models"].get(name, "") + (str(rc.get("bm25")) if name == "bm25" else "")
        fp = _fingerprint(doc_texts, qids, depth, extra)
        lists[name] = _cached(cache, name, fp, lambda n=name: backends[n](doc_texts, queries, depth), log)
        if on_step:
            on_step()

    fused: Dict[str, List[Hits]] = {}
    if any(m in HYBRID for m in methods):
        s_lists, d_lists = lists[hc["sparse"]], lists[hc["dense"]]
        w = hc["sparse_weight"]
        fused["hybrid_li"] = [fuse_linear([s, d], [w, 1 - w]) for s, d in zip(s_lists, d_lists)]
        if "hybrid_rrf" in methods:
            fused["hybrid_rrf"] = [fuse_rrf([s, d], eps=hc["rrf_eps"]) for s, d in zip(s_lists, d_lists)]
        if "hybrid_combmnz" in methods:
            fused["hybrid_combmnz"] = [fuse_combmnz([s, d]) for s, d in zip(s_lists, d_lists)]
        if "hybrid_li_rerank" in methods:
            log(f"[retrieval] cross-encoder reranking of up to {hc['rerank_pool']} candidates per query")
            fp = _fingerprint(doc_texts, qids, depth,
                              f"rerank|{rc['models']['reranker']}|{hc}|{rc['models'][hc['sparse']]}|{rc['models'][hc['dense']]}")

            def rerank_all() -> List[Hits]:
                score_fn = backends["reranker"]()
                out = []
                for i, (q, f) in enumerate(zip(queries, fused["hybrid_li"]), 1):
                    out.append(rerank_blend(q, f, doc_texts, score_fn, pool=hc["rerank_pool"], beta=hc["rerank_beta"]))
                    if i % 2000 == 0:
                        log(f"[retrieval]   reranked {i}/{len(queries)} queries")
                free_gpu_memory()
                return out

            fused["hybrid_li_rerank"] = _cached(cache, "hybrid_li_rerank", fp, rerank_all, log)
            if on_step:
                on_step()

    results: Dict[str, Dict] = {}
    for m in methods:
        hits = lists.get(m) if m in SINGLE else fused.get(m)
        if hits is None:
            continue
        run = {qid: [f"d{d}" for d, _ in h[:top_k]] for qid, h in zip(qids, hits)}
        scores = {qid: [float(s) for _, s in h[:top_k]] for qid, h in zip(qids, hits)}
        results[m] = {"run": run, "scores": scores, "eval": evaluate_run(run, qrels, cutoffs)}
        log(f"[retrieval] {m}: " + ", ".join(f"{k}={v:.4f}" for k, v in results[m]["eval"]["mean"].items()))
    return results
