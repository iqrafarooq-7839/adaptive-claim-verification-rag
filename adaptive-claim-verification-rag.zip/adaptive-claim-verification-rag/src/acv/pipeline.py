"""Retrieval orchestration for the base-paper reproduction (Tables 1 and 3)."""

from __future__ import annotations

from typing import Callable, Dict, List, Sequence

from .ir_metrics import evaluate_run
from .retrieval import (BM25Index, DenseIndex, Hits, fuse_combmnz, fuse_linear, fuse_rrf, rerank_blend)

SINGLE = ("bm25", "splade", "mpnet", "mpnet_qa", "contriever")
HYBRID = ("hybrid_rrf", "hybrid_combmnz", "hybrid_li", "hybrid_li_rerank")


def default_backends(cfg: Dict) -> Dict[str, Callable]:
    """Factories for the real models (imported lazily)."""
    from .retrieval import CrossEncoderReranker, DenseEncoder, SpladeEncoder, SparseVectorIndex

    rc = cfg["retrieval"]
    m = rc["models"]

    def dense(name, pooling):
        def search(doc_texts, queries, depth):
            enc = DenseEncoder(m[name], pooling=pooling, batch_size=rc["batch_size"])
            index = DenseIndex(enc.encode(doc_texts))
            return index.search(enc.encode(queries), depth)
        return search

    def splade(doc_texts, queries, depth):
        enc = SpladeEncoder(m["splade"], batch_size=max(8, rc["batch_size"] // 2), max_terms=rc["splade_max_terms"])
        index = SparseVectorIndex(enc.encode(doc_texts))
        return index.search(enc.encode(queries), depth)

    def bm25(doc_texts, queries, depth):
        return BM25Index(**rc["bm25"]).fit(doc_texts).search(queries, depth)

    def reranker():
        return CrossEncoderReranker(m["reranker"]).score

    return {"bm25": bm25, "splade": splade, "mpnet": dense("mpnet", "st"),
            "mpnet_qa": dense("mpnet_qa", "st"), "contriever": dense("contriever", "mean"),
            "reranker": reranker}


def run_methods(doc_texts: Sequence[str], qids: Sequence[str], queries: Sequence[str],
                qrels: Dict[str, Dict[str, int]], methods: Sequence[str], cfg: Dict,
                backends: Dict[str, Callable], log: Callable[[str], None] = print) -> Dict[str, Dict]:
    """Run every requested method; returns {method: {"run": {qid: [doc_id,...]}, "eval": {...}}}."""
    rc = cfg["retrieval"]
    hc = rc["hybrid"]
    depth, top_k, cutoffs = rc["candidate_depth"], rc["top_k"], rc["cutoffs"]
    needed = set(m for m in methods if m in SINGLE)
    if any(m in HYBRID for m in methods):
        needed.update([hc["sparse"], hc["dense"]])
    lists: Dict[str, List[Hits]] = {}
    for name in [n for n in SINGLE if n in needed]:
        log(f"[retrieval] {name}: {len(queries)} queries over {len(doc_texts)} documents")
        lists[name] = backends[name](doc_texts, queries, depth)

    fused: Dict[str, List[Hits]] = {}
    if any(m in HYBRID for m in methods):
        s_lists, d_lists = lists[hc["sparse"]], lists[hc["dense"]]
        w = hc["sparse_weight"]
        fused["hybrid_li"] = [fuse_linear([s, d], [w, 1 - w]) for s, d in zip(s_lists, d_lists)]
        if "hybrid_rrf" in methods:
            fused["hybrid_rrf"] = [fuse_rrf([s, d], eps=hc["rrf_eps"]) for s, d in zip(s_lists, d_lists)]
        if "hybrid_combmnz" in methods:
            fused["hybrid_combmnz"] = [fuse_combmnz([s, d]) for s, d in zip(s_lists, d_lists)]
        if "hybrid_li_rerank" in methods:
            log("[retrieval] cross-encoder reranking")
            score_fn = backends["reranker"]()
            fused["hybrid_li_rerank"] = [
                rerank_blend(q, f, doc_texts, score_fn, pool=hc["rerank_pool"], beta=hc["rerank_beta"])
                for q, f in zip(queries, fused["hybrid_li"])]

    results: Dict[str, Dict] = {}
    for m in methods:
        hits = lists.get(m) if m in SINGLE else fused.get(m)
        if hits is None:
            continue
        run = {qid: [f"d{d}" for d, _ in h[:top_k]] for qid, h in zip(qids, hits)}
        scores = {qid: [float(s) for _, s in h[:top_k]] for qid, h in zip(qids, hits)}
        results[m] = {"run": run, "scores": scores, "eval": evaluate_run(run, qrels, cutoffs)}
        log(f"[retrieval] {m}: " + ", ".join(f"{k}={v:.4f}" for k, v in results[m]["eval"]["mean"].items()))
    return results
