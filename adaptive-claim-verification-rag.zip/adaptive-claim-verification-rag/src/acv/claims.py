"""Claim extraction: turn a generated answer (including its reasoning steps) into atomic claims."""

from __future__ import annotations

import re
from typing import List, Optional

from .generation import is_refusal
from .utils import normalize_text, split_sentences

_PREFIX = re.compile(r"^\s*(?:[-*•]+\s*)?(?:\*\*)?(?:step\s*\d+\s*[:.\-]|final answer\s*[:\-]|"
                     r"answer\s*[:\-]|therefore,?|thus,?|so,?)\s*(?:\*\*)?\s*", re.I)
_META = re.compile(
    r"^(the question (asks|is asking)|to answer|let'?s|i (will|need|can|must)|we (need|can|must)|"
    r"first,? (i|we)|carefully read|analy[sz]e whether|"
    r"(the )?(given |provided )?contexts? (do(es)? )?(provide|provides|contain|contains|give|gives) "
    r"(sufficient|enough|the necessary|relevant)|"
    r"(this|that) (information|context) (is|was) (sufficient|enough))",
    re.I,
)
_WORD = re.compile(r"[A-Za-z0-9]+")


def _words(text: str) -> List[str]:
    return _WORD.findall(text or "")


def extract_claims(answer: str, min_words: int = 3, max_claims: int = 8) -> List[str]:
    """Rule-based extractor used in all experiments.

    Splits the output into sentences (step lines included, so intermediate multi-hop statements
    become claims), strips step labels, and drops refusals, meta-reasoning and fragments.
    A short answer with no full sentence (e.g. "1998") is kept as a single claim.
    """
    if not answer or is_refusal(answer) and len(_words(answer)) < 25:
        return []
    text = answer.replace("**", " ")
    pieces: List[str] = []
    for line in re.split(r"[\r\n]+", text):
        pieces.extend(split_sentences(line))
    claims, seen = [], set()
    for p in pieces:
        s = _PREFIX.sub("", p).strip(" -*•\t")
        s = _PREFIX.sub("", s).strip()
        if not s or is_refusal(s) or _META.search(s):
            continue
        if len(_words(s)) < min_words:
            continue
        key = normalize_text(s)
        if key in seen:
            continue
        seen.add(key)
        claims.append(s)
        if len(claims) >= max_claims:
            break
    if not claims and not is_refusal(answer):
        short = answer.strip().strip(".")
        if short:
            claims = [short]
    return claims


def to_hypothesis(claim: str, question: Optional[str] = None, short_words: int = 5) -> str:
    """A bare short answer ("1998") is not a proposition; wrap it with the question so it can be
    checked by entailment. Full sentences are used as they are."""
    if question and len(_words(claim)) <= short_words:
        return f"The answer to the question \"{question.strip()}\" is {claim.strip().rstrip('.')}."
    return claim.strip()
