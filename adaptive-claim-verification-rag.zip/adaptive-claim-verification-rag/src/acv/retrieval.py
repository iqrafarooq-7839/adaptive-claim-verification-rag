"""Retrievers used in the base-paper reproduction.

Sparse: BM25 (sparse-matrix implementation with Pyserini's default k1/b) and SPLADE.
Dense: MPNet, MultiQA-MPNet (sentence-transformers) and Contriever (mean pooling).
Fusion: min-max linear interpolation (LI), CombMNZ and reciprocal rank fusion (RRF).
Reranking: MS MARCO MiniLM cross-encoder blended with the fused score.

Heavy libraries (torch, transformers, sentence-transformers) are imported lazily so the
fusion code and the tests run without them.
"""

from __future__ import annotations

import math
import re
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np
from scipy import sparse

Hits = List[Tuple[int, float]]  # (document index, score), best first


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------

def topk_from_sparse_rows(scores: sparse.csr_matrix, k: int) -> List[Hits]:
    """Top-k (index, score) per row of a sparse score matrix, ignoring zero scores."""
    scores = scores.tocsr()
    out: List[Hits] = []
    for i in range(scores.shape[0]):
        start, end = scores.indptr[i], scores.indptr[i + 1]
        idx, val = scores.indices[start:end], scores.data[start:end]
        if len(val) == 0:
            out.append([])
            continue
        kk = min(k, len(val))
        part = np.argpartition(-val, kk - 1)[:kk]
        order = part[np.argsort(-val[part], kind="stable")]
        out.append([(int(idx[j]), float(val[j])) for j in order])
    return out


def topk_dense(scores: np.ndarray, k: int) -> List[Hits]:
    out: List[Hits] = []
    k = min(k, scores.shape[1])
    for row in scores:
        part = np.argpartition(-row, k - 1)[:k]
        order = part[np.argsort(-row[part], kind="stable")]
        out.append([(int(j), float(row[j])) for j in order])
    return out


# ---------------------------------------------------------------------------
# BM25
# ---------------------------------------------------------------------------

# Lucene's default English stop words (the set used by Pyserini's default analyzer)
LUCENE_STOPWORDS = frozenset("""a an and are as at be but by for if in into is it no not of on or such that the
their then there these they this to was will with""".split())
_BM25_TOKEN = re.compile(r"\w+")


class LuceneEnglishAnalyzer:
    """Approximation of Lucene's EnglishAnalyzer (Pyserini default): lower-case, drop possessive 's,
    remove stop words, Porter stemming. Falls back to plain lower-cased tokens if NLTK is missing."""

    def __init__(self, stem: bool = True):
        self._cache: Dict[str, str] = {}
        self._stem = None
        if stem:
            try:
                from nltk.stem.porter import PorterStemmer

                self._stem = PorterStemmer(mode=PorterStemmer.ORIGINAL_ALGORITHM).stem
            except Exception:  # NLTK not installed
                self._stem = None

    def __call__(self, text: str) -> List[str]:
        out = []
        for tok in _BM25_TOKEN.findall(text.lower().replace("'s ", " ").replace("\u2019s ", " ")):
            if tok in LUCENE_STOPWORDS:
                continue
            if self._stem is not None:
                st = self._cache.get(tok)
                if st is None:
                    st = self._cache[tok] = self._stem(tok)
                tok = st
            out.append(tok)
        return out


class BM25Index:
    """Okapi BM25 with Lucene's idf, computed as a sparse matrix product (fast for large query sets).

    ``analyzer='lucene_english'`` mimics Pyserini's default analyzer (stop words + Porter stemming);
    ``analyzer='plain'`` uses lower-cased word tokens only.
    """

    def __init__(self, k1: float = 0.9, b: float = 0.4, analyzer: str = "lucene_english"):
        self.k1, self.b, self.analyzer = k1, b, analyzer

    def fit(self, texts: Sequence[str]) -> "BM25Index":
        from sklearn.feature_extraction.text import CountVectorizer

        if self.analyzer == "lucene_english":
            self.vectorizer = CountVectorizer(analyzer=LuceneEnglishAnalyzer(), dtype=np.float32)
        else:
            self.vectorizer = CountVectorizer(lowercase=True, token_pattern=r"(?u)\b\w+\b", dtype=np.float32)
        tf = self.vectorizer.fit_transform(texts).tocsr().astype(np.float32)
        n_docs = tf.shape[0]
        df = np.bincount(tf.indices, minlength=tf.shape[1]).astype(np.float32)
        idf = np.log1p((n_docs - df + 0.5) / (df + 0.5)).astype(np.float32)
        dl = np.asarray(tf.sum(axis=1)).ravel()
        avgdl = float(dl.mean()) if n_docs else 1.0
        rows = np.repeat(np.arange(n_docs), np.diff(tf.indptr))
        denom = tf.data + self.k1 * (1 - self.b + self.b * dl[rows] / max(avgdl, 1e-9))
        weights = idf[tf.indices] * tf.data * (self.k1 + 1) / denom
        w = sparse.csr_matrix((weights.astype(np.float32), tf.indices, tf.indptr), shape=tf.shape)
        self.term_doc = w.T.tocsr()  # vocabulary x documents
        return self

    def search(self, queries: Sequence[str], k: int, batch_size: int = 64) -> List[Hits]:
        out: List[Hits] = []
        for s in range(0, len(queries), batch_size):
            # each query term counts once (Lucene scores a repeated query term once per clause match)
            q = self.vectorizer.transform(queries[s:s + batch_size]).astype(np.float32)
            out.extend(topk_from_sparse_rows(q @ self.term_doc, k))
        return out


# ---------------------------------------------------------------------------
# SPLADE
# ---------------------------------------------------------------------------

class SpladeEncoder:
    """SPLADE term weights: max over tokens of log(1 + ReLU(MLM logits))."""

    def __init__(self, model_name: str, device: Optional[str] = None, batch_size: int = 64,
                 max_length: int = 256, max_terms: int = 256):
        import torch
        from transformers import AutoModelForMaskedLM, AutoTokenizer

        from .utils import device_name

        self.torch = torch
        self.device = device or device_name()
        self.tok = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForMaskedLM.from_pretrained(model_name).to(self.device).eval()
        limit = getattr(self.model.config, "max_position_embeddings", max_length) or max_length
        self.batch_size, self.max_length, self.max_terms = batch_size, min(max_length, limit), max_terms

    def encode(self, texts: Sequence[str]) -> sparse.csr_matrix:
        torch = self.torch
        vocab = self.model.config.vocab_size
        rows, cols, vals = [], [], []
        with torch.no_grad():
            for s in range(0, len(texts), self.batch_size):
                batch = list(texts[s:s + self.batch_size])
                enc = self.tok(batch, padding=True, truncation=True, max_length=self.max_length,
                               return_tensors="pt").to(self.device)
                logits = self.model(**enc).logits
                w = torch.log1p(torch.relu(logits)) * enc["attention_mask"].unsqueeze(-1)
                rep = w.max(dim=1).values  # batch x vocab
                top = torch.topk(rep, min(self.max_terms, vocab), dim=1)
                v = top.values.float().cpu().numpy()
                c = top.indices.cpu().numpy()
                keep = v > 0
                r = np.broadcast_to(np.arange(s, s + len(batch))[:, None], v.shape)
                rows.append(r[keep].astype(np.int64))
                cols.append(c[keep].astype(np.int64))
                vals.append(v[keep].astype(np.float32))
        if not rows:
            return sparse.csr_matrix((len(texts), vocab), dtype=np.float32)
        return sparse.csr_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))),
                                 shape=(len(texts), vocab))


class SparseVectorIndex:
    def __init__(self, doc_matrix: sparse.csr_matrix):
        self.term_doc = doc_matrix.T.tocsr()

    def search(self, query_matrix: sparse.csr_matrix, k: int, batch_size: int = 64) -> List[Hits]:
        out: List[Hits] = []
        for s in range(0, query_matrix.shape[0], batch_size):
            out.extend(topk_from_sparse_rows(query_matrix[s:s + batch_size] @ self.term_doc, k))
        return out


# ---------------------------------------------------------------------------
# Dense retrievers
# ---------------------------------------------------------------------------

class DenseEncoder:
    """L2-normalised sentence embeddings.

    ``pooling='st'`` uses sentence-transformers (MPNet, MultiQA-MPNet);
    ``pooling='mean'`` uses a plain transformer with attention-masked mean pooling (Contriever).
    """

    def __init__(self, model_name: str, pooling: str = "st", device: Optional[str] = None,
                 batch_size: int = 128, max_length: int = 256):
        from .utils import device_name

        self.device = device or device_name()
        self.pooling, self.batch_size, self.max_length = pooling, batch_size, max_length
        if pooling == "st":
            from sentence_transformers import SentenceTransformer

            self.model = SentenceTransformer(model_name, device=self.device)
            self.model.max_seq_length = max_length
        elif pooling == "mean":
            import torch
            from transformers import AutoModel, AutoTokenizer

            self.torch = torch
            self.tok = AutoTokenizer.from_pretrained(model_name)
            self.model = AutoModel.from_pretrained(model_name).to(self.device).eval()
            limit = getattr(self.model.config, "max_position_embeddings", max_length) or max_length
            self.max_length = min(max_length, limit)
        else:
            raise ValueError(pooling)

    def encode(self, texts: Sequence[str]) -> np.ndarray:
        if self.pooling == "st":
            emb = self.model.encode(list(texts), batch_size=self.batch_size, convert_to_numpy=True,
                                    normalize_embeddings=True, show_progress_bar=len(texts) > 5000)
            return emb.astype(np.float32)
        torch = self.torch
        chunks = []
        with torch.no_grad():
            for s in range(0, len(texts), self.batch_size):
                enc = self.tok(list(texts[s:s + self.batch_size]), padding=True, truncation=True,
                               max_length=self.max_length, return_tensors="pt").to(self.device)
                out = self.model(**enc).last_hidden_state
                mask = enc["attention_mask"].unsqueeze(-1).float()
                emb = (out * mask).sum(1) / mask.sum(1).clamp(min=1e-9)
                emb = torch.nn.functional.normalize(emb, dim=-1)
                chunks.append(emb.float().cpu().numpy())
        return np.concatenate(chunks, axis=0) if chunks else np.zeros((0, 1), dtype=np.float32)


class DenseIndex:
    """Exact inner-product search (cosine, since embeddings are normalised)."""

    def __init__(self, doc_emb: np.ndarray, use_torch: bool = True):
        self.doc_emb = doc_emb.astype(np.float32)
        self._t = None
        if use_torch:
            try:
                import torch

                from .utils import device_name

                dev = device_name()
                self._torch = torch
                self._t = torch.from_numpy(self.doc_emb).to(dev)
                if dev != "cpu":
                    self._t = self._t.half()
            except ImportError:
                self._t = None

    def search(self, q_emb: np.ndarray, k: int, batch_size: int = 256) -> List[Hits]:
        out: List[Hits] = []
        for s in range(0, len(q_emb), batch_size):
            q = q_emb[s:s + batch_size].astype(np.float32)
            if self._t is not None:
                torch = self._torch
                qt = torch.from_numpy(q).to(self._t.device).to(self._t.dtype)
                sc = qt @ self._t.T
                kk = min(k, sc.shape[1])
                top = torch.topk(sc.float(), kk, dim=1)
                for vals, idx in zip(top.values.cpu().numpy(), top.indices.cpu().numpy()):
                    out.append([(int(i), float(v)) for i, v in zip(idx, vals)])
            else:
                out.extend(topk_dense(q @ self.doc_emb.T, k))
        return out


# ---------------------------------------------------------------------------
# Fusion
# ---------------------------------------------------------------------------

def minmax(scores: Dict[int, float]) -> Dict[int, float]:
    if not scores:
        return {}
    lo, hi = min(scores.values()), max(scores.values())
    if math.isclose(hi, lo):
        return {d: 1.0 for d in scores}
    return {d: (v - lo) / (hi - lo) for d, v in scores.items()}


def fuse_linear(lists: Sequence[Hits], weights: Sequence[float]) -> Hits:
    """Score_LI(d) = sum_i w_i * minmax(s_i)(d); a document missing from a list contributes 0."""
    fused: Dict[int, float] = {}
    for hits, w in zip(lists, weights):
        for d, v in minmax(dict(hits)).items():
            fused[d] = fused.get(d, 0.0) + w * v
    return sorted(fused.items(), key=lambda x: (-x[1], x[0]))


def fuse_combmnz(lists: Sequence[Hits]) -> Hits:
    """Score_CombMNZ(d) = (sum_i minmax(s_i)(d)) * |{i : s_i(d) > 0}|."""
    total: Dict[int, float] = {}
    count: Dict[int, int] = {}
    for hits in lists:
        for d, v in minmax(dict(hits)).items():
            total[d] = total.get(d, 0.0) + v
            if v > 0:
                count[d] = count.get(d, 0) + 1
    fused = {d: total[d] * count.get(d, 0) for d in total}
    return sorted(fused.items(), key=lambda x: (-x[1], x[0]))


def fuse_rrf(lists: Sequence[Hits], eps: float = 60.0, weights: Optional[Sequence[float]] = None) -> Hits:
    """Score_RRF(d) = sum_i w_i / (eps + rank_i(d)), ranks starting at 1."""
    weights = weights or [1.0] * len(lists)
    fused: Dict[int, float] = {}
    for hits, w in zip(lists, weights):
        for rank, (d, _) in enumerate(hits, start=1):
            fused[d] = fused.get(d, 0.0) + w / (eps + rank)
    return sorted(fused.items(), key=lambda x: (-x[1], x[0]))


# ---------------------------------------------------------------------------
# Cross-encoder reranking
# ---------------------------------------------------------------------------

class CrossEncoderReranker:
    def __init__(self, model_name: str, device: Optional[str] = None, batch_size: int = 64):
        from sentence_transformers import CrossEncoder

        from .utils import device_name

        self.model = CrossEncoder(model_name, device=device or device_name())
        limit = getattr(self.model.model.config, "max_position_embeddings", 512) or 512
        attr = "max_seq_length" if hasattr(type(self.model), "max_seq_length") else "max_length"
        setattr(self.model, attr, min(512, limit))
        self.batch_size = batch_size

    def score(self, query: str, docs: Sequence[str]) -> np.ndarray:
        if not docs:
            return np.zeros(0, dtype=np.float32)
        return np.asarray(self.model.predict([(query, d) for d in docs], batch_size=self.batch_size),
                          dtype=np.float32)


def rerank_blend(query: str, fused: Hits, texts: Sequence[str],
                 score_fn: Callable[[str, Sequence[str]], np.ndarray],
                 pool: int = 200, beta: float = 0.85) -> Hits:
    """final(d) = beta * minmax(ce)(d) + (1 - beta) * minmax(fused)(d) over the top-``pool`` fused candidates."""
    cand = fused[:pool]
    if not cand:
        return []
    ce = score_fn(query, [texts[d] for d, _ in cand])
    ce_n = minmax({d: float(s) for (d, _), s in zip(cand, ce)})
    fu_n = minmax(dict(cand))
    final = {d: beta * ce_n[d] + (1 - beta) * fu_n[d] for d, _ in cand}
    return sorted(final.items(), key=lambda x: (-x[1], x[0]))
