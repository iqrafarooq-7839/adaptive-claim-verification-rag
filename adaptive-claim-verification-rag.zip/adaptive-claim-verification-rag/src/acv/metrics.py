"""Evaluation metrics: base-paper answer metrics, claim detection metrics, calibration, statistics."""

from __future__ import annotations

from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# Base paper: answer-level metrics from judge labels
# ---------------------------------------------------------------------------

def answer_metrics(labels: Iterable[Optional[str]]) -> Dict[str, float]:
    """Accuracy, hallucination rate, rejection rate (all over valid labels) and adjusted accuracy
    = correct / (correct + hallucinated), in percent. ``None`` labels (judge refusals) are dropped."""
    labs = [l for l in labels if l is not None]
    n = len(labs)
    c = sum(l == "Correct" for l in labs)
    h = sum(l == "Hallucinated" for l in labs)
    r = sum(l == "Insufficient Context" for l in labs)
    pct = lambda x: 100.0 * x / n if n else float("nan")
    return {"n": n, "accuracy": pct(c), "hallucination_rate": pct(h), "rejection_rate": pct(r),
            "adjusted_accuracy": 100.0 * c / (c + h) if (c + h) else float("nan")}


# ---------------------------------------------------------------------------
# Detection of unsupported claims (positive class = unsupported)
# ---------------------------------------------------------------------------

def prf(y_true: Sequence[int], y_pred: Sequence[int]) -> Dict[str, float]:
    yt, yp = np.asarray(y_true, dtype=int), np.asarray(y_pred, dtype=int)
    tp = int(((yt == 1) & (yp == 1)).sum())
    fp = int(((yt == 0) & (yp == 1)).sum())
    fn = int(((yt == 1) & (yp == 0)).sum())
    tn = int(((yt == 0) & (yp == 0)).sum())
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * p * r / (p + r) if p + r else 0.0
    acc = (tp + tn) / len(yt) if len(yt) else 0.0
    return {"precision": p, "recall": r, "f1": f1, "accuracy": acc, "tp": tp, "fp": fp, "fn": fn, "tn": tn}


def auroc(y_true: Sequence[int], scores: Sequence[float]) -> float:
    """Area under the ROC curve via the rank statistic (ties get average ranks)."""
    yt, s = np.asarray(y_true, dtype=int), np.asarray(scores, dtype=float)
    pos, neg = (yt == 1).sum(), (yt == 0).sum()
    if pos == 0 or neg == 0:
        return float("nan")
    from scipy.stats import rankdata

    ranks = rankdata(s)
    return float((ranks[yt == 1].sum() - pos * (pos + 1) / 2) / (pos * neg))


def expected_calibration_error(probs: Sequence[float], outcomes: Sequence[int], n_bins: int = 10) -> float:
    """ECE = sum_b (|B_b| / N) * |acc(B_b) - conf(B_b)| with equal-width bins."""
    p, y = np.asarray(probs, dtype=float), np.asarray(outcomes, dtype=float)
    if len(p) == 0:
        return float("nan")
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    idx = np.clip(np.digitize(p, bins[1:-1], right=True), 0, n_bins - 1)
    ece = 0.0
    for b in range(n_bins):
        m = idx == b
        if m.any():
            ece += m.mean() * abs(y[m].mean() - p[m].mean())
    return float(ece)


def reliability_curve(probs: Sequence[float], outcomes: Sequence[int], n_bins: int = 10
                      ) -> List[Tuple[float, float, int]]:
    p, y = np.asarray(probs, dtype=float), np.asarray(outcomes, dtype=float)
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    idx = np.clip(np.digitize(p, bins[1:-1], right=True), 0, n_bins - 1)
    return [(float(p[idx == b].mean()), float(y[idx == b].mean()), int((idx == b).sum()))
            for b in range(n_bins) if (idx == b).any()]


# ---------------------------------------------------------------------------
# Statistics
# ---------------------------------------------------------------------------

def bootstrap_ci(fn: Callable[[np.ndarray], float], n_items: int, n_boot: int = 1000,
                 alpha: float = 0.05, seed: int = 42) -> Tuple[float, float]:
    """Percentile bootstrap CI; ``fn`` receives an index array sampled with replacement."""
    rng = np.random.default_rng(seed)
    vals = [fn(rng.integers(0, n_items, n_items)) for _ in range(n_boot)]
    return float(np.percentile(vals, 100 * alpha / 2)), float(np.percentile(vals, 100 * (1 - alpha / 2)))


def mcnemar_exact(y_true: Sequence[int], pred_a: Sequence[int], pred_b: Sequence[int]) -> Dict[str, float]:
    """Exact McNemar test on the discordant pairs of correct/incorrect decisions."""
    from scipy.stats import binomtest

    yt, a, b = (np.asarray(x, dtype=int) for x in (y_true, pred_a, pred_b))
    a_ok, b_ok = a == yt, b == yt
    n01 = int((a_ok & ~b_ok).sum())
    n10 = int((~a_ok & b_ok).sum())
    n = n01 + n10
    p = binomtest(n01, n, 0.5).pvalue if n else 1.0
    return {"a_only_correct": n01, "b_only_correct": n10, "p_value": float(p)}


def wilcoxon_paired(x: Sequence[float], y: Sequence[float]) -> Dict[str, float]:
    from scipy.stats import wilcoxon

    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    if np.allclose(x, y):
        return {"statistic": 0.0, "p_value": 1.0}
    res = wilcoxon(x, y, zero_method="wilcox")
    return {"statistic": float(res.statistic), "p_value": float(res.pvalue)}


def benjamini_hochberg(pvalues: Sequence[float]) -> List[float]:
    p = np.asarray(pvalues, dtype=float)
    n = len(p)
    order = np.argsort(p)
    adj = np.empty(n)
    prev = 1.0
    for rank, i in reversed(list(enumerate(order, start=1))):
        prev = min(prev, p[i] * n / rank)
        adj[i] = prev
    return adj.tolist()
