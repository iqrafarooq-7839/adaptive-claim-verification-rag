"""Experiment E2: detecting unsupported answers with the adaptive claim verifier (HaluBench).

Shared by scripts/04_verify_halubench.py (real models) and scripts/smoke_test.py (toy models).
"""

from __future__ import annotations

from typing import Callable, Dict, List, Sequence

import numpy as np

from .metrics import auroc, bootstrap_ci, expected_calibration_error, mcnemar_exact, prf, reliability_curve
from .verifier import AdaptiveVerifier, Calibrator, CheapScorer, Item, build_premise, evaluate_offline


def single_claim_training_data(items: Sequence[Item]):
    """Claims of single-claim answers inherit the answer label (supported = 1 - unsupported)."""
    X, y = [], []
    for it in items:
        if len(it.claims) == 1:
            X.append(it.phi[0])
            y.append(1 - int(it.meta["unsupported"]))
    return np.asarray(X), np.asarray(y)


def answer_scores(items: Sequence[Item], res: Dict) -> Dict[str, float]:
    y = [int(it.meta["unsupported"]) for it in items]
    out = prf(y, res["pred"])
    out["auroc"] = auroc(y, res["risk"])
    out["call_rate"] = res["call_rate"]
    out["calls"] = res["calls"]
    return out


def choose_tau(items: Sequence[Item], grid: Sequence[float]) -> float:
    best = max(grid, key=lambda t: answer_scores(items, evaluate_offline(items, "nli", 0.0, t))["f1"])
    return float(best)


def theta_sweep(items: Sequence[Item], grid: Sequence[float], tau: float) -> List[Dict]:
    rows = []
    for th in grid:
        sc = answer_scores(items, evaluate_offline(items, "adaptive", th, tau))
        rows.append({"theta": float(th), **sc})
    return rows


def choose_theta(sweep: Sequence[Dict], cost_weight: float) -> Dict:
    """theta* = argmin (1 - F1) + lambda * call_rate on the dev split (Eq. 1 of the paper)."""
    return min(sweep, key=lambda r: (1 - r["f1"]) + cost_weight * r["call_rate"])


def with_ci(items: Sequence[Item], res: Dict, n_boot: int = 1000, seed: int = 42) -> Dict:
    y = np.asarray([int(it.meta["unsupported"]) for it in items])
    pred = np.asarray(res["pred"])
    sc = answer_scores(items, res)
    lo, hi = bootstrap_ci(lambda idx: prf(y[idx], pred[idx])["f1"], len(y), n_boot=n_boot, seed=seed)
    sc["f1_ci"] = [lo, hi]
    return sc


def run_verifier_experiment(dev: List[Dict], test: List[Dict], embed_fn: Callable, nli, cfg: Dict,
                            nli_factory_m1=None, log: Callable[[str], None] = print) -> Dict:
    """Full E2 protocol. ``dev``/``test`` rows need: id, question, answer, passage, unsupported, source."""
    vc = cfg["verifier"]
    scorer = CheapScorer(embed_fn)
    cal = Calibrator("logistic")
    ver = AdaptiveVerifier(scorer, cal, nli, m=vc["premise_sentences"])

    def prep(rows):
        return [ver.prepare(r["id"], r["question"], r["answer"], r["passage"],
                            meta={"unsupported": r["unsupported"], "source": r.get("source", "")}) for r in rows]

    log("[E2] cheap stage")
    dev_items, test_items = prep(dev), prep(test)
    X, y = single_claim_training_data(dev_items)
    cal.fit(X, y)
    ver.calibrate(dev_items); ver.calibrate(test_items)

    log("[E2] NLI scores for analysis")
    ver.score_all_nli(dev_items); ver.score_all_nli(test_items)

    tau = choose_tau(dev_items, vc["tau_grid"])
    dev_sweep = theta_sweep(dev_items, vc["theta_grid"], tau)
    chosen = choose_theta(dev_sweep, vc["cost_weight"])
    theta = chosen["theta"]
    log(f"[E2] selected on dev: tau={tau:.2f}, theta={theta:.2f}")

    res = {
        "B1_cheap": with_ci(test_items, evaluate_offline(test_items, "cheap", theta, tau)),
        "B2_uniform_nli": with_ci(test_items, evaluate_offline(test_items, "nli", theta, tau)),
        "B3_adaptive": with_ci(test_items, evaluate_offline(test_items, "adaptive", theta, tau)),
    }
    y_test = [int(it.meta["unsupported"]) for it in test_items]
    res["mcnemar_B2_vs_B3"] = mcnemar_exact(y_test, evaluate_offline(test_items, "nli", theta, tau)["pred"],
                                            evaluate_offline(test_items, "adaptive", theta, tau)["pred"])

    # Wall-clock cost of the deployment path (only escalated claims reach the NLI model)
    timing = {}
    for mode in ("cheap", "nli", "adaptive"):
        runs = [ver.run(it, mode, theta, tau) for it in test_items]
        timing[mode] = {"seconds_total": float(sum(r["seconds"] for r in runs)),
                        "seconds_per_answer": float(np.mean([r["seconds"] for r in runs])) if runs else 0.0,
                        "nli_calls": int(sum(r["calls"] for r in runs))}
    res["timing_verification_only"] = timing

    # Calibration quality on single-claim test answers
    Xt, yt = single_claim_training_data(test_items)
    raw = Calibrator("identity").predict(Xt)
    calp = cal.predict(Xt)
    res["calibration"] = {"ece_raw_similarity": expected_calibration_error(raw, yt),
                          "ece_calibrated": expected_calibration_error(calp, yt),
                          "curve_raw": reliability_curve(raw, yt), "curve_calibrated": reliability_curve(calp, yt)}

    # Per-source breakdown for the adaptive verifier
    by_src = {}
    for src in sorted({it.meta["source"] for it in test_items}):
        sub = [it for it in test_items if it.meta["source"] == src]
        by_src[src] = answer_scores(sub, evaluate_offline(sub, "adaptive", theta, tau))
    res["per_source_B3"] = by_src

    # Ablations (all evaluated on test with the same tau/theta selection protocol on dev)
    abl = {}
    for name, calib in (("no_calibration_raw_similarity", Calibrator("identity")),
                        ("similarity_only_logistic", Calibrator("logistic", features=("s_max",))),
                        ("without_entity_number_coverage", Calibrator("logistic", features=("s_max", "s_top3", "lex_cov")))):
        if calib.mode == "logistic":
            calib.fit(X, y)
        for its in (dev_items, test_items):
            for it in its:
                it.meta["p_full"] = it.p
                it.p = calib.predict(it.phi) if it.claims else np.zeros(0)
        sw = theta_sweep(dev_items, vc["theta_grid"], tau)
        th = choose_theta(sw, vc["cost_weight"])["theta"]
        abl[name] = {"theta": th, **answer_scores(test_items, evaluate_offline(test_items, "adaptive", th, tau))}
        for its in (dev_items, test_items):
            for it in its:
                it.p = it.meta.pop("p_full")
    if nli is not None:
        # single best sentence as premise instead of the multi-hop premise
        saved = [(it.premises, it.v) for it in test_items]
        for it in test_items:
            it.premises = [build_premise(it.ctx_sents, it.sims[i], 1) for i in range(len(it.claims))]
        ver.score_all_nli(test_items)
        abl["single_sentence_premise"] = {"theta": theta, **answer_scores(
            test_items, evaluate_offline(test_items, "adaptive", theta, tau))}
        abl["single_sentence_premise_uniform_nli"] = answer_scores(
            test_items, evaluate_offline(test_items, "nli", theta, tau))
        for it, (pr, v) in zip(test_items, saved):
            it.premises, it.v = pr, v
    res["ablations"] = abl

    res["selection"] = {"tau": tau, "theta": theta, "cost_weight": vc["cost_weight"], "dev_sweep": dev_sweep}
    res["test_sweep"] = theta_sweep(test_items, vc["theta_grid"], tau)
    res["n"] = {"dev_answers": len(dev_items), "test_answers": len(test_items),
                "test_claims": int(sum(len(it.claims) for it in test_items)),
                "calibration_examples": int(len(y))}
    res["examples"] = examples_for_paper(test_items, theta, tau)
    return res


def examples_for_paper(items: Sequence[Item], theta: float, tau: float, n: int = 6) -> List[Dict]:
    """A few qualitative cases: escalated-and-caught, accepted-correctly, and errors."""
    out = []
    for it in items:
        if not it.claims:
            continue
        res = evaluate_offline([it], "adaptive", theta, tau)
        out.append({"id": it.uid, "source": it.meta.get("source"), "question": it.question, "answer": it.answer,
                    "gold_unsupported": int(it.meta["unsupported"]), "pred_unsupported": res["pred"][0],
                    "claims": [{"claim": c, "p": round(float(p), 3), "v": round(float(v), 3) if it.v is not None else None}
                               for c, p, v in zip(it.claims, it.p, it.v if it.v is not None else it.p)],
                    "escalated": int(res["calls"])})
    picked, seen = [], set()
    for want in [(1, 1, True), (0, 0, False), (1, 0, None), (0, 1, None)]:
        for e in out:
            key = (e["gold_unsupported"], e["pred_unsupported"])
            if key == want[:2] and (want[2] is None or (e["escalated"] > 0) == want[2]) and e["id"] not in seen:
                picked.append(e); seen.add(e["id"])
                break
    return picked[:n]
