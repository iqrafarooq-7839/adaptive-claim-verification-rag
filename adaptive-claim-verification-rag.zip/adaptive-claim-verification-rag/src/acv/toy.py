"""Lightweight stand-ins for the neural models, used by the tests and the smoke test only.

They let every code path run on a laptop without downloads. Never use them for reported results.
"""

from __future__ import annotations

from typing import Sequence

import numpy as np

from .verifier import content_tokens, context_vocab, coverage, key_tokens


class HashingEmbedder:
    """Character n-gram hashing vectors, L2-normalised (a toy dense encoder)."""

    def __init__(self, n_features: int = 2 ** 12):
        from sklearn.feature_extraction.text import HashingVectorizer

        self.vec = HashingVectorizer(analyzer="char_wb", ngram_range=(3, 4), n_features=n_features,
                                     alternate_sign=False, norm="l2")

    def __call__(self, texts: Sequence[str]) -> np.ndarray:
        return self.vec.transform(list(texts)).toarray().astype(np.float32)

    encode = __call__


class LexicalNLI:
    """Toy entailment: content-token coverage, zeroed when a number or entity is missing."""

    def __init__(self):
        self.calls = 0

    def entail_prob(self, premises: Sequence[str], hypotheses: Sequence[str]) -> np.ndarray:
        self.calls += len(premises)
        out = []
        for p, h in zip(premises, hypotheses):
            vocab = context_vocab([p])
            cov = coverage(content_tokens(h), vocab)
            key = coverage(key_tokens(h), vocab)
            out.append(cov * (1.0 if key == 1.0 else 0.2))
        return np.asarray(out, dtype=float)


def lexical_rerank_scores(query: str, docs: Sequence[str]) -> np.ndarray:
    q = set(content_tokens(query))
    return np.asarray([len(q & set(content_tokens(d))) / (len(q) or 1) for d in docs], dtype=np.float32)
