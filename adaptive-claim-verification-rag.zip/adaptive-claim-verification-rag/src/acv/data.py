"""Dataset loading: HotpotQA (distractor) and HaluBench, plus the sentence-level retrieval corpus."""

from __future__ import annotations

import random
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

from .utils import normalize_text


# ---------------------------------------------------------------------------
# HotpotQA
# ---------------------------------------------------------------------------

def _local_parquet(data_dir: Optional[str], *patterns: str) -> List[str]:
    """Parquet files saved by scripts/00_download_data.py (empty list if they are not there)."""
    if not data_dir:
        return []
    from pathlib import Path

    files: List[str] = []
    for pat in patterns:
        files.extend(str(p) for p in sorted(Path(data_dir).glob(pat)))
    return files


def load_hotpotqa(hf_name: str = "hotpotqa/hotpot_qa", config: str = "distractor",
                  split: str = "train", max_questions: Optional[int] = None,
                  seed: int = 42, data_dir: Optional[str] = None,
                  keep_paragraphs: str = "supporting") -> List[Dict[str, Any]]:
    """Load HotpotQA and flatten each example.

    Local parquet files under ``<data_dir>/hotpot_qa/<config>/`` are used when present (offline),
    otherwise the dataset is downloaded from the Hugging Face hub. ``keep_paragraphs='supporting'``
    drops the eight distractor paragraphs of every question to save memory.
    """
    from datasets import load_dataset

    local = _local_parquet(data_dir, f"hotpot_qa/{config}/{split}-*.parquet")
    if local:
        ds = load_dataset("parquet", data_files=local, split="train")
    else:
        ds = load_dataset(hf_name, config, split=split)
    if max_questions:
        ds = ds.shuffle(seed=seed).select(range(min(max_questions, len(ds))))
    return [hotpot_example_from_hf(ex, keep_paragraphs) for ex in ds]


def _columns(field: Any, keys: Tuple[str, ...]) -> Tuple[list, ...]:
    """HF stores these nested fields as a dict of lists; accept a list of dicts as well."""
    if isinstance(field, dict):
        return tuple(list(field[k]) for k in keys)
    return tuple([row[k] for row in field] for k in keys)


def hotpot_example_from_hf(ex: Dict[str, Any], keep_paragraphs: str = "all") -> Dict[str, Any]:
    titles, sentences = _columns(ex["context"], ("title", "sentences"))
    sf_titles, sf_sent_ids = _columns(ex["supporting_facts"], ("title", "sent_id"))
    if keep_paragraphs == "supporting":
        wanted = set(sf_titles)
        kept = [(t, s) for t, s in zip(titles, sentences) if t in wanted]
        titles, sentences = [t for t, _ in kept], [s for _, s in kept]
    return {
        "id": ex["id"],
        "question": ex["question"],
        "answer": ex["answer"],
        "type": ex.get("type"),
        "level": ex.get("level"),
        "titles": list(titles),
        "sentences": [list(s) for s in sentences],
        "sf_titles": list(sf_titles),
        "sf_sent_ids": [int(i) for i in sf_sent_ids],
    }


def build_sentence_corpus(examples: List[Dict[str, Any]], paragraphs: str = "supporting"
                          ) -> Tuple[List[str], List[str], Dict[str, Dict[str, int]]]:
    """Build the pooled sentence-level corpus and the relevance judgements (qrels).

    Each sentence is one document; identical sentences (after normalisation) are stored once,
    as in the base repository. ``paragraphs='supporting'`` uses the sentences of the two
    supporting paragraphs of every question (base repository); ``'all'`` also adds the eight
    distractor paragraphs. Relevant documents are the annotated supporting sentences.
    """
    if paragraphs not in {"supporting", "all"}:
        raise ValueError("paragraphs must be 'supporting' or 'all'")
    key_to_id: Dict[str, str] = {}
    texts: List[str] = []
    qrels: Dict[str, Dict[str, int]] = {}

    def add(sentence: str) -> Optional[str]:
        key = normalize_text(sentence)
        if not key:
            return None
        if key not in key_to_id:
            key_to_id[key] = f"d{len(texts)}"
            texts.append(sentence.strip())
        return key_to_id[key]

    for ex in examples:
        sf = set(ex["sf_titles"])
        para = dict(zip(ex["titles"], ex["sentences"]))
        for title, sents in zip(ex["titles"], ex["sentences"]):
            if paragraphs == "supporting" and title not in sf:
                continue
            for s in sents:
                add(s)
        rel: Dict[str, int] = {}
        for title, sid in zip(ex["sf_titles"], ex["sf_sent_ids"]):
            sents = para.get(title, [])
            if 0 <= sid < len(sents):  # a few HotpotQA annotations point past the paragraph end
                doc_id = key_to_id.get(normalize_text(sents[sid]))
                if doc_id:
                    rel[doc_id] = 1
        qrels[ex["id"]] = rel
    doc_ids = [f"d{i}" for i in range(len(texts))]
    return doc_ids, texts, qrels


def sample_examples(examples: List[Dict[str, Any]], n: int, seed: int = 42) -> List[Dict[str, Any]]:
    rng = random.Random(seed)
    idx = list(range(len(examples)))
    rng.shuffle(idx)
    return [examples[i] for i in sorted(idx[: min(n, len(idx))])]


# ---------------------------------------------------------------------------
# HaluBench
# ---------------------------------------------------------------------------

def load_halubench(hf_name: str = "PatronusAI/HaluBench", per_source: Optional[int] = 200,
                   seed: int = 42, data_dir: Optional[str] = None) -> List[Dict[str, Any]]:
    """Load HaluBench (one split, 14,900 rows, six sources), clean it, and draw a stratified sample.

    Cleaning follows the base paper: drop rows with missing fields and exact duplicates.
    ``unsupported`` is 1 for answers labelled FAIL (hallucinated) and 0 for PASS.
    Local parquet files under ``<data_dir>/halubench/`` are used when present.
    """
    from datasets import load_dataset

    local = _local_parquet(data_dir, "halubench/data/*.parquet", "halubench/*.parquet")
    if local:
        rows = [dict(r) for r in load_dataset("parquet", data_files=local, split="train")]
    else:
        dsd = load_dataset(hf_name)
        split = "test" if "test" in dsd else list(dsd.keys())[0]
        rows = [dict(r) for r in dsd[split]]
    return clean_and_sample_halubench(rows, per_source, seed)


def halubench_label(value: Any) -> Optional[int]:
    s = str(value).strip().upper()
    if s.startswith("FAIL") or s in {"1", "TRUE", "HALLUCINATED"}:
        return 1
    if s.startswith("PASS") or s in {"0", "FALSE", "FAITHFUL"}:
        return 0
    return None


def clean_and_sample_halubench(rows: List[Dict[str, Any]], per_source: Optional[int] = 200,
                               seed: int = 42) -> List[Dict[str, Any]]:
    seen = set()
    by_source: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in rows:
        passage, question, answer = r.get("passage"), r.get("question"), r.get("answer")
        label = halubench_label(r.get("label"))
        if not passage or not question or answer is None or str(answer).strip() == "" or label is None:
            continue
        key = (normalize_text(passage), normalize_text(question), normalize_text(str(answer)))
        if key in seen:
            continue
        seen.add(key)
        by_source[str(r.get("source_ds", "unknown"))].append({
            "id": str(r.get("id", len(seen))),
            "source": str(r.get("source_ds", "unknown")),
            "passage": str(passage),
            "question": str(question),
            "answer": str(answer),
            "unsupported": label,
        })
    rng = random.Random(seed)
    out: List[Dict[str, Any]] = []
    for source in sorted(by_source):
        items = by_source[source]
        rng.shuffle(items)
        out.extend(items if per_source is None else items[:per_source])
    return out


def split_dev_test(items: List[Dict[str, Any]], dev_fraction: float, seed: int = 42,
                   stratify_key: str = "source") -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Stratified, non-overlapping dev/test split (dev is used only for fitting and tuning)."""
    rng = random.Random(seed)
    groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for it in items:
        groups[str(it.get(stratify_key, "all"))].append(it)
    dev, test = [], []
    for g in sorted(groups):
        members = groups[g][:]
        rng.shuffle(members)
        k = int(round(len(members) * dev_fraction))
        dev.extend(members[:k])
        test.extend(members[k:])
    return dev, test
