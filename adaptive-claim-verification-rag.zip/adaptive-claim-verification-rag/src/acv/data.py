"""Dataset loading: HotpotQA (distractor) and HaluBench, plus the sentence-level retrieval corpus."""

from __future__ import annotations

import random
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

from .utils import normalize_text


# ---------------------------------------------------------------------------
# HotpotQA
# ---------------------------------------------------------------------------

def load_hotpotqa(hf_name: str = "hotpotqa/hotpot_qa", config: str = "distractor",
                  split: str = "train", max_questions: Optional[int] = None,
                  seed: int = 42) -> List[Dict[str, Any]]:
    """Load HotpotQA from the Hugging Face hub and flatten each example."""
    from datasets import load_dataset

    ds = load_dataset(hf_name, config, split=split)
    if max_questions:
        ds = ds.shuffle(seed=seed).select(range(min(max_questions, len(ds))))
    return [hotpot_example_from_hf(ex) for ex in ds]


def hotpot_example_from_hf(ex: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": ex["id"],
        "question": ex["question"],
        "answer": ex["answer"],
        "type": ex.get("type"),
        "level": ex.get("level"),
        "titles": list(ex["context"]["title"]),
        "sentences": [list(s) for s in ex["context"]["sentences"]],
        "sf_titles": list(ex["supporting_facts"]["title"]),
        "sf_sent_ids": [int(i) for i in ex["supporting_facts"]["sent_id"]],
    }


def build_sentence_corpus(examples: List[Dict[str, Any]], paragraphs: str = "supporting"
                          ) -> Tuple[List[str], List[str], Dict[str, Dict[str, int]]]:
    """Build the pooled sentence-level corpus and the relevance judgements (qrels).

    Each sentence is one document; identical sentences (after normalisation) are stored once,
    as in the base repository. ``paragraphs='supporting'`` uses the sentences of the two
    supporting paragraphs of every question (base repository); ``'all'`` also adds the eight
    distractor paragraphs. Relevant documents are the annotated supporting sentences.
    """
    if paragraphs not in {"supporting", "all"}:
        raise ValueError("paragraphs must be 'supporting' or 'all'")
    key_to_id: Dict[str, str] = {}
    texts: List[str] = []
    qrels: Dict[str, Dict[str, int]] = {}

    def add(sentence: str) -> Optional[str]:
        key = normalize_text(sentence)
        if not key:
            return None
        if key not in key_to_id:
            key_to_id[key] = f"d{len(texts)}"
            texts.append(sentence.strip())
        return key_to_id[key]

    for ex in examples:
        sf = set(ex["sf_titles"])
        para = dict(zip(ex["titles"], ex["sentences"]))
        for title, sents in zip(ex["titles"], ex["sentences"]):
            if paragraphs == "supporting" and title not in sf:
                continue
            for s in sents:
                add(s)
        rel: Dict[str, int] = {}
        for title, sid in zip(ex["sf_titles"], ex["sf_sent_ids"]):
            sents = para.get(title, [])
            if 0 <= sid < len(sents):  # a few HotpotQA annotations point past the paragraph end
                doc_id = key_to_id.get(normalize_text(sents[sid]))
                if doc_id:
                    rel[doc_id] = 1
        qrels[ex["id"]] = rel
    doc_ids = [f"d{i}" for i in range(len(texts))]
    return doc_ids, texts, qrels


def sample_examples(examples: List[Dict[str, Any]], n: int, seed: int = 42) -> List[Dict[str, Any]]:
    rng = random.Random(seed)
    idx = list(range(len(examples)))
    rng.shuffle(idx)
    return [examples[i] for i in sorted(idx[: min(n, len(idx))])]


# ---------------------------------------------------------------------------
# HaluBench
# ---------------------------------------------------------------------------

def load_halubench(hf_name: str = "PatronusAI/HaluBench", per_source: Optional[int] = 200,
                   seed: int = 42) -> List[Dict[str, Any]]:
    """Load HaluBench, clean it, and draw a stratified sample per source dataset.

    Cleaning follows the base paper: drop rows with missing fields and exact duplicates.
    ``unsupported`` is 1 for answers labelled FAIL (hallucinated) and 0 for PASS.
    """
    from datasets import load_dataset

    dsd = load_dataset(hf_name)
    split = "test" if "test" in dsd else list(dsd.keys())[0]
    return clean_and_sample_halubench([dict(r) for r in dsd[split]], per_source, seed)


def halubench_label(value: Any) -> Optional[int]:
    s = str(value).strip().upper()
    if s.startswith("FAIL") or s in {"1", "TRUE", "HALLUCINATED"}:
        return 1
    if s.startswith("PASS") or s in {"0", "FALSE", "FAITHFUL"}:
        return 0
    return None


def clean_and_sample_halubench(rows: List[Dict[str, Any]], per_source: Optional[int] = 200,
                               seed: int = 42) -> List[Dict[str, Any]]:
    seen = set()
    by_source: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in rows:
        passage, question, answer = r.get("passage"), r.get("question"), r.get("answer")
        label = halubench_label(r.get("label"))
        if not passage or not question or answer is None or str(answer).strip() == "" or label is None:
            continue
        key = (normalize_text(passage), normalize_text(question), normalize_text(str(answer)))
        if key in seen:
            continue
        seen.add(key)
        by_source[str(r.get("source_ds", "unknown"))].append({
            "id": str(r.get("id", len(seen))),
            "source": str(r.get("source_ds", "unknown")),
            "passage": str(passage),
            "question": str(question),
            "answer": str(answer),
            "unsupported": label,
        })
    rng = random.Random(seed)
    out: List[Dict[str, Any]] = []
    for source in sorted(by_source):
        items = by_source[source]
        rng.shuffle(items)
        out.extend(items if per_source is None else items[:per_source])
    return out


def split_dev_test(items: List[Dict[str, Any]], dev_fraction: float, seed: int = 42,
                   stratify_key: str = "source") -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Stratified, non-overlapping dev/test split (dev is used only for fitting and tuning)."""
    rng = random.Random(seed)
    groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for it in items:
        groups[str(it.get(stratify_key, "all"))].append(it)
    dev, test = [], []
    for g in sorted(groups):
        members = groups[g][:]
        rng.shuffle(members)
        k = int(round(len(members) * dev_fraction))
        dev.extend(members[:k])
        test.extend(members[k:])
    return dev, test
