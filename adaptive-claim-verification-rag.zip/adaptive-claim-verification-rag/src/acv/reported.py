"""Numbers reported by the base paper (Mala et al., Machine Learning 115, art. 187, 2026),
copied from its Tables 1, 3 and 5 for side-by-side comparison with the reproduction."""

# Table 1: retrieval on HotpotQA (distractor, train split, sentence-level corpus)
TABLE1_HOTPOTQA = {
    "bm25":       {"MAP@3": 0.2660, "MAP@5": 0.2776, "MAP@10": 0.2847, "NDCG@3": 0.3304, "NDCG@5": 0.3428, "NDCG@10": 0.3562},
    "splade":     {"MAP@3": 0.2819, "MAP@5": 0.2945, "MAP@10": 0.3019, "NDCG@3": 0.3493, "NDCG@5": 0.3622, "NDCG@10": 0.3756},
    "mpnet":      {"MAP@3": 0.2020, "MAP@5": 0.2127, "MAP@10": 0.2202, "NDCG@3": 0.2580, "NDCG@5": 0.2712, "NDCG@10": 0.2864},
    "contriever": {"MAP@3": 0.1998, "MAP@5": 0.2128, "MAP@10": 0.2209, "NDCG@3": 0.2583, "NDCG@5": 0.2743, "NDCG@10": 0.2903},
    "mpnet_qa":   {"MAP@3": 0.1677, "MAP@5": 0.1765, "MAP@10": 0.1828, "NDCG@3": 0.2149, "NDCG@5": 0.2267, "NDCG@10": 0.2403},
}

# Table 3: hybrid retrieval on HotpotQA
TABLE3_HOTPOTQA = {
    "hybrid_rrf":       {"MAP@3": 0.2566, "MAP@5": 0.2735, "MAP@10": 0.2824, "NDCG@3": 0.3225, "NDCG@5": 0.3425, "NDCG@10": 0.3589},
    "hybrid_combmnz":   {"MAP@3": 0.2615, "MAP@5": 0.2763, "MAP@10": 0.2850, "NDCG@3": 0.3281, "NDCG@5": 0.3448, "NDCG@10": 0.3606},
    "hybrid_li":        {"MAP@3": 0.2822, "MAP@5": 0.2949, "MAP@10": 0.3022, "NDCG@3": 0.3501, "NDCG@5": 0.3629, "NDCG@10": 0.3762},
    "hybrid_li_rerank": {"MAP@3": 0.2954, "MAP@5": 0.3073, "MAP@10": 0.3139, "NDCG@3": 0.3628, "NDCG@5": 0.3743, "NDCG@10": 0.3863},
}

# Table 5: end-to-end results on HotpotQA (1,200 questions, Claude Sonnet 4.5 as judge), percent
TABLE5_HOTPOTQA = {
    ("contriever", "gemma2_2b"):        {"accuracy": 0.33,  "hallucination_rate": 0.42,  "rejection_rate": 99.25, "adjusted_accuracy": 44.44},
    ("hybrid_li_rerank", "gemma2_2b"):  {"accuracy": 9.05,  "hallucination_rate": 30.82, "rejection_rate": 60.13, "adjusted_accuracy": 22.69},
    ("contriever", "qwen3_4b"):         {"accuracy": 37.78, "hallucination_rate": 9.34,  "rejection_rate": 52.88, "adjusted_accuracy": 80.18},
    ("hybrid_li_rerank", "qwen3_4b"):   {"accuracy": 49.25, "hallucination_rate": 16.00, "rejection_rate": 34.75, "adjusted_accuracy": 75.48},
    ("contriever", "llama31_8b"):       {"accuracy": 37.92, "hallucination_rate": 13.42, "rejection_rate": 48.67, "adjusted_accuracy": 73.86},
    ("hybrid_li_rerank", "llama31_8b"): {"accuracy": 46.29, "hallucination_rate": 16.68, "rejection_rate": 37.03, "adjusted_accuracy": 73.51},
}
