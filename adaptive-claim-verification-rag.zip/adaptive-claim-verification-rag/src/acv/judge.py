"""LLM-as-a-judge.

``judge_answer`` reproduces the base paper's three-way label (Correct / Hallucinated /
Insufficient Context) by comparing the generated answer with the ground truth.
``judge_claim`` produces reference labels for the proposed claim-level experiments
(Supported / Unsupported with respect to the retrieved context).

Two interchangeable backends:
  * ``AnthropicJudge``: the Claude API, as in the base paper (needs ANTHROPIC_API_KEY, costs a few dollars);
  * ``HFJudge``: an open-weight chat model run locally on the GPU (free; a documented deviation).
Results are cached on disk, so re-running a script never repeats a call.
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

ANSWER_LABELS = ("Correct", "Hallucinated", "Insufficient Context")
CLAIM_LABELS = ("Supported", "Unsupported")

ANSWER_SYSTEM = (
    "You are an impartial evaluator (LLM-as-a-Judge) of model-generated answers to questions.\n"
    "You receive a question, a model-generated answer and a ground-truth reference answer.\n"
    "Assign exactly one label:\n"
    "1. Correct: the generated answer semantically matches the ground-truth answer.\n"
    "2. Hallucinated: the generated answer contradicts or diverges from the ground-truth answer.\n"
    "3. Insufficient Context: the generated answer states that the context does not provide "
    "sufficient information (or an equivalent phrase) instead of answering.\n\n"
    "Return exactly one JSON object: {\"label\": one of [\"Correct\", \"Hallucinated\", "
    "\"Insufficient Context\"], \"explanation\": one short sentence}."
)

CLAIM_SYSTEM = (
    "You check whether a claim is supported by a given context.\n"
    "Use only the context, not outside knowledge. A claim is Supported only if every part of it "
    "follows from the context (combining several context sentences is allowed). Otherwise it is "
    "Unsupported, including when the context is silent about it.\n\n"
    "Return exactly one JSON object: {\"label\": \"Supported\" or \"Unsupported\", "
    "\"explanation\": one short sentence}."
)


def answer_prompt(question: str, generated: str, gold: str) -> str:
    return (f"QUESTION: {question}\n\nMODEL-GENERATED ANSWER: {generated}\n\n"
            f"GROUND-TRUTH ANSWER: {gold}\n\nCompare the generated answer with the ground-truth "
            "answer and return the JSON object.")


def claim_prompt(context: str, claim: str) -> str:
    return f"CONTEXT:\n{context}\n\nCLAIM: {claim}\n\nReturn the JSON object."


def parse_label(text: str, allowed: Sequence[str]) -> Dict[str, Optional[str]]:
    """Extract the label from a JSON reply; returns label None when it is missing or invalid."""
    label, expl = None, None
    m = re.search(r"\{.*?\}", text or "", flags=re.S)
    if m:
        try:
            obj = json.loads(m.group(0))
            label, expl = obj.get("label"), obj.get("explanation")
        except json.JSONDecodeError:
            pass
    if label is None:
        m2 = re.search(r"\"?label\"?\s*[:=]\s*\"?([A-Za-z ]+)", text or "", flags=re.I)
        if m2:
            label = m2.group(1).strip()
    if label is None:
        # longest label first, so "Unsupported" is not read as "Supported"
        for a in sorted(allowed, key=len, reverse=True):
            if re.search(rf"\b{re.escape(a)}\b", text or "", flags=re.I):
                label = a
                break
    if label is not None:
        canon = {a.lower(): a for a in allowed}
        label = canon.get(str(label).strip().lower())
    return {"label": label, "explanation": expl}


class _CachedJudge:
    """Shared logic: on-disk cache keyed by (model, system prompt, user prompt)."""

    name = "judge"

    def __init__(self, model: str, cache_dir: Optional[str] = None):
        self.model = model
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", model)
        self.cache_path = Path(cache_dir) / f"{safe}.jsonl" if cache_dir else None
        self.cache: Dict[str, Dict] = {}
        if self.cache_path and self.cache_path.exists():
            for line in self.cache_path.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    try:
                        row = json.loads(line)
                        self.cache[row["key"]] = row["value"]
                    except (json.JSONDecodeError, KeyError):
                        continue  # a line cut off when a session was killed

    def _key(self, system: str, user: str) -> str:
        return hashlib.sha1(f"{self.model}\n{system}\n{user}".encode("utf-8")).hexdigest()

    def _store(self, key: str, value: Dict) -> None:
        self.cache[key] = value
        if self.cache_path:
            self.cache_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.cache_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps({"key": key, "value": value}) + "\n")

    def _complete(self, pairs: List[Tuple[str, str]]) -> List[Dict]:
        """Return [{'text': ..., 'stop_reason': ...}] for uncached (system, user) pairs."""
        raise NotImplementedError

    def _run(self, pairs: List[Tuple[str, str]]) -> List[Dict]:
        keys = [self._key(s, u) for s, u in pairs]
        todo = [(k, p) for k, p in dict(zip(keys, pairs)).items() if k not in self.cache]
        if todo:
            for (k, _), value in zip(todo, self._complete([p for _, p in todo])):
                if not str(value.get("stop_reason") or "").startswith("error"):
                    self._store(k, value)
                else:
                    self.cache.setdefault(k, value)
        return [self.cache[k] for k in keys]

    def _labels(self, pairs, allowed) -> List[Dict[str, Optional[str]]]:
        out = []
        for raw in self._run(pairs):
            res = parse_label(raw["text"], allowed)
            res["stop_reason"] = raw.get("stop_reason")
            if raw.get("stop_reason") == "refusal":
                res["label"] = None  # discarded, as in the base paper
            out.append(res)
        return out

    # batch interface
    def judge_answers(self, triples: Sequence[Tuple[str, str, str]]) -> List[Dict[str, Optional[str]]]:
        return self._labels([(ANSWER_SYSTEM, answer_prompt(q, g, gold)) for q, g, gold in triples], ANSWER_LABELS)

    def judge_claims(self, pairs: Sequence[Tuple[str, str]]) -> List[Dict[str, Optional[str]]]:
        return self._labels([(CLAIM_SYSTEM, claim_prompt(c, claim)) for c, claim in pairs], CLAIM_LABELS)

    # single-item interface
    def judge_answer(self, question: str, generated: str, gold: str) -> Dict[str, Optional[str]]:
        return self.judge_answers([(question, generated, gold)])[0]

    def judge_claim(self, context: str, claim: str) -> Dict[str, Optional[str]]:
        return self.judge_claims([(context, claim)])[0]


class AnthropicJudge(_CachedJudge):
    name = "anthropic"

    def __init__(self, model: str, max_tokens: int = 300, cache_dir: Optional[str] = None,
                 client=None, max_retries: int = 5):
        super().__init__(model, cache_dir)
        if client is None:
            import anthropic

            client = anthropic.Anthropic()
        self.client, self.max_tokens, self.max_retries = client, max_tokens, max_retries

    @staticmethod
    def _retryable(exc: Exception) -> bool:
        status = getattr(exc, "status_code", None)
        if status is not None:
            return status in (408, 409, 429) or status >= 500
        return any(w in type(exc).__name__ for w in ("Connection", "Timeout"))

    def _one(self, system: str, user: str) -> Dict:
        delay = 2.0
        for attempt in range(self.max_retries):
            try:
                resp = self.client.messages.create(model=self.model, max_tokens=self.max_tokens, system=system,
                                                   messages=[{"role": "user", "content": user}])
                text = "".join(getattr(b, "text", "") for b in resp.content if getattr(b, "type", "text") == "text")
                return {"text": text, "stop_reason": getattr(resp, "stop_reason", None)}
            except Exception as exc:
                if not self._retryable(exc):
                    # wrong/missing key, retired model, no credit ...: stop at once instead of retrying 1000s of calls
                    raise RuntimeError(
                        f"Judge call failed and will not succeed on retry ({type(exc).__name__}: {exc}). "
                        "Check ANTHROPIC_API_KEY, your credit balance and the model id "
                        f"('{self.model}'; claude-sonnet-4-5 retires on 30 Nov 2026, then use "
                        "--model-id claude-sonnet-5-5), or run with --backend hf for the free local judge.") from exc
                if attempt == self.max_retries - 1:
                    return {"text": "", "stop_reason": f"error: {type(exc).__name__}"}
                time.sleep(delay)
                delay *= 2
        return {"text": "", "stop_reason": "error: unknown"}

    def _complete(self, pairs):
        return [self._one(s, u) for s, u in pairs]


class HFJudge(_CachedJudge):
    """Open-weight chat model as judge (greedy decoding, chat template when the tokenizer has one)."""

    name = "hf"

    def __init__(self, model: str, max_new_tokens: int = 80, cache_dir: Optional[str] = None,
                 load_in_4bit: bool = True, dtype: str = "auto", batch_size: int = 8,
                 max_input_chars: int = 12000, tok=None, lm=None):
        super().__init__(model, cache_dir)
        if tok is None or lm is None:
            from .generation import load_causal_lm

            tok, lm, _ = load_causal_lm(model, dtype=dtype, load_in_4bit=load_in_4bit)
        self.tok, self.lm = tok, lm
        self.max_new_tokens, self.batch_size, self.max_input_chars = max_new_tokens, batch_size, max_input_chars

    def _format(self, system: str, user: str) -> str:
        user = user[: self.max_input_chars]
        messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        if getattr(self.tok, "chat_template", None):
            try:
                return self.tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            except Exception:  # some templates reject a system role
                merged = [{"role": "user", "content": system + "\n\n" + user}]
                return self.tok.apply_chat_template(merged, tokenize=False, add_generation_prompt=True)
        return f"{system}\n\n{user}\n\nJSON:"

    def _complete(self, pairs):
        from .generation import greedy_generate

        prompts = [self._format(s, u) for s, u in pairs]
        order = sorted(range(len(prompts)), key=lambda i: len(prompts[i]))
        texts = greedy_generate(self.tok, self.lm, [prompts[i] for i in order], self.max_new_tokens, self.batch_size)
        out: List[Dict] = [{}] * len(prompts)
        for i, t in zip(order, texts):
            out[i] = {"text": t, "stop_reason": "end_turn"}
        return out


def make_judge(cfg: Dict, backend: Optional[str] = None, model_id: Optional[str] = None):
    """Build the judge named in the config (``judge.backend``: 'anthropic' or 'hf')."""
    jc = cfg["judge"]
    backend = (backend or jc.get("backend", "anthropic")).lower()
    if backend == "anthropic":
        return AnthropicJudge(model_id or jc["model"], jc.get("max_tokens", 300), jc.get("cache_dir"))
    if backend == "hf":
        return HFJudge(model_id or jc["hf_model"], jc.get("hf_max_new_tokens", 80), jc.get("cache_dir"),
                       load_in_4bit=jc.get("hf_load_in_4bit", True), dtype=jc.get("hf_dtype", "auto"),
                       batch_size=jc.get("hf_batch_size", 8))
    raise ValueError(f"unknown judge backend {backend!r} (use 'anthropic' or 'hf')")
