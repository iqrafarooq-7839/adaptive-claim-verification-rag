"""LLM-as-a-judge through the Anthropic API.

``judge_answer`` reproduces the base paper's three-way label (Correct / Hallucinated /
Insufficient Context) by comparing the generated answer with the ground truth.
``judge_claim`` produces reference labels for the proposed claim-level experiments
(Supported / Unsupported with respect to the retrieved context).

Results are cached on disk, so re-running a script never pays twice for the same call.
Set the ANTHROPIC_API_KEY environment variable before use.
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from pathlib import Path
from typing import Dict, Optional, Sequence

ANSWER_LABELS = ("Correct", "Hallucinated", "Insufficient Context")
CLAIM_LABELS = ("Supported", "Unsupported")

ANSWER_SYSTEM = (
    "You are an impartial evaluator (LLM-as-a-Judge) of model-generated answers to questions.\n"
    "You receive a question, a model-generated answer and a ground-truth reference answer.\n"
    "Assign exactly one label:\n"
    "1. Correct: the generated answer semantically matches the ground-truth answer.\n"
    "2. Hallucinated: the generated answer contradicts or diverges from the ground-truth answer.\n"
    "3. Insufficient Context: the generated answer states that the context does not provide "
    "sufficient information (or an equivalent phrase) instead of answering.\n\n"
    "Return exactly one JSON object: {\"label\": one of [\"Correct\", \"Hallucinated\", "
    "\"Insufficient Context\"], \"explanation\": one short sentence}."
)

CLAIM_SYSTEM = (
    "You check whether a claim is supported by a given context.\n"
    "Use only the context, not outside knowledge. A claim is Supported only if every part of it "
    "follows from the context (combining several context sentences is allowed). Otherwise it is "
    "Unsupported, including when the context is silent about it.\n\n"
    "Return exactly one JSON object: {\"label\": \"Supported\" or \"Unsupported\", "
    "\"explanation\": one short sentence}."
)


def parse_label(text: str, allowed: Sequence[str]) -> Dict[str, Optional[str]]:
    """Extract the label from a JSON reply; returns label None when it is missing or invalid."""
    label, expl = None, None
    m = re.search(r"\{.*\}", text or "", flags=re.S)
    if m:
        try:
            obj = json.loads(m.group(0))
            label, expl = obj.get("label"), obj.get("explanation")
        except json.JSONDecodeError:
            pass
    if label is None:
        for a in allowed:
            if re.search(rf"\b{re.escape(a)}\b", text or "", flags=re.I):
                label = a
                break
    if label is not None:
        canon = {a.lower(): a for a in allowed}
        label = canon.get(str(label).strip().lower())
    return {"label": label, "explanation": expl}


class AnthropicJudge:
    def __init__(self, model: str, max_tokens: int = 300, cache_dir: Optional[str] = None,
                 client=None, max_retries: int = 5):
        if client is None:
            import anthropic

            client = anthropic.Anthropic()
        self.client, self.model, self.max_tokens, self.max_retries = client, model, max_tokens, max_retries
        self.cache_path = Path(cache_dir) / f"{model}.jsonl" if cache_dir else None
        self.cache: Dict[str, Dict] = {}
        if self.cache_path and self.cache_path.exists():
            for line in self.cache_path.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    row = json.loads(line)
                    self.cache[row["key"]] = row["value"]

    def _key(self, system: str, user: str) -> str:
        return hashlib.sha1(f"{self.model}\n{system}\n{user}".encode("utf-8")).hexdigest()

    def _call(self, system: str, user: str) -> Dict[str, Optional[str]]:
        key = self._key(system, user)
        if key in self.cache:
            return self.cache[key]
        delay = 2.0
        for attempt in range(self.max_retries):
            try:
                resp = self.client.messages.create(model=self.model, max_tokens=self.max_tokens,
                                                   system=system,
                                                   messages=[{"role": "user", "content": user}])
                text = "".join(getattr(b, "text", "") for b in resp.content
                               if getattr(b, "type", "text") == "text")
                value = {"text": text, "stop_reason": getattr(resp, "stop_reason", None)}
                break
            except Exception as exc:  # rate limits, overload, network
                if attempt == self.max_retries - 1:
                    value = {"text": "", "stop_reason": f"error: {type(exc).__name__}"}
                    break
                time.sleep(delay)
                delay *= 2
        if not value["stop_reason"] or not str(value["stop_reason"]).startswith("error"):
            self.cache[key] = value
            if self.cache_path:
                self.cache_path.parent.mkdir(parents=True, exist_ok=True)
                with open(self.cache_path, "a", encoding="utf-8") as fh:
                    fh.write(json.dumps({"key": key, "value": value}) + "\n")
        return value

    def judge_answer(self, question: str, generated: str, gold: str) -> Dict[str, Optional[str]]:
        user = (f"QUESTION: {question}\n\nMODEL-GENERATED ANSWER: {generated}\n\n"
                f"GROUND-TRUTH ANSWER: {gold}\n\nCompare the generated answer with the ground-truth "
                "answer and return the JSON object.")
        raw = self._call(ANSWER_SYSTEM, user)
        out = parse_label(raw["text"], ANSWER_LABELS)
        out["stop_reason"] = raw["stop_reason"]
        if raw["stop_reason"] == "refusal":
            out["label"] = None  # discarded, as in the base paper
        return out

    def judge_claim(self, context: str, claim: str) -> Dict[str, Optional[str]]:
        user = f"CONTEXT:\n{context}\n\nCLAIM: {claim}\n\nReturn the JSON object."
        raw = self._call(CLAIM_SYSTEM, user)
        out = parse_label(raw["text"], CLAIM_LABELS)
        out["stop_reason"] = raw["stop_reason"]
        if raw["stop_reason"] == "refusal":
            out["label"] = None
        return out
