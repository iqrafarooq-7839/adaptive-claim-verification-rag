"""Adaptive claim-level evidence verification for multi-hop retrieval-augmented generation."""

__version__ = "0.1.0"
