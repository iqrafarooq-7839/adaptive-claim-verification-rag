"""Optional safety net for free GPU sessions: mirror ``outputs/`` in a private Hugging Face dataset repo.

Free sessions (Kaggle, Colab) can end at any time and their disks are wiped. When syncing is on,
every script uploads its results after each finished step and a new session starts by pulling them
back, so finished work is never repeated.

Turn it on by setting the environment variable ACV_SYNC=1 and providing an HF token with *write*
permission (HF_TOKEN). The repo defaults to ``<your user name>/acv-outputs`` and is created private.
Syncing is best-effort: a failed upload prints a warning and never stops an experiment.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, Optional


def enabled() -> bool:
    return os.environ.get("ACV_SYNC", "0") == "1"


def _repo_id(cfg: Dict, api) -> str:
    repo = os.environ.get("ACV_HF_REPO") or (cfg.get("sync") or {}).get("hf_repo")
    if repo:
        return repo
    return f"{api.whoami()['name']}/acv-outputs"


def push(cfg: Dict, message: str = "update outputs") -> Optional[str]:
    """Upload outputs/ (only changed files are transferred). Returns the repo id or None."""
    if not enabled():
        return None
    out_dir = Path(cfg["paths"]["out_dir"])
    if not out_dir.exists():
        return None
    try:
        from huggingface_hub import HfApi

        api = HfApi()
        repo = _repo_id(cfg, api)
        api.create_repo(repo, repo_type="dataset", private=True, exist_ok=True)
        api.upload_folder(folder_path=str(out_dir), repo_id=repo, repo_type="dataset",
                          commit_message=message, ignore_patterns=["*.tmp", "**/*.tmp"])
        print(f"[sync] outputs saved to https://huggingface.co/datasets/{repo} ({message})")
        return repo
    except Exception as exc:  # never let a sync problem kill a long run
        print(f"[sync] WARNING: could not upload outputs ({type(exc).__name__}: {exc})")
        return None


def pull(cfg: Dict) -> Optional[str]:
    """Download previously saved outputs into outputs/ (no-op if the repo does not exist yet)."""
    if not enabled():
        return None
    try:
        from huggingface_hub import HfApi, snapshot_download

        api = HfApi()
        repo = _repo_id(cfg, api)
        if not api.repo_exists(repo, repo_type="dataset"):
            print(f"[sync] no saved outputs yet ({repo} will be created on the first upload)")
            return None
        out_dir = Path(cfg["paths"]["out_dir"])
        out_dir.mkdir(parents=True, exist_ok=True)
        snapshot_download(repo_id=repo, repo_type="dataset", local_dir=str(out_dir))
        print(f"[sync] restored outputs from https://huggingface.co/datasets/{repo}")
        return repo
    except Exception as exc:
        print(f"[sync] WARNING: could not restore outputs ({type(exc).__name__}: {exc})")
        return None
