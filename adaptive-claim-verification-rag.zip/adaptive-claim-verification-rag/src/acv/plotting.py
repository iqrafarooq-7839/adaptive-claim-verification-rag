"""Plain black-and-white figures in Times New Roman (journal style, no colour)."""

from __future__ import annotations

import warnings
from typing import Dict, List, Optional, Sequence, Tuple

SERIF_STACK = ["Times New Roman", "Times", "Liberation Serif", "TeX Gyre Termes", "Nimbus Roman",
               "Nimbus Roman No9 L", "DejaVu Serif"]
HATCHES = ["", "///", "...", "xxx", "\\\\\\", "---", "+++"]
GRAYS = ["white", "0.85", "0.6", "0.35", "black"]
MARKERS = ["o", "s", "^", "D", "v", "x"]


def setup_style() -> str:
    """Configure matplotlib; returns the font actually used (warns if Times New Roman is missing)."""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager

    available = {f.name for f in font_manager.fontManager.ttflist}
    chosen = next((f for f in SERIF_STACK if f in available), "serif")
    if chosen != "Times New Roman":
        warnings.warn(f"Times New Roman is not installed; using '{chosen}'. Install it "
                      "(e.g. ttf-mscorefonts-installer on Ubuntu) for exact Times New Roman.")
    plt.rcParams.update({
        "font.family": "serif", "font.serif": [chosen] + SERIF_STACK, "font.size": 10,
        "mathtext.fontset": "stix", "axes.edgecolor": "black", "axes.labelcolor": "black",
        "axes.linewidth": 0.8, "axes.grid": False, "xtick.color": "black", "ytick.color": "black",
        "text.color": "black", "lines.color": "black", "patch.edgecolor": "black",
        "figure.facecolor": "white", "axes.facecolor": "white", "savefig.facecolor": "white",
        "legend.frameon": False, "pdf.fonttype": 42, "ps.fonttype": 42, "savefig.dpi": 300,
        "axes.prop_cycle": matplotlib.cycler(color=["black"]),
    })
    return chosen


def _save(fig, path: str) -> None:
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    if path.endswith(".pdf"):
        fig.savefig(path[:-4] + ".png", bbox_inches="tight")


def plot_cost_f1(sweep: List[Dict], chosen: Optional[Dict], baselines: Dict[str, Tuple[float, float]],
                 path: str, title: Optional[str] = None) -> None:
    """F1 of unsupported-answer detection against the fraction of claims sent to the NLI verifier."""
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(3.6, 2.7))
    xs = [r["call_rate"] for r in sweep]
    ys = [r["f1"] for r in sweep]
    ax.plot(xs, ys, color="black", linestyle="-", marker="o", markersize=3.5, linewidth=0.9,
            markerfacecolor="white", label="Adaptive (theta sweep)")
    for (name, (x, y)), mk in zip(baselines.items(), ["s", "^", "D"]):
        ax.plot([x], [y], marker=mk, color="black", markerfacecolor="black", linestyle="none",
                markersize=5, label=name)
    if chosen:
        ax.plot([chosen["call_rate"]], [chosen["f1"]], marker="*", color="black", markersize=10,
                linestyle="none", markerfacecolor="white", label=f"Selected theta = {chosen['theta']:.1f}")
    ax.set_xlabel("Fraction of claims verified by NLI")
    ax.set_ylabel("F1 (unsupported answers)")
    ax.set_xlim(-0.03, 1.03)
    if title:
        ax.set_title(title)
    ax.legend(fontsize=7.5, loc="lower right")
    _save(fig, path)
    plt.close(fig)


def plot_reliability(curves: Dict[str, List[Tuple[float, float, int]]], path: str) -> None:
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(3.2, 3.0))
    ax.plot([0, 1], [0, 1], color="black", linestyle=":", linewidth=0.8, label="Perfect calibration")
    for (name, pts), ls, mk in zip(curves.items(), ["-", "--", "-."], MARKERS):
        if pts:
            ax.plot([p[0] for p in pts], [p[1] for p in pts], color="black", linestyle=ls, marker=mk,
                    markersize=3.5, markerfacecolor="white", linewidth=0.9, label=name)
    ax.set_xlabel("Predicted support probability")
    ax.set_ylabel("Observed fraction supported")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.legend(fontsize=7.5, loc="upper left")
    _save(fig, path)
    plt.close(fig)


def plot_grouped_bars(groups: Sequence[str], series: Dict[str, Sequence[float]], ylabel: str, path: str,
                      figsize=(4.8, 2.8)) -> None:
    """Grouped bars distinguished by grey level and hatch, never by colour."""
    import numpy as np
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=figsize)
    n = len(series)
    width = 0.8 / max(n, 1)
    x = np.arange(len(groups))
    for k, (name, vals) in enumerate(series.items()):
        ax.bar(x + (k - (n - 1) / 2) * width, vals, width, color=GRAYS[k % len(GRAYS)],
               hatch=HATCHES[k % len(HATCHES)], edgecolor="black", linewidth=0.6, label=name)
    ax.set_xticks(x)
    ax.set_xticklabels(groups, fontsize=8)
    ax.set_ylabel(ylabel)
    ax.legend(fontsize=7.5, ncol=min(n, 3), loc="upper center", bbox_to_anchor=(0.5, 1.22))
    _save(fig, path)
    plt.close(fig)
