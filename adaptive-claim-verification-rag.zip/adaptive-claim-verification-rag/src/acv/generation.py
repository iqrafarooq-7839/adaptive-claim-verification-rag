"""Answer generation with frozen open-weight LLMs (greedy decoding), following the base paper."""

from __future__ import annotations

import re
from typing import List, Sequence

REFUSAL = "The context does not provide sufficient information to answer the question."

_REFUSAL_PATTERNS = [
    r"does not provide (sufficient|enough) information",
    r"cannot be determined from (the )?(given |provided )?context",
    r"not enough information",
    r"insufficient (information|context)",
]


def build_prompt(question: str, contexts: Sequence[str], max_ctx_chars: int = 2000) -> str:
    """Chain-of-thought RAG prompt with the same step structure and refusal sentence as the base
    repository (github.com/chandanasreemala/Beyond_Retrieval, generation_utils.build_prompt)."""
    lines = []
    for i, txt in enumerate(contexts, start=1):
        clean = " ".join(str(txt)[:max_ctx_chars].split())
        lines.append(f"[context {i}] - {clean}")
    ctx_block = "\n".join(lines)
    return (
        "You are a helpful assistant. Follow the user's instructions carefully and answer the "
        "question in one or max two sentences. Do not repeat any part of the prompt in your final "
        "answer and answer strictly based on provided contexts.\n\n"
        "Prompt:\n"
        f"Question:- {question}\n"
        "Contexts:-\n"
        f"{ctx_block}\n\n"
        "Your task is to answer the given question by thinking progressively following the steps:\n"
        "Step 0: Process the answer within your memory and only provide the necessary answer.\n"
        "Step 1: Carefully read and understand the question and given contexts which can support you "
        "to answer better.\n"
        "Step 2: Analyze whether the given contexts provides sufficient information to answer the question.\n"
        f"- If the given contexts do not provide sufficient information, respond with: \"{REFUSAL}\"\n"
        "- If the given contexts provide sufficient information, proceed to Step 3.\n"
        "Step 3: Generate an accurate and grounded response strictly based on the provided contexts. "
        "Avoid guessing or providing incorrect/hallucinated responses.\n"
        "Step 4: Only when you are sure of Step 3, Clearly state the final answer in one or two sentences.\n\n"
        "Answer:"
    )


def is_refusal(text: str) -> bool:
    t = (text or "").lower()
    return any(re.search(p, t) for p in _REFUSAL_PATTERNS)


def strip_think(text: str) -> str:
    return re.sub(r"<think>.*?</think>", "", text or "", flags=re.S).strip()


class HFGenerator:
    """Frozen causal LM; raw prompt (no chat template) and greedy decoding, as in the base repository."""

    def __init__(self, model_id: str, max_new_tokens: int = 256, load_in_4bit: bool = False,
                 device_map: str = "auto"):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self.torch = torch
        self.tok = AutoTokenizer.from_pretrained(model_id)
        kwargs = {"device_map": device_map}
        if load_in_4bit:
            from transformers import BitsAndBytesConfig

            kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True, bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_quant_type="nf4")
        else:
            kwargs["torch_dtype"] = torch.bfloat16 if torch.cuda.is_available() else torch.float32
        self.model = AutoModelForCausalLM.from_pretrained(model_id, **kwargs).eval()
        self.max_new_tokens = max_new_tokens

    def generate(self, prompt: str) -> str:
        torch = self.torch
        inputs = self.tok(prompt, return_tensors="pt").to(self.model.device)
        pad = self.tok.eos_token_id if self.tok.eos_token_id is not None else self.tok.pad_token_id
        with torch.no_grad():
            out = self.model.generate(**inputs, max_new_tokens=self.max_new_tokens, do_sample=False,
                                      pad_token_id=pad)
        text = self.tok.decode(out[0, inputs["input_ids"].shape[1]:], skip_special_tokens=True)
        return strip_think(text)


def answer_contexts(ranked_doc_ids: Sequence[int], texts: Sequence[str], n: int = 5) -> List[str]:
    return [texts[d] for d in list(ranked_doc_ids)[:n]]
