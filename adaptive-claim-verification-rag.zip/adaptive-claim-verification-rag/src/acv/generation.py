"""Answer generation with frozen open-weight LLMs (greedy decoding), following the base paper."""

from __future__ import annotations

import re
from typing import List, Sequence

REFUSAL = "The context does not provide sufficient information to answer the question."

_REFUSAL_PATTERNS = [
    r"does not provide (sufficient|enough) information",
    r"cannot be determined from (the )?(given |provided )?context",
    r"not enough information",
    r"insufficient (information|context)",
]


def build_prompt(question: str, contexts: Sequence[str], max_ctx_chars: int = 2000) -> str:
    """Chain-of-thought RAG prompt with the same step structure and refusal sentence as the base
    repository (github.com/chandanasreemala/Beyond_Retrieval, generation_utils.build_prompt)."""
    lines = []
    for i, txt in enumerate(contexts, start=1):
        clean = " ".join(str(txt)[:max_ctx_chars].split())
        lines.append(f"[context {i}] - {clean}")
    ctx_block = "\n".join(lines)
    return (
        "You are a helpful assistant. Follow the user's instructions carefully and answer the "
        "question in one or max two sentences. Do not repeat any part of the prompt in your final "
        "answer and answer strictly based on provided contexts.\n\n"
        "Prompt:\n"
        f"Question:- {question}\n"
        "Contexts:-\n"
        f"{ctx_block}\n\n"
        "Your task is to answer the given question by thinking progressively following the steps:\n"
        "Step 0: Process the answer within your memory and only provide the necessary answer.\n"
        "Step 1: Carefully read and understand the question and given contexts which can support you "
        "to answer better.\n"
        "Step 2: Analyze whether the given contexts provides sufficient information to answer the question.\n"
        f"- If the given contexts do not provide sufficient information, respond with: \"{REFUSAL}\"\n"
        "- If the given contexts provide sufficient information, proceed to Step 3.\n"
        "Step 3: Generate an accurate and grounded response strictly based on the provided contexts. "
        "Avoid guessing or providing incorrect/hallucinated responses.\n"
        "Step 4: Only when you are sure of Step 3, Clearly state the final answer in one or two sentences.\n\n"
        "Answer:"
    )


def is_refusal(text: str) -> bool:
    t = (text or "").lower()
    return any(re.search(p, t) for p in _REFUSAL_PATTERNS)


def strip_think(text: str) -> str:
    return re.sub(r"<think>.*?</think>", "", text or "", flags=re.S).strip()


def resolve_dtype(name: str = "auto"):
    """Map a config string to a torch dtype.

    ``auto``: bfloat16 on GPUs with native support (A100, L4, RTX 30/40...), float16 on older GPUs
    such as the free-tier T4/P100, float32 on CPU.
    """
    import torch

    name = (name or "auto").lower()
    table = {"bfloat16": torch.bfloat16, "bf16": torch.bfloat16, "float16": torch.float16,
             "fp16": torch.float16, "half": torch.float16, "float32": torch.float32, "fp32": torch.float32}
    if name in table:
        return table[name]
    if name != "auto":
        raise ValueError(f"unknown dtype {name!r}")
    if not torch.cuda.is_available():
        return torch.float32
    try:
        native_bf16 = torch.cuda.is_bf16_supported(including_emulation=False)
    except TypeError:  # older torch
        major = torch.cuda.get_device_capability(0)[0]
        native_bf16 = major >= 8
    return torch.bfloat16 if native_bf16 else torch.float16


def load_causal_lm(model_id: str, dtype: str = "auto", load_in_4bit: bool = False, device_map: str = "auto"):
    """Load tokenizer and a frozen causal LM. With several GPUs (Kaggle T4 x2) ``device_map='auto'``
    spreads the layers over them, so an 8B model fits in 16-bit without quantisation."""
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    tok = AutoTokenizer.from_pretrained(model_id)
    tok.padding_side = "left"  # required for batched generation with decoder-only models
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    kwargs = {}
    if torch.cuda.is_available():
        kwargs["device_map"] = device_map
    torch_dtype = resolve_dtype(dtype)
    if load_in_4bit:
        from transformers import BitsAndBytesConfig

        compute = torch_dtype if torch_dtype != torch.float32 else torch.float16
        kwargs["quantization_config"] = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                                           bnb_4bit_compute_dtype=compute)
        model = AutoModelForCausalLM.from_pretrained(model_id, **kwargs)
    else:
        try:  # transformers >= 4.56 names the argument ``dtype``
            model = AutoModelForCausalLM.from_pretrained(model_id, dtype=torch_dtype, **kwargs)
        except TypeError:
            model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=torch_dtype, **kwargs)
    return tok, model.eval(), torch_dtype


def greedy_generate(tok, model, prompts: Sequence[str], max_new_tokens: int, batch_size: int = 1) -> List[str]:
    """Greedy decoding for a list of prompts, in batches; halves the batch size on out-of-memory."""
    import torch

    outputs: List[str] = [""] * len(prompts)
    i, bs = 0, max(1, batch_size)
    while i < len(prompts):
        chunk = list(prompts[i:i + bs])
        try:
            enc = tok(chunk, return_tensors="pt", padding=len(chunk) > 1).to(model.device)
            with torch.no_grad():
                out = model.generate(**enc, max_new_tokens=max_new_tokens, do_sample=False,
                                     pad_token_id=tok.pad_token_id)
            new_tokens = out[:, enc["input_ids"].shape[1]:]
            for k, text in enumerate(tok.batch_decode(new_tokens, skip_special_tokens=True)):
                outputs[i + k] = text
            i += len(chunk)
        except torch.cuda.OutOfMemoryError:
            torch.cuda.empty_cache()
            if bs == 1:
                raise
            bs = max(1, bs // 2)
            print(f"[generation] out of GPU memory, batch size reduced to {bs}")
    return outputs


class HFGenerator:
    """Frozen causal LM; raw prompt (no chat template) and greedy decoding, as in the base repository.

    ``batch_size=1`` reproduces the base implementation exactly. Larger batches are several times
    faster on a free GPU; padding can change a few outputs in 16-bit arithmetic, so report it.
    """

    def __init__(self, model_id: str, max_new_tokens: int = 256, load_in_4bit: bool = False,
                 dtype: str = "auto", batch_size: int = 1, device_map: str = "auto"):
        self.tok, self.model, self.dtype = load_causal_lm(model_id, dtype, load_in_4bit, device_map)
        self.max_new_tokens, self.batch_size = max_new_tokens, batch_size

    def generate_many(self, prompts: Sequence[str]) -> List[str]:
        texts = greedy_generate(self.tok, self.model, prompts, self.max_new_tokens, self.batch_size)
        return [strip_think(t).strip() for t in texts]

    def generate(self, prompt: str) -> str:
        return self.generate_many([prompt])[0]


def model_settings(gen_cfg: dict, model_key: str) -> dict:
    """Generation settings for one model: global values overridden by ``generation.per_model.<key>``."""
    base = {"dtype": gen_cfg.get("dtype", "auto"), "batch_size": gen_cfg.get("batch_size", 1),
            "load_in_4bit": gen_cfg.get("load_in_4bit", False)}
    base.update((gen_cfg.get("per_model") or {}).get(model_key) or {})
    return base


def answer_contexts(ranked_doc_ids: Sequence[int], texts: Sequence[str], n: int = 5) -> List[str]:
    return [texts[d] for d in list(ranked_doc_ids)[:n]]
