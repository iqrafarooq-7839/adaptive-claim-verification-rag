"""Small shared helpers: configuration, seeding, JSONL I/O, text normalisation, timing."""

from __future__ import annotations

import json
import os
import random
import re
import time
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List

import numpy as np

_WS = re.compile(r"\s+")
_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+(?=[\"'(\[A-Z0-9])")


def deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Recursively merge ``override`` into a copy of ``base`` (dicts merge, everything else replaces)."""
    out = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = deep_merge(out[key], value)
        else:
            out[key] = value
    return out


def load_config(path: str | os.PathLike = "configs/default.yaml") -> Dict[str, Any]:
    """Load a YAML config. A file may start with ``extends: other.yaml`` (path relative to the file)
    and then only list the settings it changes, e.g. configs/free_gpu.yaml."""
    import yaml

    path = Path(path)
    with open(path, "r", encoding="utf-8") as fh:
        cfg = yaml.safe_load(fh) or {}
    parent = cfg.pop("extends", None)
    if parent:
        cfg = deep_merge(load_config(path.parent / parent), cfg)
    return cfg


def retrieval_run_dir(cfg: Dict[str, Any], split: str | None = None) -> Path:
    """Directory of a retrieval run; the name encodes the split and any sampling so runs never mix."""
    hc = cfg["hotpotqa"]
    name = split or hc["retrieval_split"]
    if hc.get("max_questions"):
        name += f"_corpus{hc['max_questions']}"
    if hc.get("max_queries"):
        name += f"_q{hc['max_queries']}"
    return Path(cfg["paths"]["out_dir"]) / "retrieval" / name


def free_gpu_memory() -> None:
    import gc

    gc.collect()
    try:
        import torch

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except ImportError:
        pass


def gpu_summary() -> str:
    try:
        import torch
    except ImportError:
        return "torch not installed"
    if not torch.cuda.is_available():
        return "no CUDA GPU (CPU only)"
    parts = []
    for i in range(torch.cuda.device_count()):
        p = torch.cuda.get_device_properties(i)
        parts.append(f"cuda:{i} {p.name} {p.total_memory / 2**30:.1f} GB")
    return "; ".join(parts)


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass


def ensure_dir(path: str | os.PathLike) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def write_jsonl(path: str | os.PathLike, rows: Iterable[Dict[str, Any]]) -> int:
    ensure_dir(Path(path).parent)
    n = 0
    with open(path, "w", encoding="utf-8") as fh:
        for row in rows:
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")
            n += 1
    return n


def append_jsonl(path: str | os.PathLike, row: Dict[str, Any]) -> None:
    ensure_dir(Path(path).parent)
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, ensure_ascii=False) + "\n")


def read_jsonl(path: str | os.PathLike) -> List[Dict[str, Any]]:
    return list(iter_jsonl(path))


def iter_jsonl(path: str | os.PathLike) -> Iterator[Dict[str, Any]]:
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                yield json.loads(line)


def write_json(path: str | os.PathLike, obj: Any) -> None:
    ensure_dir(Path(path).parent)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=2, ensure_ascii=False)


def normalize_text(text: str) -> str:
    """Lower-case, strip surrounding quotes and collapse whitespace (matches the base repository)."""
    if text is None:
        return ""
    t = str(text).strip().strip("\"'").strip()
    return _WS.sub(" ", t).lower()


def split_sentences(text: str) -> List[str]:
    """Rule-based sentence splitter (no external models needed)."""
    if not text:
        return []
    text = _WS.sub(" ", str(text)).strip()
    parts = _SENT_SPLIT.split(text)
    return [p.strip() for p in parts if p.strip()]


class Timer:
    """Context manager that records elapsed wall-clock seconds in ``.seconds``."""

    def __enter__(self) -> "Timer":
        self._t0 = time.perf_counter()
        self.seconds = 0.0
        return self

    def __exit__(self, *exc) -> None:
        self.seconds = time.perf_counter() - self._t0


def device_name() -> str:
    try:
        import torch

        if torch.cuda.is_available():
            return "cuda"
        if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            return "mps"
    except ImportError:
        pass
    return "cpu"
