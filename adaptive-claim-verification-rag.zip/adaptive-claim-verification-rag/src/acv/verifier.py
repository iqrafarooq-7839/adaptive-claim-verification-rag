"""Proposed method: adaptive claim-level evidence verification.

Stage 1  claims    C = E(a)                                  (claims.extract_claims)
Stage 2  cheap     phi_i = [s_max, s_top3, lex_cov, key_cov];  p_i = sigmoid(w^T phi_i + b)
Stage 3  gate      u_i = 1 - |2 p_i - 1|;  escalate iff u_i > theta
Stage 4  verifier  v_i = P_NLI(entailment | premise_i, claim_i),  premise_i = top-m context
                   sentences by similarity, kept in document order (multi-hop composition)
Decision           z_i = 1 (unsupported) iff  (not escalated and p_i < 0.5) or (escalated and v_i < tau)
Answer             unsupported iff any z_i = 1; risk score = 1 - min_i support_i
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence

import numpy as np

from .claims import extract_claims, to_hypothesis
from .utils import Timer, split_sentences

FEATURES = ("s_max", "s_top3", "lex_cov", "key_cov")

STOPWORDS = set("""a an the and or but if of to in on at by for with from as is are was were be been being
this that these those it its it's he she they them his her their there here which who whom whose what when
where why how not no do does did done has have had having will would can could should may might must than
then also into onto over under about after before during while because so such very more most other some
any each both all one two three answer question context given provided""".split())

_TOKEN = re.compile(r"[A-Za-z0-9]+(?:[.,][0-9]+)?")
_NUMBER = re.compile(r"\d[\d,.]*")
_CAP = re.compile(r"\b[A-Z][a-zA-Z0-9\-]+")


def content_tokens(text: str) -> List[str]:
    return [t.lower() for t in _TOKEN.findall(text or "") if len(t) > 2 and t.lower() not in STOPWORDS]


def key_tokens(text: str) -> List[str]:
    """Numbers and capitalised words (entities); the first word of the claim is ignored."""
    nums = [n.strip(".,").replace(",", "") for n in _NUMBER.findall(text or "")]
    words = _CAP.findall(text or "")
    first = (text or "").strip().split(" ")[0] if text else ""
    caps = [w.lower() for w in words if w != first and w.lower() not in STOPWORDS]
    return [n for n in nums if n] + caps


def coverage(tokens: Sequence[str], vocab: set) -> float:
    return 1.0 if not tokens else sum(t in vocab for t in tokens) / len(tokens)


def context_vocab(sentences: Sequence[str]) -> set:
    vocab = set()
    for s in sentences:
        vocab.update(t.lower() for t in _TOKEN.findall(s))
        vocab.update(n.strip(".,").replace(",", "") for n in _NUMBER.findall(s))
    return vocab


# ---------------------------------------------------------------------------
# Stage 2: cheap evidence-support features and calibration
# ---------------------------------------------------------------------------

class CheapScorer:
    """Embedding similarity plus lexical and entity/number coverage; no generator calls."""

    def __init__(self, embed_fn: Callable[[Sequence[str]], np.ndarray]):
        self.embed_fn = embed_fn

    def features(self, claims: Sequence[str], hypotheses: Sequence[str], ctx_sents: Sequence[str]):
        if not claims:
            return np.zeros((0, len(FEATURES))), np.zeros((0, len(ctx_sents)))
        if not ctx_sents:
            return np.zeros((len(claims), len(FEATURES))), np.zeros((len(claims), 0))
        emb = self.embed_fn(list(hypotheses) + list(ctx_sents))
        e_c, e_s = emb[: len(claims)], emb[len(claims):]
        sims = e_c @ e_s.T
        top = np.sort(sims, axis=1)[:, ::-1]
        s_max = top[:, 0]
        s_top3 = top[:, : min(3, top.shape[1])].mean(axis=1)
        vocab = context_vocab(ctx_sents)
        lex = np.array([coverage(content_tokens(c), vocab) for c in claims])
        key = np.array([coverage(key_tokens(c), vocab) for c in claims])
        return np.stack([s_max, s_top3, lex, key], axis=1), sims


class Calibrator:
    """p_i = P(supported | phi_i). ``mode='logistic'`` fits w, b on the dev split;
    ``mode='identity'`` (ablation) uses the raw maximum similarity as the probability."""

    def __init__(self, mode: str = "logistic", features: Sequence[str] = FEATURES):
        self.mode = mode
        self.cols = [FEATURES.index(f) for f in features]
        self.model = None

    def fit(self, phi: np.ndarray, supported: Sequence[int]) -> "Calibrator":
        if self.mode == "identity":
            return self
        from sklearn.linear_model import LogisticRegression
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler

        y = np.asarray(supported, dtype=int)
        if len(set(y.tolist())) < 2:
            raise ValueError("calibration needs both supported and unsupported examples")
        self.model = make_pipeline(StandardScaler(), LogisticRegression(C=1.0, max_iter=2000))
        self.model.fit(phi[:, self.cols], y)
        return self

    def predict(self, phi: np.ndarray) -> np.ndarray:
        if len(phi) == 0:
            return np.zeros(0)
        if self.mode == "identity":
            return np.clip(phi[:, 0], 0.0, 1.0)
        return self.model.predict_proba(phi[:, self.cols])[:, 1]


# ---------------------------------------------------------------------------
# Stage 4: full verifier
# ---------------------------------------------------------------------------

class NLIVerifier:
    """Sentence-pair NLI classifier; returns P(entailment). Counts every pair it scores."""

    def __init__(self, model_name: str, device: Optional[str] = None, batch_size: int = 16,
                 max_length: int = 512):
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer

        from .utils import device_name

        self.torch = torch
        self.device = device or device_name()
        self.tok = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSequenceClassification.from_pretrained(model_name).to(self.device).eval()
        labels = {i: str(l).lower() for i, l in self.model.config.id2label.items()}
        ent = [i for i, l in labels.items() if "entail" in l]
        if not ent:
            raise ValueError(f"no entailment label in {labels}")
        self.entail_idx = ent[0]
        limit = getattr(self.model.config, "max_position_embeddings", max_length) or max_length
        self.batch_size, self.max_length = batch_size, min(max_length, limit)
        self.calls = 0

    def entail_prob(self, premises: Sequence[str], hypotheses: Sequence[str]) -> np.ndarray:
        torch = self.torch
        out = []
        with torch.no_grad():
            for s in range(0, len(premises), self.batch_size):
                enc = self.tok(list(premises[s:s + self.batch_size]), list(hypotheses[s:s + self.batch_size]),
                               padding=True, truncation="only_first", max_length=self.max_length,
                               return_tensors="pt").to(self.device)
                probs = torch.softmax(self.model(**enc).logits.float(), dim=-1)[:, self.entail_idx]
                out.append(probs.cpu().numpy())
        self.calls += len(premises)
        return np.concatenate(out) if out else np.zeros(0)


def build_premise(ctx_sents: Sequence[str], sims_row: np.ndarray, m: int) -> str:
    """Top-m sentences by similarity to the claim, restored to document order so that evidence
    for different hops appears together (multi-hop premise)."""
    if len(ctx_sents) == 0:
        return ""
    idx = np.argsort(-sims_row)[: min(m, len(ctx_sents))]
    return " ".join(ctx_sents[j] for j in sorted(idx.tolist()))


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

@dataclass
class Item:
    """One answer to verify, with everything computed by the cheap stage."""
    uid: str
    question: str
    answer: str
    ctx_sents: List[str]
    claims: List[str] = field(default_factory=list)
    hypotheses: List[str] = field(default_factory=list)
    phi: np.ndarray = None
    sims: np.ndarray = None
    p: np.ndarray = None
    premises: List[str] = field(default_factory=list)
    v: Optional[np.ndarray] = None  # NLI entailment for every claim (analysis only)
    meta: Dict = field(default_factory=dict)


def uncertainty(p: np.ndarray) -> np.ndarray:
    return 1.0 - np.abs(2.0 * np.asarray(p) - 1.0)


def decide(p: np.ndarray, v: Optional[np.ndarray], mode: str, theta: float = 0.5, tau: float = 0.5):
    """Return (unsupported flags, support scores, escalated mask) for one answer."""
    p = np.asarray(p, dtype=float)
    if mode == "cheap":
        esc = np.zeros(len(p), dtype=bool)
    elif mode == "nli":
        esc = np.ones(len(p), dtype=bool)
    elif mode == "adaptive":
        esc = uncertainty(p) > theta
    else:
        raise ValueError(mode)
    support = p.copy()
    if esc.any():
        if v is None:
            raise ValueError("NLI scores are required for escalated claims")
        support[esc] = np.asarray(v, dtype=float)[esc]
    unsup = np.where(esc, support < tau, support < 0.5)
    return unsup.astype(int), support, esc


class AdaptiveVerifier:
    def __init__(self, scorer: CheapScorer, calibrator: Calibrator, nli=None, m: int = 4,
                 theta: float = 0.5, tau: float = 0.5):
        self.scorer, self.calibrator, self.nli = scorer, calibrator, nli
        self.m, self.theta, self.tau = m, theta, tau

    # --- cheap stage -----------------------------------------------------
    def prepare(self, uid: str, question: str, answer: str, context: str | Sequence[str], meta=None) -> Item:
        ctx = split_sentences(context) if isinstance(context, str) else [s for s in context if s and s.strip()]
        it = Item(uid=uid, question=question, answer=answer, ctx_sents=ctx, meta=meta or {})
        it.claims = extract_claims(answer)
        it.hypotheses = [to_hypothesis(c, question) for c in it.claims]
        it.phi, it.sims = self.scorer.features(it.claims, it.hypotheses, ctx)
        it.premises = [build_premise(ctx, it.sims[i], self.m) for i in range(len(it.claims))]
        return it

    def calibrate(self, items: Sequence[Item]) -> None:
        for it in items:
            it.p = self.calibrator.predict(it.phi) if len(it.claims) else np.zeros(0)

    # --- full verifier for analysis (scores every claim once) -------------
    def score_all_nli(self, items: Sequence[Item]) -> None:
        prem, hyp, owner = [], [], []
        for k, it in enumerate(items):
            for i in range(len(it.claims)):
                prem.append(it.premises[i]); hyp.append(it.hypotheses[i]); owner.append((k, i))
        v = self.nli.entail_prob(prem, hyp) if prem else np.zeros(0)
        for it in items:
            it.v = np.zeros(len(it.claims))
        for (k, i), val in zip(owner, v):
            items[k].v[i] = val

    # --- deployment path (only escalated claims reach the NLI model) -----
    def run(self, item: Item, mode: str = "adaptive", theta: Optional[float] = None,
            tau: Optional[float] = None) -> Dict:
        theta = self.theta if theta is None else theta
        tau = self.tau if tau is None else tau
        with Timer() as t:
            if not item.claims:
                return {"unsupported": 0, "risk": 0.0, "calls": 0, "seconds": 0.0, "claims": []}
            esc = np.zeros(len(item.claims), dtype=bool)
            if mode == "nli":
                esc[:] = True
            elif mode == "adaptive":
                esc = uncertainty(item.p) > theta
            v = np.full(len(item.claims), np.nan)
            if esc.any():
                idx = np.where(esc)[0]
                v[idx] = self.nli.entail_prob([item.premises[i] for i in idx], [item.hypotheses[i] for i in idx])
            z, support, esc = decide(item.p, np.nan_to_num(v, nan=0.0), mode, theta, tau)
        return {"unsupported": int(z.max()), "risk": float(1 - support.min()), "calls": int(esc.sum()),
                "seconds": t.seconds,
                "claims": [{"claim": c, "p": float(pp), "escalated": bool(e), "v": None if np.isnan(vv) else float(vv),
                            "unsupported": int(zz)} for c, pp, e, vv, zz in zip(item.claims, item.p, esc, v, z)]}


def evaluate_offline(items: Sequence[Item], mode: str, theta: float, tau: float) -> Dict:
    """Answer-level predictions and cost from precomputed p and v (used for the theta sweep)."""
    preds, risks, calls, n_claims = [], [], 0, 0
    for it in items:
        if not it.claims:
            preds.append(0); risks.append(0.0)
            continue
        z, support, esc = decide(it.p, it.v, mode, theta, tau)
        preds.append(int(z.max())); risks.append(float(1 - support.min()))
        calls += int(esc.sum()); n_claims += len(it.claims)
    return {"pred": preds, "risk": risks, "calls": calls, "n_claims": n_claims,
            "call_rate": calls / n_claims if n_claims else 0.0}
