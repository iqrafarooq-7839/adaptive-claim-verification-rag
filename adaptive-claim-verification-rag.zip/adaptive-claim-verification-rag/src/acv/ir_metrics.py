"""Order-aware retrieval metrics with trec_eval semantics (map_cut_k and ndcg_cut_k, binary relevance)."""

from __future__ import annotations

import math
from typing import Dict, Iterable, List, Sequence


def average_precision_at_k(ranked: Sequence[str], relevant: Dict[str, int], k: int) -> float:
    """AP@k = (1/|R|) * sum_{i<=k} P(i) * rel(i), with |R| the total number of relevant documents."""
    n_rel = sum(1 for v in relevant.values() if v > 0)
    if n_rel == 0:
        return 0.0
    hits, total = 0, 0.0
    for i, doc in enumerate(ranked[:k], start=1):
        if relevant.get(doc, 0) > 0:
            hits += 1
            total += hits / i
    return total / n_rel


def ndcg_at_k(ranked: Sequence[str], relevant: Dict[str, int], k: int) -> float:
    """NDCG@k with gain (2^rel - 1) and log2(i + 1) discount."""
    dcg = 0.0
    for i, doc in enumerate(ranked[:k], start=1):
        rel = relevant.get(doc, 0)
        if rel > 0:
            dcg += (2 ** rel - 1) / math.log2(i + 1)
    ideal = sorted((v for v in relevant.values() if v > 0), reverse=True)[:k]
    idcg = sum((2 ** r - 1) / math.log2(i + 1) for i, r in enumerate(ideal, start=1))
    return dcg / idcg if idcg > 0 else 0.0


def evaluate_run(run: Dict[str, List[str]], qrels: Dict[str, Dict[str, int]],
                 cutoffs: Iterable[int] = (3, 5, 10)) -> Dict[str, object]:
    """Return mean MAP@k / NDCG@k over queries that have at least one relevant document,
    plus per-query values (needed for the Wilcoxon test)."""
    cutoffs = list(cutoffs)
    per_query: Dict[str, Dict[str, float]] = {}
    for qid, rel in qrels.items():
        if not any(v > 0 for v in rel.values()):
            continue
        ranked = run.get(qid, [])
        row = {}
        for k in cutoffs:
            row[f"MAP@{k}"] = average_precision_at_k(ranked, rel, k)
            row[f"NDCG@{k}"] = ndcg_at_k(ranked, rel, k)
        per_query[qid] = row
    means = {}
    if per_query:
        for key in next(iter(per_query.values())):
            means[key] = sum(r[key] for r in per_query.values()) / len(per_query)
    return {"mean": means, "per_query": per_query, "n_queries": len(per_query)}
