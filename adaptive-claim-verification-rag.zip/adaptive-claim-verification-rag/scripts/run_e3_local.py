"""Run experiment E3 end to end on your own GPU (judge + verification of the HotpotQA answers).

    python scripts/run_e3_local.py --s1 path/to/hotpot_s1_results.zip --s3 path/to/halubench_v2_results.zip

--s1  Kaggle output of the HotpotQA run (notebook notebookf1bed88cf9): the zip, the downloaded output folder,
      or any folder that contains qwen3_4b__*.jsonl generation files.
--s3  Kaggle output of the HaluBench run (notebook notebooka9cf410887): the zip, the folder, or v2_artifacts.pkl.
      Optional; without it only the in-domain configuration is evaluated.

Writes outputs/verifier/hotpot_endtoend.json and e3_results.zip (send that zip back for the paper).
GPU: about 8 GB is enough with 4-bit loading (bitsandbytes); without bitsandbytes the 7B judge needs ~16 GB.
"""
import argparse
import collections
import glob
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def find(src, patterns, tmp):
    """Return files matching patterns inside a file, folder or zip."""
    if not src:
        return []
    p = Path(src)
    if p.is_file() and p.suffix == ".zip":
        d = Path(tmp) / p.stem
        zipfile.ZipFile(p).extractall(d)
        p = d
    if p.is_file():
        return [p]
    out = []
    for pat in patterns:
        out += [Path(x) for x in glob.glob(str(p / "**" / pat), recursive=True)]
        for z in glob.glob(str(p / "**" / "*.zip"), recursive=True):   # zips inside a downloaded folder
            d = Path(tmp) / Path(z).stem
            if not d.exists():
                zipfile.ZipFile(z).extractall(d)
            out += [Path(x) for x in glob.glob(str(d / "**" / pat), recursive=True)]
    return sorted(set(out))


def run(cmd):
    print("\n$ " + " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=ROOT, check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--s1", required=True)
    ap.add_argument("--s3", default=None)
    ap.add_argument("--judge-batch", type=int, default=4, help="lower to 2 or 1 if you run out of GPU memory")
    ap.add_argument("--claim-judge-n", type=int, default=250)
    args = ap.parse_args()

    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    gen_dir = ROOT / "outputs" / "generation"
    ver_dir = ROOT / "outputs" / "verifier"
    gen_dir.mkdir(parents=True, exist_ok=True)
    ver_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        gens = [f for f in find(args.s1, ["qwen3_4b__*.jsonl"], tmp) if not f.name.endswith("_judged.jsonl")]
        if not gens:
            sys.exit("no qwen3_4b__*.jsonl generation files found in --s1")
        for f in gens:
            shutil.copy(f, gen_dir / f.name)
        arts = find(args.s3, ["v2_artifacts.pkl"], tmp) if args.s3 else []
        if arts:
            shutil.copy(arts[0], ver_dir / "v2_artifacts.pkl")
    print("generation files:", sorted(p.name for p in gen_dir.glob("qwen3_4b__*.jsonl")))
    print("HaluBench artifacts:", "found" if (ver_dir / "v2_artifacts.pkl").exists() else "not given")

    try:
        import bitsandbytes  # noqa: F401
        four_bit = True
    except Exception:
        four_bit = False
        print("bitsandbytes not available: the judge is loaded in 16-bit (needs ~16 GB of GPU memory)")
    cfg = ROOT / "configs" / "local_gpu.yaml"
    cfg.write_text("extends: free_gpu.yaml\n"
                   f"judge:\n  backend: hf\n  hf_batch_size: {args.judge_batch}\n  hf_load_in_4bit: {str(four_bit).lower()}\n")
    C = ["--config", str(cfg)]
    py = sys.executable
    run([py, "scripts/03_judge.py", *C, "--backend", "hf"])
    for f in sorted(gen_dir.glob("*_judged.jsonl")):
        rows = [json.loads(line) for line in open(f, encoding="utf-8")]
        print(f.name, len(rows), dict(collections.Counter(r.get("judge_label") for r in rows)))
    cmd = [py, "scripts/10_hotpot_endtoend.py", *C, "--claim-judge-n", str(args.claim_judge_n)]
    if (ver_dir / "v2_artifacts.pkl").exists():
        cmd += ["--artifacts", str(ver_dir / "v2_artifacts.pkl")]
    run(cmd)

    out = ROOT / "e3_results.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(ver_dir / "hotpot_endtoend.json", "hotpot_endtoend.json")
        for f in sorted(gen_dir.glob("*_judged.jsonl")):
            z.write(f, "generation/" + f.name)
    print(f"\nDone. Results: {ver_dir / 'hotpot_endtoend.json'}\nSend back: {out}")


if __name__ == "__main__":
    main()
