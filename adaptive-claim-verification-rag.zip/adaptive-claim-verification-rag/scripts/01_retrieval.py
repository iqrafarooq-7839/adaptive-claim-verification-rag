"""Step 1 (base-paper reproduction): retrieval on HotpotQA and Tables 1 and 3.

Examples
  python scripts/01_retrieval.py --split train                      # as in the base paper (slow: about 90k queries)
  python scripts/01_retrieval.py --split train --max-questions 5000 # quick run, smaller corpus
  python scripts/01_retrieval.py --split validation --methods contriever hybrid_li_rerank   # contexts for step 2
"""

import argparse
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.data import build_sentence_corpus, load_hotpotqa  # noqa: E402
from acv.metrics import benjamini_hochberg, wilcoxon_paired  # noqa: E402
from acv.pipeline import HYBRID, SINGLE, default_backends, run_methods  # noqa: E402
from acv.reported import TABLE1_HOTPOTQA, TABLE3_HOTPOTQA  # noqa: E402
from acv.utils import ensure_dir, load_config, set_seed, write_json, write_jsonl  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--split", default=None)
    ap.add_argument("--max-questions", type=int, default=None)
    ap.add_argument("--methods", nargs="+", default=list(SINGLE) + list(HYBRID))
    args = ap.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    hc = cfg["hotpotqa"]
    split = args.split or hc["retrieval_split"]
    maxq = args.max_questions or hc["max_questions"]
    out = ensure_dir(Path(cfg["paths"]["out_dir"]) / "retrieval" / (split + (f"_{maxq}" if maxq else "")))

    examples = load_hotpotqa(hc["hf_name"], hc["config"], split, maxq, cfg["seed"])
    doc_ids, texts, qrels = build_sentence_corpus(examples, hc["corpus_paragraphs"])
    qids = [e["id"] for e in examples]
    queries = [e["question"] for e in examples]
    print(f"{len(examples)} questions, {len(texts)} sentence documents")
    write_json(out / "corpus.json", texts)
    write_json(out / "qrels.json", qrels)
    write_jsonl(out / "questions.jsonl", [{"id": e["id"], "question": e["question"], "answer": e["answer"],
                                          "type": e["type"], "level": e["level"]} for e in examples])

    results = run_methods(texts, qids, queries, qrels, args.methods, cfg, default_backends(cfg))

    reported = {**TABLE1_HOTPOTQA, **TABLE3_HOTPOTQA}
    keys = [f"{m}@{k}" for m in ("MAP", "NDCG") for k in cfg["retrieval"]["cutoffs"]]
    with open(out / "metrics.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["method", "n_queries"] + keys + [f"reported_{k}" for k in keys] + [f"diff_{k}" for k in keys])
        for m, r in results.items():
            mean = r["eval"]["mean"]
            rep = reported.get(m, {})
            w.writerow([m, r["eval"]["n_queries"]] + [f"{mean[k]:.4f}" for k in keys]
                       + [f"{rep[k]:.4f}" if k in rep else "" for k in keys]
                       + [f"{mean[k] - rep[k]:+.4f}" if k in rep else "" for k in keys])
        write_jsonl(out / "runs.jsonl", [{"method": m, "qid": q, "docs": r["run"][q], "scores": r["scores"][q]}
                                         for m, r in results.items() for q in r["run"]])

    # Paired Wilcoxon signed-rank tests with Benjamini-Hochberg correction (as in the base paper)
    pairs = [(a, b) for i, a in enumerate(results) for b in list(results)[i + 1:]]
    rows = []
    for a, b in pairs:
        pa, pb = results[a]["eval"]["per_query"], results[b]["eval"]["per_query"]
        common = sorted(set(pa) & set(pb))
        for k in ("MAP@10", "NDCG@10"):
            t = wilcoxon_paired([pa[q][k] for q in common], [pb[q][k] for q in common])
            rows.append({"a": a, "b": b, "metric": k, **t})
    if rows:
        for r, adj in zip(rows, benjamini_hochberg([r["p_value"] for r in rows])):
            r["p_fdr"] = adj
    write_json(out / "significance.json", rows)
    print(f"saved results to {out}")


if __name__ == "__main__":
    main()
