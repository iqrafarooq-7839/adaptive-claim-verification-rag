"""Step 1 (base-paper reproduction): retrieval on HotpotQA, Tables 1 and 3 of the base paper.

  python scripts/01_retrieval.py --config configs/free_gpu.yaml   # free GPU: 10,000 sampled questions, full corpus
  python scripts/01_retrieval.py                                  # exact protocol: all 90,447 train questions
  python scripts/01_retrieval.py --methods contriever hybrid_li_rerank   # only what step 2 needs

The corpus is always the full pooled sentence corpus of the split, so metrics measured on a random
sample of questions (--max-queries) are unbiased estimates of the full-split values; the script
reports their 95% confidence intervals. Finished retrievers are cached: re-run the same command
after an interrupted session and it continues where it stopped.
"""

import argparse
import csv
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv import sync  # noqa: E402
from acv.data import build_sentence_corpus, load_hotpotqa, sample_examples  # noqa: E402
from acv.metrics import benjamini_hochberg, wilcoxon_paired  # noqa: E402
from acv.pipeline import HYBRID, SINGLE, default_backends, run_methods  # noqa: E402
from acv.reported import TABLE1_HOTPOTQA, TABLE3_HOTPOTQA  # noqa: E402
from acv.utils import (ensure_dir, gpu_summary, load_config, retrieval_run_dir, set_seed, write_json,  # noqa: E402
                       write_jsonl)


def ci95(values):
    n = len(values)
    if n < 2:
        return 0.0
    mean = sum(values) / n
    var = sum((v - mean) ** 2 for v in values) / (n - 1)
    return 1.96 * math.sqrt(var / n)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--split", default=None)
    ap.add_argument("--max-queries", type=int, default=None, help="evaluate a random sample of questions (full corpus)")
    ap.add_argument("--max-questions", type=int, default=None, help="debugging: shrink corpus and questions")
    ap.add_argument("--methods", nargs="+", default=list(SINGLE) + list(HYBRID))
    args = ap.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    hc = cfg["hotpotqa"]
    if args.max_queries is not None:
        hc["max_queries"] = args.max_queries or None
    if args.max_questions is not None:
        hc["max_questions"] = args.max_questions or None
    split = args.split or hc["retrieval_split"]
    out = ensure_dir(retrieval_run_dir(cfg, split))
    print(f"GPU: {gpu_summary()}\noutput directory: {out}")

    examples = load_hotpotqa(hc["hf_name"], hc["config"], split, hc.get("max_questions"), cfg["seed"],
                             data_dir=cfg["paths"]["data_dir"], keep_paragraphs=hc["corpus_paragraphs"])
    doc_ids, texts, qrels_all = build_sentence_corpus(examples, hc["corpus_paragraphs"])
    queried = sample_examples(examples, hc["max_queries"], cfg["seed"]) if hc.get("max_queries") else examples
    qids = [e["id"] for e in queried]
    queries = [e["question"] for e in queried]
    qrels = {q: qrels_all[q] for q in qids}
    print(f"{len(examples):,} questions in the split, {len(texts):,} sentence documents in the corpus, "
          f"{len(queried):,} questions searched")
    write_json(out / "corpus.json", texts)
    write_json(out / "qrels.json", qrels)
    write_jsonl(out / "questions.jsonl", [{"id": e["id"], "question": e["question"], "answer": e["answer"],
                                          "type": e["type"], "level": e["level"]} for e in queried])
    del examples, qrels_all

    results = run_methods(texts, qids, queries, qrels, args.methods, cfg, default_backends(cfg),
                          cache_dir=out / "cache", on_step=lambda: sync.push(cfg, f"retrieval {split}"))

    reported = {**TABLE1_HOTPOTQA, **TABLE3_HOTPOTQA}
    keys = [f"{m}@{k}" for m in ("MAP", "NDCG") for k in cfg["retrieval"]["cutoffs"]]
    with open(out / "metrics.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["method", "n_queries", "n_documents"] + keys + [f"ci95_{k}" for k in keys]
                   + [f"reported_{k}" for k in keys] + [f"diff_{k}" for k in keys])
        for m, r in results.items():
            mean, per_q = r["eval"]["mean"], r["eval"]["per_query"]
            rep = reported.get(m, {})
            w.writerow([m, r["eval"]["n_queries"], len(texts)] + [f"{mean[k]:.4f}" for k in keys]
                       + [f"{ci95([v[k] for v in per_q.values()]):.4f}" for k in keys]
                       + [f"{rep[k]:.4f}" if k in rep else "" for k in keys]
                       + [f"{mean[k] - rep[k]:+.4f}" if k in rep else "" for k in keys])

    # top-10 lists: all methods for sampled runs, only the two retrievers used in step 2 for very large runs
    keep = set(results) if len(qids) <= 20000 else {"contriever", "hybrid_li_rerank"} & set(results)
    write_jsonl(out / "runs.jsonl", [{"method": m, "qid": q, "docs": results[m]["run"][q],
                                     "scores": results[m]["scores"][q]} for m in results if m in keep for q in qids])

    # Paired Wilcoxon signed-rank tests with Benjamini-Hochberg correction (as in the base paper)
    names = list(results)
    rows = []
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            pa, pb = results[a]["eval"]["per_query"], results[b]["eval"]["per_query"]
            common = sorted(set(pa) & set(pb))
            for k in ("MAP@10", "NDCG@10"):
                rows.append({"a": a, "b": b, "metric": k,
                             **wilcoxon_paired([pa[q][k] for q in common], [pb[q][k] for q in common])})
    if rows:
        for r, adj in zip(rows, benjamini_hochberg([r["p_value"] for r in rows])):
            r["p_fdr"] = adj
    write_json(out / "significance.json", rows)
    sync.push(cfg, f"retrieval {split} finished")
    print(f"saved results to {out}")


if __name__ == "__main__":
    main()
