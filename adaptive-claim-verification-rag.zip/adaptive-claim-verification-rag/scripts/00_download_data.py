"""Step 0: download the research datasets into data/ and check them.

  python scripts/00_download_data.py                  # both datasets (about 370 MB)
  python scripts/00_download_data.py --only halubench # 7.5 MB, enough for the verifier experiment (step 4)

Datasets (downloaded from the Hugging Face hub; no account needed):
  * HotpotQA, distractor setting (hotpotqa/hotpot_qa, CC BY-SA 4.0): 90,447 train + 7,405 validation questions
  * HaluBench (PatronusAI/HaluBench, CC BY-NC 2.0): 14,900 context-question-answer triplets, PASS/FAIL labels

All other scripts read these local files when they exist and download from the hub otherwise.
The script also writes the exact HaluBench subset used in the paper (1,200 rows, dev/test split).
"""

import argparse
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.data import clean_and_sample_halubench, split_dev_test  # noqa: E402
from acv.utils import ensure_dir, load_config, write_jsonl  # noqa: E402

EXPECTED = {"hotpot_train": 90447, "hotpot_validation": 7405, "halubench": 14900}


def parquet_rows(files):
    import pyarrow.parquet as pq

    return sum(pq.ParquetFile(f).metadata.num_rows for f in files)


def size_mb(files):
    return sum(Path(f).stat().st_size for f in files) / 2**20


def check(name, got, expected):
    flag = "OK" if got == expected else f"WARNING: expected {expected:,}"
    print(f"  {name}: {got:,} rows  [{flag}]")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--only", choices=["all", "halubench", "hotpotqa"], default="all")
    args = ap.parse_args()

    from huggingface_hub import snapshot_download

    cfg = load_config(args.config)
    data = ensure_dir(cfg["paths"]["data_dir"])
    hc, hb = cfg["hotpotqa"], cfg["halubench"]

    if args.only in ("all", "hotpotqa"):
        print(f"Downloading HotpotQA ({hc['config']}) from {hc['hf_name']} ...")
        snapshot_download(repo_id=hc["hf_name"], repo_type="dataset", local_dir=str(data / "hotpot_qa"),
                          allow_patterns=[f"{hc['config']}/*.parquet", "README.md"])
        for split, key in (("train", "hotpot_train"), ("validation", "hotpot_validation")):
            files = sorted((data / "hotpot_qa" / hc["config"]).glob(f"{split}-*.parquet"))
            print(f"  {len(files)} file(s), {size_mb(files):.0f} MB")
            check(f"HotpotQA {split}", parquet_rows(files), EXPECTED[key])

    if args.only in ("all", "halubench"):
        print(f"Downloading HaluBench from {hb['hf_name']} ...")
        snapshot_download(repo_id=hb["hf_name"], repo_type="dataset", local_dir=str(data / "halubench"),
                          allow_patterns=["data/*.parquet", "README.md"])
        files = sorted((data / "halubench" / "data").glob("*.parquet"))
        print(f"  {len(files)} file(s), {size_mb(files):.1f} MB")
        check("HaluBench", parquet_rows(files), EXPECTED["halubench"])

        import pyarrow.parquet as pq

        rows = [r for f in files for r in pq.read_table(f).to_pylist()]
        print("  rows per source:", dict(Counter(r["source_ds"] for r in rows)))
        print("  labels:", dict(Counter(r["label"] for r in rows)))
        sample = clean_and_sample_halubench(rows, hb["per_source"], cfg["seed"])
        dev, test = split_dev_test(sample, cfg["verifier"]["dev_fraction"], cfg["seed"])
        out = ensure_dir(data / "samples")
        write_jsonl(out / "halubench_dev.jsonl", dev)
        write_jsonl(out / "halubench_test.jsonl", test)
        print(f"  paper subset: {len(sample)} answers -> dev {len(dev)}, test {len(test)} "
              f"(saved in {out}/halubench_dev.jsonl and halubench_test.jsonl)")
        print("  unsupported share in test:", round(sum(r['unsupported'] for r in test) / max(len(test), 1), 3))

    print(f"Done. Datasets are in {data.resolve()}")


if __name__ == "__main__":
    main()
