"""Why do the reproduced retrieval scores differ from the values printed in the base paper?

  python scripts/11_repro_investigation.py --config configs/free_gpu.yaml [--dense]

Re-runs BM25 (and optionally MPNet) on the same 10,000 sampled training questions under controlled variants of
corpus construction, relevance labels and metric computation:
  A  ours: global de-duplication of identical sentences; qrels = de-duplicated ids of the supporting sentences;
  B  question-scoped ids (base repository's "passages_with_ids"): every question contributes its own copy of
     each supporting-paragraph sentence (no global de-duplication); qrels = only that question's own copies;
  C  as B, but a retrieved copy of a relevant sentence from another question counts as relevant (text identity);
  D  as A, metrics with pytrec_eval instead of our implementation (checks the metric code).
Also reports corpus sizes, relevant documents per question, and how often the top 10 of variant B contains a
text-identical copy of a relevant sentence that B scores as non-relevant.
Writes outputs/retrieval/repro_investigation.json.
"""

import argparse
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.data import build_sentence_corpus, load_hotpotqa, sample_examples  # noqa: E402
from acv.ir_metrics import evaluate_run  # noqa: E402
from acv.retrieval import BM25Index  # noqa: E402
from acv.utils import load_config, normalize_text, set_seed, write_json  # noqa: E402


def log(s):
    print(s, flush=True)


def row_scoped_corpus(examples):
    """Base repository style: doc ids '<row>_<i>' over each question's supporting-paragraph sentences."""
    texts, ids, qrels, owner = [], [], {}, []
    for r, ex in enumerate(examples):
        sf = set(ex["sf_titles"])
        para = dict(zip(ex["titles"], ex["sentences"]))
        gt = set()
        for title, sid in zip(ex["sf_titles"], ex["sf_sent_ids"]):
            sents = para.get(title, [])
            if 0 <= sid < len(sents):
                gt.add(normalize_text(sents[sid]))
        rel, i = {}, 0
        for title, sents in zip(ex["titles"], ex["sentences"]):
            if title not in sf:
                continue
            for s in sents:
                if not normalize_text(s):
                    continue
                did = f"{r}_{i}"
                texts.append(s.strip()); ids.append(did); owner.append(r)
                if normalize_text(s) in gt:
                    rel[did] = 1
                i += 1
        qrels[ex["id"]] = rel
    return texts, ids, qrels


def pytrec(run, qrels, cuts=(3, 5, 10)):
    try:
        import pytrec_eval
    except ImportError:
        return None
    metrics = {f"map_cut.{c}" for c in cuts} | {f"ndcg_cut.{c}" for c in cuts}
    r = {q: {d: float(len(docs) - i) for i, d in enumerate(docs)} for q, docs in run.items()}
    q = {k: v for k, v in qrels.items() if k in run and v}
    res = pytrec_eval.RelevanceEvaluator(q, metrics).evaluate(r)
    out = {}
    for c in cuts:
        out[f"MAP@{c}"] = float(np.mean([v[f"map_cut_{c}"] for v in res.values()]))
        out[f"NDCG@{c}"] = float(np.mean([v[f"ndcg_cut_{c}"] for v in res.values()]))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/free_gpu.yaml")
    ap.add_argument("--max-queries", type=int, default=10000)
    ap.add_argument("--max-questions", type=int, default=0, help="debugging only")
    ap.add_argument("--dense", action="store_true", help="also MPNet on variants A and B (GPU, ~1 h)")
    args = ap.parse_args()
    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    hc, rc = cfg["hotpotqa"], cfg["retrieval"]
    T0 = time.time()
    exs = load_hotpotqa(hc["hf_name"], hc["config"], hc["retrieval_split"], args.max_questions or None, cfg["seed"],
                        data_dir=cfg["paths"]["data_dir"], keep_paragraphs="supporting")
    queried = sample_examples(exs, min(args.max_queries, len(exs)), cfg["seed"])
    qids = [e["id"] for e in queried]; queries = [e["question"] for e in queried]
    R = {"n_questions_split": len(exs), "n_queries": len(qids), "variants": {}}

    # A: ours
    _, texts_a, qrels_a = build_sentence_corpus(exs, "supporting")
    qa = {q: qrels_a[q] for q in qids}
    # B: question-scoped ids
    texts_b, ids_b, qrels_b_all = row_scoped_corpus(exs)
    qb = {q: qrels_b_all[q] for q in qids}
    R["corpus"] = {"A_documents": len(texts_a), "B_documents": len(texts_b),
                   "A_relevant_per_query": float(np.mean([len(v) for v in qa.values()])),
                   "B_relevant_per_query": float(np.mean([len(v) for v in qb.values()])),
                   "A_queries_without_relevant": int(sum(not v for v in qa.values())),
                   "B_queries_without_relevant": int(sum(not v for v in qb.values()))}
    log(f"[corpus] {R['corpus']}")

    def bm25(texts):
        t0 = time.time()
        hits = BM25Index(**rc["bm25"]).fit(texts).search(queries, 10)
        log(f"  BM25 over {len(texts):,} documents: {(time.time() - t0) / 60:.1f} min")
        return hits

    hits_a = bm25(texts_a)
    run_a = {q: [f"d{d}" for d, _ in h[:10]] for q, h in zip(qids, hits_a)}
    R["variants"]["A_ours"] = {"bm25": evaluate_run(run_a, qa)["mean"]}
    R["variants"]["D_pytrec_eval_on_A"] = {"bm25": pytrec(run_a, qa)}
    hits_b = bm25(texts_b)
    run_b = {q: [ids_b[d] for d, _ in h[:10]] for q, h in zip(qids, hits_b)}
    R["variants"]["B_question_scoped"] = {"bm25": evaluate_run(run_b, qb)["mean"],
                                         "bm25_pytrec_eval": pytrec(run_b, qb)}
    # C: relevance by text identity on the B run
    norm_b = [normalize_text(t) for t in texts_b]
    qc, run_c = {}, {}
    dup_hits, total = 0, 0
    # compute text-identity relevance efficiently
    id_pos = {d: k for k, d in enumerate(ids_b)}
    for q, h in zip(qids, hits_b):
        rel_txt = {norm_b[id_pos[d]] for d in qb[q]}
        ranked, seen = [], set()
        for d, _ in h[:10]:
            total += 1
            if norm_b[d] in rel_txt and ids_b[d] not in qb[q]:
                dup_hits += 1
            if norm_b[d] not in seen:          # identical sentences collapse to one document, as in variant A
                seen.add(norm_b[d]); ranked.append(norm_b[d])
        qc[q] = {t: 1 for t in rel_txt}
        run_c[q] = ranked
    R["variants"]["C_text_identity_on_B"] = {"bm25": evaluate_run(run_c, qc)["mean"]}
    R["duplicates"] = {"top10_slots": total, "copies_of_relevant_counted_nonrelevant_in_B": dup_hits,
                       "share": dup_hits / max(1, total)}
    for k, v in R["variants"].items():
        log(f"[{k}] {v}")
    log(f"[duplicates] {R['duplicates']}")

    if args.dense:
        from acv.retrieval import DenseEncoder, DenseIndex
        enc = DenseEncoder(rc["models"]["mpnet"], pooling="st", batch_size=rc["batch_size"])
        qv = enc.encode(queries)
        for tag, texts, ids, qr in (("A_ours", texts_a, None, qa), ("B_question_scoped", texts_b, ids_b, qb)):
            t0 = time.time()
            hits = DenseIndex(enc.encode(texts)).search(qv, 10)
            run = {q: [(f"d{d}" if ids is None else ids[d]) for d, _ in h[:10]] for q, h in zip(qids, hits)}
            R["variants"][tag]["mpnet"] = evaluate_run(run, qr)["mean"]
            log(f"[{tag} mpnet] {R['variants'][tag]['mpnet']} ({(time.time() - t0) / 60:.1f} min)")
    R["minutes"] = (time.time() - T0) / 60
    out = Path(cfg["paths"]["out_dir"]) / "retrieval" / "repro_investigation.json"
    write_json(out, R)
    log(f"saved {out}")


if __name__ == "__main__":
    main()
