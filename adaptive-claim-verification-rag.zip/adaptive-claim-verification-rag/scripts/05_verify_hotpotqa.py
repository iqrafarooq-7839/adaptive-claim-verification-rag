"""Step 5 (proposed method, experiment E3): verify the reproduced HotpotQA answers.

Uses the calibrator, tau and theta selected on HaluBench dev (step 4), i.e. a transfer setting.
  python scripts/05_verify_hotpotqa.py                    # all *_judged.jsonl files from step 3
  python scripts/05_verify_hotpotqa.py --claim-judge-n 300  # also claim-level reference labels (API cost)

Reports per model and retriever: unsupported-claim rate (RQ1), detection of judge-labelled
hallucinated answers among attempted answers, claim-level P/R/F1 against the claim judge,
and the share of claims escalated to the NLI verifier (RQ3).
"""

import argparse
import pickle
import random
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.judge import AnthropicJudge  # noqa: E402
from acv.metrics import prf  # noqa: E402
from acv.utils import device_name, load_config, read_jsonl, set_seed, write_json  # noqa: E402
from acv.verifier import AdaptiveVerifier, CheapScorer, NLIVerifier, decide, evaluate_offline  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--claim-judge-n", type=int, default=0)
    args = ap.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    vc, jc = cfg["verifier"], cfg["judge"]
    out_dir = Path(cfg["paths"]["out_dir"])
    saved = pickle.load(open(out_dir / "verifier" / "calibrator.pkl", "rb"))
    theta, tau = saved["theta"], saved["tau"]

    from sentence_transformers import SentenceTransformer

    emb = SentenceTransformer(vc["embedder"], device=device_name())
    embed_fn = lambda t: emb.encode(list(t), batch_size=64, normalize_embeddings=True, convert_to_numpy=True)
    ver = AdaptiveVerifier(CheapScorer(embed_fn), saved["calibrator"], NLIVerifier(vc["nli_model"]),
                           m=vc["premise_sentences"], theta=theta, tau=tau)
    judge = AnthropicJudge(jc["model"], jc["max_tokens"], jc["cache_dir"]) if args.claim_judge_n else None

    results = {"theta": theta, "tau": tau, "runs": {}}
    for f in sorted((out_dir / "generation").glob("*_judged.jsonl")):
        rows = [r for r in read_jsonl(f) if r.get("judge_label")]
        items = [ver.prepare(r["id"], r["question"], r["output"], r["contexts"],
                             meta={"label": r["judge_label"]}) for r in rows]
        ver.calibrate(items)
        ver.score_all_nli(items)
        attempted = [it for it in items if it.meta["label"] != "Insufficient Context" and it.claims]
        y = [int(it.meta["label"] == "Hallucinated") for it in attempted]
        entry = {"n_answers": len(items), "n_attempted": len(attempted),
                 "claims_per_attempted_answer": float(np.mean([len(it.claims) for it in attempted])) if attempted else 0}
        for mode in ("cheap", "nli", "adaptive"):
            r = evaluate_offline(attempted, mode, theta, tau)
            entry[mode] = {**prf(y, r["pred"]), "call_rate": r["call_rate"],
                           "flagged_answer_rate": float(np.mean(r["pred"])) if r["pred"] else 0.0}
        # RQ1: fraction of claims predicted unsupported by the adaptive verifier
        claim_flags = [int(f) for it in attempted for f in decide(it.p, it.v, "adaptive", theta, tau)[0]]
        entry["predicted_unsupported_claim_rate"] = float(np.mean(claim_flags)) if claim_flags else 0.0

        if judge:
            rng = random.Random(cfg["seed"])
            sample = rng.sample(attempted, min(args.claim_judge_n, len(attempted)))
            gold = {"cheap": [], "nli": [], "adaptive": []}
            for it in sample:
                ctx = " ".join(it.ctx_sents)
                labels = [judge.judge_claim(ctx, c)["label"] for c in it.claims]
                for mode in gold:
                    z, _, _ = decide(it.p, it.v, mode, theta, tau)
                    for lab, zz in zip(labels, z):
                        if lab:
                            gold[mode].append((int(lab == "Unsupported"), int(zz)))
            entry["claim_level_vs_judge"] = {m: prf([g for g, _ in v], [p for _, p in v]) for m, v in gold.items()}
            entry["claim_level_vs_judge"]["gold_unsupported_rate"] = (
                float(np.mean([g for g, _ in gold["adaptive"]])) if gold["adaptive"] else None)
        results["runs"][f.stem.replace("_judged", "")] = entry
        print(f.stem, {k: (v["f1"] if isinstance(v, dict) and "f1" in v else v) for k, v in entry.items()})

    write_json(out_dir / "verifier" / "hotpotqa_results.json", results)
    print(f"saved {out_dir / 'verifier' / 'hotpotqa_results.json'}")


if __name__ == "__main__":
    main()
