"""Step 5 (proposed method, experiment E3): verify the reproduced HotpotQA answers.

Uses the calibrator, tau and theta selected on HaluBench dev (step 4), i.e. a transfer setting.
  python scripts/05_verify_hotpotqa.py --config configs/free_gpu.yaml                     # all *_judged.jsonl files
  python scripts/05_verify_hotpotqa.py --config configs/free_gpu.yaml --claim-judge-n 300 # plus claim-level labels

Reports per model and retriever: unsupported-claim rate (RQ1), detection of judge-labelled
hallucinated answers among attempted answers, claim-level P/R/F1 against the claim judge,
and the share of claims escalated to the NLI verifier (RQ3).
"""

import argparse
import pickle
import random
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv import sync  # noqa: E402
from acv.judge import make_judge  # noqa: E402
from acv.metrics import prf  # noqa: E402
from acv.utils import device_name, free_gpu_memory, load_config, read_jsonl, set_seed, write_json  # noqa: E402
from acv.verifier import AdaptiveVerifier, CheapScorer, NLIVerifier, decide, evaluate_offline  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--claim-judge-n", type=int, default=0, help="answers per run to label claim by claim")
    ap.add_argument("--judge-backend", default=None, choices=["anthropic", "hf"])
    ap.add_argument("--tag", default="", help="use calibrator_<tag>.pkl from a variant run of step 4")
    args = ap.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    vc = cfg["verifier"]
    out_dir = Path(cfg["paths"]["out_dir"])
    suffix = f"_{args.tag}" if args.tag else ""
    cal_path = out_dir / "verifier" / f"calibrator{suffix}.pkl"
    if not cal_path.exists():
        raise SystemExit(f"{cal_path} not found: run scripts/04_verify_halubench.py first")
    with open(cal_path, "rb") as fh:
        saved = pickle.load(fh)
    theta, tau = saved["theta"], saved["tau"]
    embedder = saved.get("embedder", vc["embedder"])
    nli_model = saved.get("nli_model", vc["nli_model"])
    files = sorted((out_dir / "generation").glob("*_judged.jsonl"))
    if not files:
        raise SystemExit("no *_judged.jsonl files: run scripts/02_generate.py and scripts/03_judge.py first")

    from sentence_transformers import SentenceTransformer

    emb = SentenceTransformer(embedder, device=device_name())

    def embed_fn(texts):
        return emb.encode(list(texts), batch_size=128, normalize_embeddings=True, convert_to_numpy=True,
                          show_progress_bar=False)

    ver = AdaptiveVerifier(CheapScorer(embed_fn), saved["calibrator"],
                           NLIVerifier(nli_model, batch_size=vc["nli_batch_size"]),
                           m=saved.get("premise_sentences", vc["premise_sentences"]), theta=theta, tau=tau)

    results = {"theta": theta, "tau": tau, "embedder": embedder, "nli_model": nli_model, "runs": {}}
    pending = {}  # run name -> sampled items for claim-level judging
    for f in files:
        rows = [r for r in read_jsonl(f) if r.get("judge_label")]
        items = [ver.prepare(r["id"], r["question"], r["output"], r["contexts"],
                             meta={"label": r["judge_label"]}) for r in rows]
        ver.calibrate(items)
        ver.score_all_nli(items)
        attempted = [it for it in items if it.meta["label"] != "Insufficient Context" and it.claims]
        y = [int(it.meta["label"] == "Hallucinated") for it in attempted]
        entry = {"n_answers": len(items), "n_attempted": len(attempted),
                 "claims_per_attempted_answer": float(np.mean([len(it.claims) for it in attempted])) if attempted else 0}
        for mode in ("cheap", "nli", "adaptive"):
            r = evaluate_offline(attempted, mode, theta, tau)
            entry[mode] = {**prf(y, r["pred"]), "call_rate": r["call_rate"],
                           "flagged_answer_rate": float(np.mean(r["pred"])) if r["pred"] else 0.0}
        # RQ1: fraction of claims predicted unsupported by the adaptive verifier
        claim_flags = [int(z) for it in attempted for z in decide(it.p, it.v, "adaptive", theta, tau)[0]]
        entry["predicted_unsupported_claim_rate"] = float(np.mean(claim_flags)) if claim_flags else 0.0
        name = f.stem.replace("_judged", "")
        results["runs"][name] = entry
        if args.claim_judge_n and attempted:
            rng = random.Random(cfg["seed"])
            pending[name] = rng.sample(attempted, min(args.claim_judge_n, len(attempted)))
        print(name, {k: (round(v["f1"], 3) if isinstance(v, dict) and "f1" in v else v) for k, v in entry.items()})

    if pending:
        del ver, emb
        free_gpu_memory()  # make room for the judge model
        judge = make_judge(cfg, args.judge_backend)
        print(f"claim judge: {judge.name} / {judge.model}")
        for name, sample in pending.items():
            pairs = [(" ".join(it.ctx_sents), c) for it in sample for c in it.claims]
            labels = iter(judge.judge_claims(pairs))
            gold = {"cheap": [], "nli": [], "adaptive": []}
            for it in sample:
                labs = [next(labels)["label"] for _ in it.claims]
                for mode in gold:
                    z, _, _ = decide(it.p, it.v, mode, theta, tau)
                    gold[mode].extend((int(lab == "Unsupported"), int(zz)) for lab, zz in zip(labs, z) if lab)
            entry = results["runs"][name]
            entry["claim_level_vs_judge"] = {m: prf([g for g, _ in v], [p for _, p in v]) for m, v in gold.items()}
            entry["claim_level_vs_judge"]["n_claims"] = len(gold["adaptive"])
            entry["claim_level_vs_judge"]["gold_unsupported_rate"] = (
                float(np.mean([g for g, _ in gold["adaptive"]])) if gold["adaptive"] else None)
            entry["claim_level_vs_judge"]["judge"] = judge.model
            print(name, "claim-level F1:", {m: round(entry["claim_level_vs_judge"][m]["f1"], 3) for m in gold})

    write_json(out_dir / "verifier" / f"hotpotqa_results{suffix}.json", results)
    sync.push(cfg, "verifier on HotpotQA finished")
    print(f"saved {out_dir / 'verifier' / f'hotpotqa_results{suffix}.json'}")


if __name__ == "__main__":
    main()
