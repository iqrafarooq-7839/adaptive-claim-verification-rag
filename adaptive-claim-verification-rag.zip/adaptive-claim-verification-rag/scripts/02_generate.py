"""Step 2 (base-paper reproduction): answer 1,200 sampled HotpotQA questions with a frozen LLM.

Requires the validation retrieval run from step 1, e.g.
  python scripts/01_retrieval.py --split validation --methods contriever hybrid_li_rerank
  python scripts/02_generate.py --model qwen3_4b --retriever hybrid_li_rerank
  python scripts/02_generate.py --model qwen3_4b --retriever contriever
The script resumes automatically if it is interrupted.
"""

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.data import sample_examples  # noqa: E402
from acv.generation import HFGenerator, build_prompt  # noqa: E402
from acv.utils import append_jsonl, iter_jsonl, load_config, read_jsonl, set_seed  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--model", required=True, help="key in config generation.models, e.g. qwen3_4b")
    ap.add_argument("--retriever", default="hybrid_li_rerank")
    ap.add_argument("--retrieval-dir", default=None, help="defaults to outputs/retrieval/<generation_split>")
    ap.add_argument("--n", type=int, default=None)
    args = ap.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    gc, hc = cfg["generation"], cfg["hotpotqa"]
    rdir = Path(args.retrieval_dir or Path(cfg["paths"]["out_dir"]) / "retrieval" / hc["generation_split"])
    texts = json.loads((rdir / "corpus.json").read_text(encoding="utf-8"))
    questions = read_jsonl(rdir / "questions.jsonl")
    runs = {r["qid"]: r["docs"] for r in iter_jsonl(rdir / "runs.jsonl") if r["method"] == args.retriever}
    if not runs:
        raise SystemExit(f"no run for {args.retriever} in {rdir}/runs.jsonl")

    sample = sample_examples(questions, args.n or hc["gen_sample_size"], cfg["seed"])
    out = Path(cfg["paths"]["out_dir"]) / "generation" / f"{args.model}__{args.retriever}.jsonl"
    done = {r["id"] for r in iter_jsonl(out)} if out.exists() else set()
    todo = [q for q in sample if q["id"] not in done]
    print(f"{len(sample)} sampled, {len(done)} already done, {len(todo)} to generate -> {out}")

    gen = HFGenerator(gc["models"][args.model], gc["max_new_tokens"], gc["load_in_4bit"])
    for i, q in enumerate(todo, 1):
        ctx = [texts[int(d[1:])] for d in runs[q["id"]][: gc["context_docs"]]]
        output = gen.generate(build_prompt(q["question"], ctx, gc["max_ctx_chars"]))
        append_jsonl(out, {"id": q["id"], "question": q["question"], "gold": q["answer"], "type": q.get("type"),
                           "contexts": ctx, "output": output, "model": args.model, "retriever": args.retriever})
        if i % 50 == 0:
            print(f"  {i}/{len(todo)}")


if __name__ == "__main__":
    main()
