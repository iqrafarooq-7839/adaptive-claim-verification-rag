"""Step 2 (base-paper reproduction): answer 1,200 sampled HotpotQA questions with a frozen LLM.

Needs the retrieval run of step 1 (same --config), with the two retrievers the base paper uses:
  python scripts/01_retrieval.py --config configs/free_gpu.yaml
  python scripts/02_generate.py  --config configs/free_gpu.yaml --model qwen3_4b
(both retrievers, Contriever and Hybrid LI + Rerank, are processed with one model load)

Every answer is written to disk as soon as it is generated; re-running the same command after an
interrupted session continues with the questions that are still missing.
"""

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv import sync  # noqa: E402
from acv.data import sample_examples  # noqa: E402
from acv.generation import HFGenerator, build_prompt, model_settings  # noqa: E402
from acv.utils import (append_jsonl, gpu_summary, iter_jsonl, load_config, read_jsonl, retrieval_run_dir,  # noqa: E402
                       set_seed)


def drop_model_cache(model_id: str) -> None:
    """Delete one model from the Hugging Face cache to free disk for the next model."""
    try:
        from huggingface_hub import scan_cache_dir

        info = scan_cache_dir()
        hashes = [rev.commit_hash for repo in info.repos if repo.repo_id == model_id for rev in repo.revisions]
        if hashes:
            strategy = info.delete_revisions(*hashes)
            print(f"[generation] freeing {strategy.expected_freed_size_str} of disk ({model_id})")
            strategy.execute()
    except Exception as exc:
        print(f"[generation] could not clear the model cache ({type(exc).__name__}: {exc})")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--model", required=True, help="key in config generation.models, e.g. qwen3_4b")
    ap.add_argument("--retrievers", "--retriever", nargs="+", default=["contriever", "hybrid_li_rerank"],
                    help="one or both retrievers; the model is loaded once for all of them")
    ap.add_argument("--retrieval-dir", default=None, help="defaults to the step-1 directory for this config")
    ap.add_argument("--n", type=int, default=None, help="number of questions (default: generation sample size)")
    ap.add_argument("--batch-size", type=int, default=None)
    ap.add_argument("--dtype", default=None, choices=["auto", "bfloat16", "float16", "float32"])
    ap.add_argument("--load-in-4bit", action="store_true", help="needed for the 8B model on a single 16 GB GPU")
    ap.add_argument("--cleanup-cache", action="store_true", help="delete the model files when finished")
    args = ap.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    gc, hc = cfg["generation"], cfg["hotpotqa"]
    rdir = Path(args.retrieval_dir) if args.retrieval_dir else retrieval_run_dir(cfg, hc["generation_split"])
    if not (rdir / "runs.jsonl").exists():
        raise SystemExit(f"{rdir}/runs.jsonl not found: run scripts/01_retrieval.py with the same --config first")
    questions = read_jsonl(rdir / "questions.jsonl")
    sample = sample_examples(questions, args.n or hc["gen_sample_size"], cfg["seed"])
    wanted = {q["id"] for q in sample}
    runs = {r: {} for r in args.retrievers}
    for row in iter_jsonl(rdir / "runs.jsonl"):
        if row["method"] in runs and row["qid"] in wanted:
            runs[row["method"]][row["qid"]] = row["docs"]
    for r in args.retrievers:
        if len(runs[r]) < len(sample):
            raise SystemExit(f"retriever '{r}' has results for {len(runs[r])} of {len(sample)} sampled questions in "
                             f"{rdir}/runs.jsonl: run scripts/01_retrieval.py --methods {r} with the same --config")

    out_dir = Path(cfg["paths"]["out_dir"]) / "generation"
    plan = []
    for r in args.retrievers:
        out = out_dir / f"{args.model}__{r}.jsonl"
        done = {x["id"] for x in iter_jsonl(out)} if out.exists() else set()
        todo = [q for q in sample if q["id"] not in done]
        print(f"{r}: {len(sample)} sampled, {len(done)} already done, {len(todo)} to generate -> {out}")
        plan.append((r, out, todo))
    print(f"GPU: {gpu_summary()}")
    if not any(todo for _, _, todo in plan):
        print("nothing left to generate")
        return

    st = model_settings(gc, args.model)
    if args.batch_size:
        st["batch_size"] = args.batch_size
    if args.dtype:
        st["dtype"] = args.dtype
    if args.load_in_4bit:
        st["load_in_4bit"] = True
    model_id = gc["models"][args.model]
    print(f"loading {model_id} (dtype={st['dtype']}, 4-bit={st['load_in_4bit']}, batch={st['batch_size']})")
    gen = HFGenerator(model_id, gc["max_new_tokens"], st["load_in_4bit"], st["dtype"], st["batch_size"])
    texts = json.loads((rdir / "corpus.json").read_text(encoding="utf-8"))
    bs = st["batch_size"]

    for r, out, todo in plan:
        if not todo:
            continue
        items = []
        for q in todo:
            ctx = [texts[int(d[1:])] for d in runs[r][q["id"]][: gc["context_docs"]]]
            items.append((q, ctx, build_prompt(q["question"], ctx, gc["max_ctx_chars"])))
        items.sort(key=lambda it: len(it[2]))  # similar lengths in a batch: less padding, faster
        t0, last_sync = time.time(), time.time()
        for s in range(0, len(items), bs):
            chunk = items[s:s + bs]
            outputs = gen.generate_many([p for _, _, p in chunk])
            for (q, ctx, _), output in zip(chunk, outputs):
                append_jsonl(out, {"id": q["id"], "question": q["question"], "gold": q["answer"],
                                   "type": q.get("type"), "contexts": ctx, "output": output, "model": args.model,
                                   "retriever": r, "dtype": str(gen.dtype).replace("torch.", ""),
                                   "batch_size": bs, "load_in_4bit": bool(st["load_in_4bit"])})
            n_done = min(s + bs, len(items))
            if (s // bs) % 10 == 9 or n_done == len(items):
                rate = n_done / (time.time() - t0)
                print(f"  [{args.model} / {r}] {n_done}/{len(items)}  ({rate * 60:.0f} answers/min, "
                      f"about {(len(items) - n_done) / rate / 60:.0f} min left)", flush=True)
            if time.time() - last_sync > 1200:  # save progress off the machine every 20 minutes
                sync.push(cfg, f"generation {args.model} {r} {n_done}/{len(items)}")
                last_sync = time.time()
        sync.push(cfg, f"generation {args.model} {r} finished")

    if args.cleanup_cache:
        del gen
        drop_model_cache(model_id)


if __name__ == "__main__":
    main()
