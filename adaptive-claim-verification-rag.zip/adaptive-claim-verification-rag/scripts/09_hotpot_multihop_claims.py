"""Controlled multi-hop claim verification on HotpotQA (distractor setting, validation split).

  python scripts/09_hotpot_multihop_claims.py --config configs/free_gpu.yaml --n 1000

Every HotpotQA question needs facts from two supporting documents. For each sampled question we build two
claims with exact labels:
  supported   "The answer to the question <q> is <gold answer>."
  unsupported the same claim with a hard wrong answer: the other entity of a comparison question, the
              flipped yes/no, a perturbed number, the bridge entity (first-hop document) of a bridge question,
              or the title of a distractor paragraph.
The evidence is the 10 paragraphs of the question (2 supporting + 8 distractors), split into sentences.

Measured (test split, thresholds from the dev split):
  * premise construction: single sentence, top-k concatenation (k = 2, 4, 8), two-hop evidence chain,
    gold supporting sentences (oracle) and the full passage (chunked) — whether the premise covers BOTH
    supporting documents, and verification AUROC / F1 per verifier;
  * calibration with genuine claim-level labels (dev-fitted) versus the HaluBench calibrator (transfer);
  * the adaptive gate at matched budgets on claims that require two documents.
Writes outputs/verifier/hotpot_multihop_claims.json.
"""

import argparse
import gc
import json
import pickle
import random
import re
import sys
import time
import traceback
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.data import load_hotpotqa, sample_examples  # noqa: E402
from acv.metrics import auroc, prf  # noqa: E402
from acv.utils import device_name, gpu_summary, load_config, normalize_text, set_seed, write_json  # noqa: E402
from acv.v2 import (EXT_FEATURES, FeatureCalibrator, NLIProbs, add_extended_features, best_threshold,  # noqa: E402
                    budget_curve, build_premises, claim_level_scores, ece, ext_matrix, load_hhem, load_minicheck,
                    make_item_from_claims, score_premises)
from acv.verifier import FEATURES, CheapScorer  # noqa: E402


def log(s):
    print(s, flush=True)


def free():
    gc.collect()
    try:
        import torch
        torch.cuda.empty_cache()
    except Exception:
        pass


_NUM = re.compile(r"\d+")


def corrupt(ex, rng):
    """A hard, wrong answer for the question and the kind of corruption used."""
    gold = ex["answer"].strip()
    gl = gold.lower()
    sf = list(dict.fromkeys(ex["sf_titles"]))
    distract = [t for t in ex["titles"] if t not in sf]
    if gl in ("yes", "no"):
        return ("no" if gl == "yes" else "yes"), "yes_no_flip"
    if ex.get("type") == "comparison":
        others = [t for t in sf if normalize_text(t) != normalize_text(gold) and normalize_text(gold) not in normalize_text(t)]
        if others:
            return others[0], "comparison_other_entity"
    m = _NUM.search(gold)
    if m and len(gold) <= 20:
        n = int(m.group(0))
        delta = rng.choice([1, 2, 3, 5]) * rng.choice([-1, 1]) if n > 31 else rng.choice([1, 2])
        return gold[:m.start()] + str(max(0, n + delta)) + gold[m.end():], "number_perturbed"
    bridge = [t for t in sf if normalize_text(t) != normalize_text(gold) and normalize_text(gold) not in normalize_text(t)]
    if ex.get("type") == "bridge" and bridge and rng.random() < 0.5:
        return bridge[0], "bridge_entity"
    if distract:
        return rng.choice(distract), "distractor_title"
    return (bridge[0] if bridge else gold + " Jr."), "fallback"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/free_gpu.yaml")
    ap.add_argument("--n", type=int, default=1000)
    ap.add_argument("--split", default="validation")
    ap.add_argument("--small-nli", default="cross-encoder/nli-MiniLM2-L6-H768")
    ap.add_argument("--large-nli", default="MoritzLaurer/DeBERTa-v3-large-mnli-fever-anli-ling-wanli")
    ap.add_argument("--minicheck", default="lytang/MiniCheck-DeBERTa-v3-Large")
    ap.add_argument("--halubench-artifacts", default=None, help="v2_artifacts.pkl from script 08 (transfer)")
    ap.add_argument("--skip", nargs="*", default=[])
    args = ap.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    vc = cfg["verifier"]
    dev_name = device_name()
    rng = random.Random(cfg["seed"])
    out_dir = Path(cfg["paths"]["out_dir"]) / "verifier"
    out_dir.mkdir(parents=True, exist_ok=True)
    R = {"gpu": gpu_summary(), "n_questions": args.n}
    T0 = time.time()

    exs = load_hotpotqa(cfg["hotpotqa"]["hf_name"], cfg["hotpotqa"]["config"], args.split, None, cfg["seed"],
                        data_dir=cfg["paths"]["data_dir"], keep_paragraphs="all")
    exs = sample_examples(exs, args.n, cfg["seed"])
    from sentence_transformers import SentenceTransformer
    emb = SentenceTransformer(vc["embedder"], device=dev_name)
    scorer = CheapScorer(lambda t: emb.encode(list(t), batch_size=256, normalize_embeddings=True,
                                              convert_to_numpy=True, show_progress_bar=False))
    items, kinds = [], {}
    qids = [e["id"] for e in exs]
    rng2 = random.Random(cfg["seed"] + 1)
    rng2.shuffle(qids)
    dev_q = set(qids[: int(round(len(qids) * vc["dev_fraction"]))])
    for ex in exs:
        ctx, para, gold_idx = [], [], {}
        for p, (title, sents) in enumerate(zip(ex["titles"], ex["sentences"])):
            for j, s in enumerate(sents):
                if s.strip():
                    if title in ex["sf_titles"] and any(t == title and sid == j for t, sid in zip(ex["sf_titles"], ex["sf_sent_ids"])):
                        gold_idx.setdefault(title, []).append(len(ctx))
                    ctx.append(s.strip()); para.append(p)
        wrong, kind = corrupt(ex, rng)
        kinds[kind] = kinds.get(kind, 0) + 1
        for lab, ans in ((0, ex["answer"]), (1, wrong)):
            it = make_item_from_claims(scorer, f"{ex['id']}_{lab}", ex["question"], [ans], ctx,
                                       {"unsupported": lab, "type": ex.get("type"), "qid": ex["id"], "para": para,
                                        "gold_idx": gold_idx, "split": "dev" if ex["id"] in dev_q else "test",
                                        "corruption": kind if lab else None, "source": ex.get("type")}, ans)
            items.append(it)
    R["corruptions"] = kinds
    dev = [it for it in items if it.meta["split"] == "dev"]
    test = [it for it in items if it.meta["split"] == "test"]
    log(f"claims: dev {len(dev)}, test {len(test)}; corruptions {kinds}")

    small = NLIProbs(args.small_nli, batch_size=64)
    add_extended_features(items, small)
    del small; free()

    # ---- premise coverage of the two supporting documents -------------------------------------------------
    strategies = ["top1", "top2", "top4", "top8", "chain"]
    prem = {s: (build_premises(dev, s), build_premises(test, s)) for s in strategies}
    prem["gold"] = tuple([[" ".join(it.ctx_sents[j] for j in sorted(sum(it.meta["gold_idx"].values(), [])))] for it in part]
                         for part in (dev, test))
    prem["full"] = tuple([[" ".join(it.ctx_sents)] for it in part] for part in (dev, test))
    R["coverage"] = {}
    for s in strategies:
        both, anyc, ntoks = [], [], []
        for it, ps in zip(test, prem[s][1]):
            p = ps[0]
            got = {t: any(it.ctx_sents[j] in p for j in idx) for t, idx in it.meta["gold_idx"].items()}
            both.append(len(got) >= 2 and all(got.values())); anyc.append(any(got.values()))
            ntoks.append(len(p.split()))
        R["coverage"][s] = {"both_supporting_docs": float(np.mean(both)), "any_supporting_doc": float(np.mean(anyc)),
                            "mean_words": float(np.mean(ntoks))}
        log(f"[coverage {s}] both docs {R['coverage'][s]['both_supporting_docs']:.3f}, any {R['coverage'][s]['any_supporting_doc']:.3f}, "
            f"{R['coverage'][s]['mean_words']:.0f} words")

    # ---- verifiers on each premise ---------------------------------------------------------------------------
    V = {}

    def add(name, v_dev, v_test):
        V[name] = ([x[0] for x in v_dev], [x[0] for x in v_test])

    for tag, model in (("nli_base", vc["nli_model"]), ("nli_large", args.large_nli)):
        if tag == "nli_large" and "large" in args.skip:
            continue
        try:
            nli = NLIProbs(model, batch_size=32)
            for s in strategies + ["gold"]:
                add(f"{tag}@{s}", score_premises(dev, prem[s][0], nli), score_premises(test, prem[s][1], nli))
            del nli; free()
        except Exception as e:
            log(f"[{tag}] FAILED: {e}")
    for tag, loader in (("minicheck", lambda: load_minicheck(args.minicheck, dev_name)), ("hhem", lambda: load_hhem(dev_name))):
        if tag in args.skip:
            continue
        try:
            sc = loader()
            for s in ("top4", "chain", "gold", "full"):
                add(f"{tag}@{s}", score_premises(dev, prem[s][0], sc), score_premises(test, prem[s][1], sc))
            del sc; free()
        except Exception as e:
            log(f"[{tag}] FAILED: {e}")
            traceback.print_exc()

    y_dev = np.asarray([it.meta["unsupported"] for it in dev]); y_test = np.asarray([it.meta["unsupported"] for it in test])
    types = np.asarray([it.meta["type"] for it in test])
    R["verification"] = {}
    for name, (vd, vt) in V.items():
        thr = best_threshold(vd, y_dev)
        res = claim_level_scores(vt, y_test, thr)
        res["threshold"] = thr
        for t in ("bridge", "comparison"):
            m = types == t
            if m.any():
                r = claim_level_scores(np.asarray(vt)[m], y_test[m], thr)
                res[f"{t}_auroc"], res[f"{t}_f1"] = r["auroc"], r["f1"]
        st = name.split("@")[1]
        if st in R["coverage"]:
            both = []
            for it, ps in zip(test, prem[st][1]):
                got = {t: any(it.ctx_sents[j] in ps[0] for j in idx) for t, idx in it.meta["gold_idx"].items()}
                both.append(len(got) >= 2 and all(got.values()))
            both = np.asarray(both)
            for flag, lab in ((True, "covered"), (False, "not_covered")):
                m = both == flag
                if m.sum() > 20 and len(set(y_test[m].tolist())) == 2:
                    res[f"auroc_when_premise_{lab}"] = claim_level_scores(np.asarray(vt)[m], y_test[m], thr)["auroc"]
        R["verification"][name] = res
        log(f"[verify {name}] AUROC={res['auroc']:.3f} F1={res['f1']:.3f} bridge={res.get('bridge_auroc', float('nan')):.3f} "
            f"comparison={res.get('comparison_auroc', float('nan')):.3f}")

    # ---- calibration with claim-level labels ----------------------------------------------------------------------
    Xd = np.asarray([ext_matrix(it)[0] for it in dev]); Xt = np.asarray([ext_matrix(it)[0] for it in test])
    R["calibration"] = {}
    cols = {"base4": list(FEATURES), "ext8": list(EXT_FEATURES)}
    for cname, cc in cols.items():
        cal = FeatureCalibrator(cc).fit(Xd, 1 - y_dev)
        pt = cal.predict(Xt)
        R["calibration"][f"{cname}|claim_labels_hotpot"] = {"auroc": auroc(y_test, 1 - pt), "ece": ece(pt, 1 - y_test)}
    if args.halubench_artifacts and Path(args.halubench_artifacts).exists():
        with open(args.halubench_artifacts, "rb") as fh:
            art = pickle.load(fh)
        for cname in ("base4", "ext8"):
            cal = art["calibrators"].get(cname)
            if cal is not None:
                pt = cal.predict(Xt)
                R["calibration"][f"{cname}|halubench_transfer"] = {"auroc": auroc(y_test, 1 - pt), "ece": ece(pt, 1 - y_test)}
    log(f"[calibration] {R['calibration']}")

    # ---- adaptive gate on two-document claims (claim = answer here) -------------------------------------------------
    cal = FeatureCalibrator(cols["ext8"]).fit(Xd, 1 - y_dev)
    for it in dev + test:
        it.p = cal.predict(ext_matrix(it))
    R["gate"] = {}
    for name in [n for n in V if n.endswith("@chain") or n.endswith("@top4") or n.endswith("@full")]:
        vd, vt = V[name]
        tau = best_threshold(vd, y_dev)
        for strat in ("uncertainty", "random", "disagreement"):
            seeds = (0, 1, 2, 3, 4) if strat == "random" else (0,)
            R["gate"][f"{name}|{strat}"] = budget_curve(test, [np.asarray([x]) for x in vt], tau, strat,
                                                        [0.0, 0.1, 0.2, 0.3, 0.5, 0.75, 1.0], seeds)
        log(f"[gate {name}] " + " ".join(f"{r['budget']}:{r['f1']:.3f}" for r in R["gate"][f"{name}|uncertainty"]))
    R["minutes"] = (time.time() - T0) / 60
    write_json(out_dir / "hotpot_multihop_claims.json", R)
    log(f"saved {out_dir / 'hotpot_multihop_claims.json'} ({R['minutes']:.1f} min)")


if __name__ == "__main__":
    main()
