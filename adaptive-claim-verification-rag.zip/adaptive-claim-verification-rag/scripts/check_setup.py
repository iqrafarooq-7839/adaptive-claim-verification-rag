"""Check that this machine can run the experiments (run it first on Kaggle or Colab).

  python scripts/check_setup.py --config configs/free_gpu.yaml

It reports the GPU(s), memory and disk, library versions, whether your Hugging Face token can open
the gated models (Gemma 2 and Llama 3.1 need a licence click on their model pages), and whether an
Anthropic key is present. Nothing is downloaded except three small config files.
"""

import argparse
import os
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.generation import model_settings  # noqa: E402
from acv.utils import gpu_summary, load_config  # noqa: E402


def version(mod):
    try:
        return __import__(mod).__version__
    except Exception:
        return "NOT INSTALLED"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/free_gpu.yaml")
    args = ap.parse_args()
    cfg = load_config(args.config)
    problems = []

    print("== Machine ==")
    print("GPU:", gpu_summary())
    try:
        import torch

        n_gpu = torch.cuda.device_count()
        mem = [torch.cuda.get_device_properties(i).total_memory / 2**30 for i in range(n_gpu)]
    except Exception:
        n_gpu, mem = 0, []
    if n_gpu == 0:
        problems.append("No GPU. On Kaggle: Settings > Accelerator > GPU T4 x2. On Colab: Runtime > Change runtime type > T4 GPU.")
    try:
        ram = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 2**30
        print(f"RAM: {ram:.0f} GB")
        if ram < 20:
            print("  note: under 20 GB RAM; keep hotpotqa.max_queries at 10000 or lower for the retrieval step")
    except (ValueError, OSError, AttributeError):
        pass
    print(f"Free disk here: {shutil.disk_usage('.').free / 2**30:.0f} GB (models and data need about 45 GB in total, "
          "but only one LLM is loaded at a time; the Hugging Face cache can be cleared between models)")

    print("\n== Libraries ==")
    for mod in ("torch", "transformers", "sentence_transformers", "datasets", "accelerate", "bitsandbytes",
                "sklearn", "anthropic", "nltk"):
        print(f"{mod}: {version(mod)}")
    tv = version("transformers")
    try:
        major, minor = (int(x) for x in tv.split(".")[:2])
        if (major, minor) < (4, 51):
            problems.append(f"transformers {tv} is too old for Qwen3 (needs 4.51 or newer): pip install -U transformers")
    except ValueError:
        problems.append("transformers is not installed: pip install -r requirements.txt")

    print("\n== Hugging Face access ==")
    token = os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    try:
        from huggingface_hub import HfApi, hf_hub_download

        api = HfApi()
        try:
            who = api.whoami()
            print("logged in as:", who.get("name"))
        except Exception:
            print("not logged in (no HF_TOKEN). Public models and both datasets still work.")
            if not token:
                problems.append("No HF_TOKEN: Gemma 2 and Llama 3.1 cannot be downloaded. Create a token at "
                                "https://huggingface.co/settings/tokens and add it as a secret named HF_TOKEN.")
        for key, model_id in cfg["generation"]["models"].items():
            try:
                hf_hub_download(model_id, "config.json")
                print(f"  {model_id}: access OK")
            except Exception as exc:
                print(f"  {model_id}: NO ACCESS ({type(exc).__name__})")
                problems.append(f"Open https://huggingface.co/{model_id} while logged in and accept the licence "
                                f"(needed for '{key}'); approval for Llama can take a few hours.")
    except ImportError:
        problems.append("huggingface_hub is not installed: pip install -r requirements.txt")

    print("\n== Judge ==")
    backend = cfg["judge"].get("backend", "anthropic")
    print("backend in this config:", backend)
    if backend == "anthropic" and not os.environ.get("ANTHROPIC_API_KEY"):
        problems.append("judge.backend is 'anthropic' but ANTHROPIC_API_KEY is not set. Add the key as a secret, "
                        "or use the free local judge: python scripts/03_judge.py --backend hf")
    if backend == "hf" and version("bitsandbytes") == "NOT INSTALLED" and cfg["judge"].get("hf_load_in_4bit", True):
        problems.append("The local judge loads in 4-bit and needs bitsandbytes: pip install bitsandbytes")

    print("\n== Plan for the generators on this machine ==")
    for key, model_id in cfg["generation"]["models"].items():
        st = model_settings(cfg["generation"], key)
        note = ""
        if key == "llama31_8b" and not st.get("load_in_4bit") and n_gpu == 1 and mem and mem[0] < 20:
            note = "  <-- one 16 GB GPU cannot hold this model in 16-bit: add --load-in-4bit"
            problems.append("Llama 3.1 8B needs two T4s (Kaggle) or --load-in-4bit on a single T4 (Colab).")
        print(f"  {key}: {model_id}  dtype={st['dtype']} batch={st['batch_size']} 4bit={st['load_in_4bit']}{note}")

    print("\n== Result ==")
    if problems:
        print("Fix these before the long runs:")
        for p in problems:
            print(" -", p)
        sys.exit(1)
    print("Everything needed is in place.")


if __name__ == "__main__":
    main()
