"""Step 3 (base-paper reproduction): LLM-as-a-judge labels and Table 5 metrics.

  python scripts/03_judge.py --config configs/free_gpu.yaml            # free: local open-weight judge
  python scripts/03_judge.py --backend anthropic                       # as in the base paper (needs ANTHROPIC_API_KEY)
  python scripts/03_judge.py --backend anthropic --model-id claude-sonnet-5-5   # after 30 Nov 2026

Judgements are cached, so an interrupted run continues where it stopped. Afterwards hand-check a
random subset (e.g. 120 rows) with scripts/export_for_annotation.py, as the base paper did, and
report the judge you used and its agreement with your labels.
"""

import argparse
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv import sync  # noqa: E402
from acv.judge import make_judge  # noqa: E402
from acv.metrics import answer_metrics  # noqa: E402
from acv.reported import TABLE5_HOTPOTQA  # noqa: E402
from acv.utils import load_config, read_jsonl, write_jsonl  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--backend", default=None, choices=["anthropic", "hf"])
    ap.add_argument("--model-id", default=None)
    ap.add_argument("--inputs", nargs="*", default=None)
    args = ap.parse_args()

    cfg = load_config(args.config)
    gen_dir = Path(cfg["paths"]["out_dir"]) / "generation"
    files = [Path(p) for p in args.inputs] if args.inputs else sorted(
        p for p in gen_dir.glob("*.jsonl") if not p.name.endswith("_judged.jsonl"))
    if not files:
        raise SystemExit(f"no generation files in {gen_dir}: run scripts/02_generate.py first")
    judge = make_judge(cfg, args.backend, args.model_id)
    print(f"judge: {judge.name} / {judge.model}")

    table = []
    for f in files:
        rows = read_jsonl(f)
        for s in range(0, len(rows), 64):
            chunk = rows[s:s + 64]
            for r, j in zip(chunk, judge.judge_answers([(r["question"], r["output"], r["gold"]) for r in chunk])):
                r["judge_label"], r["judge_explanation"], r["judge_stop"] = j["label"], j["explanation"], j["stop_reason"]
                r["judge_model"] = judge.model
            print(f"  {f.name}: {min(s + 64, len(rows))}/{len(rows)}", flush=True)
        write_jsonl(f.with_name(f.stem + "_judged.jsonl"), rows)
        model, retriever = rows[0]["model"], rows[0]["retriever"]
        m = answer_metrics(r["judge_label"] for r in rows)
        rep = TABLE5_HOTPOTQA.get((retriever, model), {})
        table.append({"retriever": retriever, "model": model, "judge": judge.model,
                      **{k: round(v, 2) for k, v in m.items()}, **{f"reported_{k}": v for k, v in rep.items()},
                      "judge_dropped": sum(r["judge_label"] is None for r in rows)})
        print(table[-1])
        sync.push(cfg, f"judge {f.stem}")

    out = Path(cfg["paths"]["out_dir"]) / "tables" / "table5_reproduction.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    cols = sorted({k for r in table for k in r}, key=lambda k: (k.startswith("reported"), k))
    with open(out, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(table)
    sync.push(cfg, "judge finished")
    print(f"saved {out}")


if __name__ == "__main__":
    main()
