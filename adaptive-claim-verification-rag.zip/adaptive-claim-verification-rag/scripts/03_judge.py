"""Step 3 (base-paper reproduction): LLM-as-a-judge labels and Table 5 metrics.

  export ANTHROPIC_API_KEY=...
  python scripts/03_judge.py                       # judges every file in outputs/generation
  python scripts/03_judge.py --model-id claude-sonnet-5-5   # after 30 Nov 2026 (report the change)

Then hand-check a random subset (e.g. 120 rows) with scripts/export_for_annotation.py, as the base paper did.
"""

import argparse
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.judge import AnthropicJudge  # noqa: E402
from acv.metrics import answer_metrics  # noqa: E402
from acv.reported import TABLE5_HOTPOTQA  # noqa: E402
from acv.utils import load_config, read_jsonl, write_jsonl  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--model-id", default=None)
    ap.add_argument("--inputs", nargs="*", default=None)
    args = ap.parse_args()

    cfg = load_config(args.config)
    jc = cfg["judge"]
    judge = AnthropicJudge(args.model_id or jc["model"], jc["max_tokens"], jc["cache_dir"])
    gen_dir = Path(cfg["paths"]["out_dir"]) / "generation"
    files = [Path(p) for p in args.inputs] if args.inputs else sorted(
        p for p in gen_dir.glob("*.jsonl") if not p.name.endswith("_judged.jsonl"))

    table = []
    for f in files:
        rows = read_jsonl(f)
        for r in rows:
            j = judge.judge_answer(r["question"], r["output"], r["gold"])
            r["judge_label"], r["judge_explanation"], r["judge_stop"] = j["label"], j["explanation"], j["stop_reason"]
        write_jsonl(f.with_name(f.stem + "_judged.jsonl"), rows)
        model, retriever = rows[0]["model"], rows[0]["retriever"]
        m = answer_metrics(r["judge_label"] for r in rows)
        rep = TABLE5_HOTPOTQA.get((retriever, model), {})
        table.append({"retriever": retriever, "model": model, **{k: round(v, 2) for k, v in m.items()},
                      **{f"reported_{k}": v for k, v in rep.items()},
                      "judge_dropped": sum(r["judge_label"] is None for r in rows)})
        print(table[-1])

    out = Path(cfg["paths"]["out_dir"]) / "tables" / "table5_reproduction.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    if table:
        with open(out, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=sorted({k for r in table for k in r}, key=lambda k: (k.startswith("reported"), k)))
            w.writeheader()
            w.writerows(table)
        print(f"saved {out}")


if __name__ == "__main__":
    main()
