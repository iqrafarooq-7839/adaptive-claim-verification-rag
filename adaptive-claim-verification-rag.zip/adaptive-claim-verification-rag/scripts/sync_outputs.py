"""Save or restore outputs/ in a private Hugging Face dataset repo (see src/acv/sync.py).

  export HF_TOKEN=<token with write permission>
  export ACV_SYNC=1
  python scripts/sync_outputs.py pull     # at the start of a session
  python scripts/sync_outputs.py push     # any time; the experiment scripts also push after each step
"""

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv import sync  # noqa: E402
from acv.utils import load_config  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["push", "pull"])
    ap.add_argument("--config", default="configs/default.yaml")
    args = ap.parse_args()
    cfg = load_config(args.config)
    if not sync.enabled():
        os.environ["ACV_SYNC"] = "1"  # running this script is an explicit request to sync
    if args.action == "pull":
        sync.pull(cfg)
    else:
        sync.push(cfg, "manual push")


if __name__ == "__main__":
    main()
