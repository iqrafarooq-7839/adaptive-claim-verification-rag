"""Step 6: paper tables (Markdown) and black-and-white figures in Times New Roman (PDF and PNG).

  python scripts/06_tables_figures.py --config configs/free_gpu.yaml
Use the same --config as in the earlier steps. Reads whatever results exist under outputs/ and skips the rest.
"""

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.plotting import plot_cost_f1, plot_grouped_bars, plot_reliability, setup_style  # noqa: E402
from acv.reported import TABLE1_HOTPOTQA, TABLE3_HOTPOTQA  # noqa: E402
from acv.utils import ensure_dir, load_config, retrieval_run_dir  # noqa: E402

LABEL = {"bm25": "BM25", "splade": "SPLADE", "mpnet": "MPNet", "contriever": "Contriever", "mpnet_qa": "MPNet-QA",
         "hybrid_rrf": "Hybrid RRF", "hybrid_combmnz": "Hybrid CombMNZ", "hybrid_li": "Hybrid LI",
         "hybrid_li_rerank": "Hybrid LI+Rerank"}


def md_table(header, rows):
    lines = ["| " + " | ".join(header) + " |", "|" + "---|" * len(header)]
    lines += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--retrieval-dir", default=None)
    args = ap.parse_args()
    cfg = load_config(args.config)
    out = Path(cfg["paths"]["out_dir"])
    figs, tabs = ensure_dir(out / "figures"), ensure_dir(out / "tables")
    font = setup_style()
    print(f"figure font: {font}")
    md = []

    # Retrieval reproduction (Tables 1 and 3)
    rdir = Path(args.retrieval_dir) if args.retrieval_dir else retrieval_run_dir(cfg)
    if (rdir / "metrics.csv").exists():
        rows = list(csv.DictReader(open(rdir / "metrics.csv")))
        rep = {**TABLE1_HOTPOTQA, **TABLE3_HOTPOTQA}
        n_q, n_d = rows[0].get("n_queries", "?"), rows[0].get("n_documents", "?")
        md.append(f"## Retrieval reproduction (HotpotQA): {n_q} questions searched over {n_d} sentence documents\n\n"
                  + md_table(
            ["Method", "MAP@10 (ours)", "95% CI", "MAP@10 (reported)", "NDCG@10 (ours)", "95% CI", "NDCG@10 (reported)"],
            [[LABEL.get(r["method"], r["method"]), r["MAP@10"], "±" + r.get("ci95_MAP@10", "?"),
              f"{rep.get(r['method'], {}).get('MAP@10', float('nan')):.4f}",
              r["NDCG@10"], "±" + r.get("ci95_NDCG@10", "?"),
              f"{rep.get(r['method'], {}).get('NDCG@10', float('nan')):.4f}"] for r in rows]))
        methods = [r["method"] for r in rows if r["method"] in rep]
        plot_grouped_bars([LABEL[m] for m in methods],
                          {"Reported [4]": [rep[m]["NDCG@10"] for m in methods],
                           "Reproduced": [float(next(r for r in rows if r["method"] == m)["NDCG@10"]) for m in methods]},
                          "NDCG@10", str(figs / "fig_retrieval_reproduction.pdf"), figsize=(6.2, 2.8))

    # End-to-end reproduction (Table 5)
    t5 = tabs / "table5_reproduction.csv"
    if t5.exists():
        rows = list(csv.DictReader(open(t5)))
        md.append("## End-to-end reproduction (HotpotQA, 1,200 questions)\n\n" + md_table(
            ["Retriever", "Model", "Acc.", "Halluc.", "Rej.", "Adj. Acc.", "Reported Acc.", "Reported Halluc.",
             "Reported Rej.", "Reported Adj. Acc.", "Judge"],
            [[r["retriever"], r["model"], r["accuracy"], r["hallucination_rate"], r["rejection_rate"],
              r["adjusted_accuracy"], r.get("reported_accuracy", ""), r.get("reported_hallucination_rate", ""),
              r.get("reported_rejection_rate", ""), r.get("reported_adjusted_accuracy", ""), r.get("judge", "")]
             for r in rows]))
        groups = [f"{r['model']}\n{LABEL.get(r['retriever'], r['retriever'])}" for r in rows]
        plot_grouped_bars(groups, {"Accuracy": [float(r["accuracy"]) for r in rows],
                                   "Hallucination": [float(r["hallucination_rate"]) for r in rows],
                                   "Rejection": [float(r["rejection_rate"]) for r in rows]},
                          "Percent of answers", str(figs / "fig_answer_breakdown.pdf"), figsize=(6.2, 2.8))

    # Proposed verifier on HaluBench (E2)
    hb = out / "verifier" / "halubench_results.json"
    if hb.exists():
        res = json.loads(hb.read_text())
        names = {"B1_cheap": "B1 Cheap only", "B2_uniform_nli": "B2 Uniform NLI", "B3_adaptive": "B3 Adaptive (ours)"}
        md.append("## Unsupported-answer detection on HaluBench (test split)\n\n" + md_table(
            ["Method", "Precision", "Recall", "F1 [95% CI]", "AUROC", "NLI call rate", "Verifier s/answer"],
            [[names[k], f"{res[k]['precision']:.3f}", f"{res[k]['recall']:.3f}",
              f"{res[k]['f1']:.3f} [{res[k]['f1_ci'][0]:.3f}, {res[k]['f1_ci'][1]:.3f}]", f"{res[k]['auroc']:.3f}",
              f"{res[k]['call_rate']:.2f}",
              f"{res['timing_verification_only'][{'B1_cheap': 'cheap', 'B2_uniform_nli': 'nli', 'B3_adaptive': 'adaptive'}[k]]['seconds_per_answer']:.4f}"]
             for k in names]))
        md.append("McNemar B2 vs B3: " + json.dumps(res["mcnemar_B2_vs_B3"]))
        md.append("## Ablations\n\n" + md_table(["Variant", "F1", "AUROC", "NLI call rate"],
                  [[k, f"{v['f1']:.3f}", f"{v['auroc']:.3f}", f"{v.get('call_rate', 1.0):.2f}"]
                   for k, v in res["ablations"].items()]))
        md.append("## Per-source F1 of B3\n\n" + md_table(["Source", "F1", "Recall", "Precision"],
                  [[s, f"{v['f1']:.3f}", f"{v['recall']:.3f}", f"{v['precision']:.3f}"] for s, v in res["per_source_B3"].items()]))
        sel = res["selection"]
        chosen = next(r for r in res["test_sweep"] if abs(r["theta"] - sel["theta"]) < 1e-9)
        plot_cost_f1(res["test_sweep"], chosen,
                     {"B1 Cheap only": (res["B1_cheap"]["call_rate"], res["B1_cheap"]["f1"]),
                      "B2 Uniform NLI": (res["B2_uniform_nli"]["call_rate"], res["B2_uniform_nli"]["f1"])},
                     str(figs / "fig_cost_f1.pdf"))
        cal = res["calibration"]
        plot_reliability({"Raw similarity": cal["curve_raw"], "Calibrated (ours)": cal["curve_calibrated"]},
                         str(figs / "fig_reliability.pdf"))
        md.append(f"ECE raw = {cal['ece_raw_similarity']:.3f}, calibrated = {cal['ece_calibrated']:.3f}")

    hq = out / "verifier" / "hotpotqa_results.json"
    if hq.exists():
        res = json.loads(hq.read_text())
        md.append("## Verifier on reproduced HotpotQA answers (transfer)\n\n" + md_table(
            ["Run", "Attempted", "Claims/answer", "Pred. unsupported claims", "F1 cheap", "F1 NLI", "F1 adaptive", "NLI call rate"],
            [[k, v["n_attempted"], f"{v['claims_per_attempted_answer']:.2f}", f"{v['predicted_unsupported_claim_rate']:.3f}",
              f"{v['cheap']['f1']:.3f}", f"{v['nli']['f1']:.3f}", f"{v['adaptive']['f1']:.3f}",
              f"{v['adaptive']['call_rate']:.2f}"] for k, v in res["runs"].items()]))

    (tabs / "paper_tables.md").write_text("\n\n".join(md) + "\n", encoding="utf-8")
    print(f"wrote {tabs / 'paper_tables.md'} and figures in {figs}")


if __name__ == "__main__":
    main()
