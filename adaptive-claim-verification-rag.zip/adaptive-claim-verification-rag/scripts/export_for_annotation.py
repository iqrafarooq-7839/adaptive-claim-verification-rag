"""Human verification of the LLM judge (the base paper checked a random subset by hand).

  python scripts/export_for_annotation.py export --n 120      # writes outputs/annotation/sample.csv
  (fill the column human_agrees with 1 or 0 in a spreadsheet)
  python scripts/export_for_annotation.py score               # prints judge-human agreement
"""

import argparse
import csv
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.utils import load_config, read_jsonl  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["export", "score"])
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--n", type=int, default=120)
    args = ap.parse_args()
    cfg = load_config(args.config)
    out_dir = Path(cfg["paths"]["out_dir"])
    path = out_dir / "annotation" / "sample.csv"

    if args.action == "export":
        rows = [r for f in sorted((out_dir / "generation").glob("*_judged.jsonl")) for r in read_jsonl(f)
                if r.get("judge_label")]
        rng = random.Random(cfg["seed"])
        sample = rng.sample(rows, min(args.n, len(rows)))
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["id", "model", "retriever", "question", "gold", "output", "judge_label", "human_agrees"])
            for r in sample:
                w.writerow([r["id"], r["model"], r["retriever"], r["question"], r["gold"], r["output"],
                            r["judge_label"], ""])
        print(f"wrote {len(sample)} rows to {path}")
    else:
        with open(path, encoding="utf-8") as fh:
            vals = [row["human_agrees"].strip() for row in csv.DictReader(fh) if row["human_agrees"].strip()]
        agree = sum(v == "1" for v in vals)
        print(f"judge-human agreement: {agree}/{len(vals)} = {100 * agree / max(len(vals), 1):.1f}%")


if __name__ == "__main__":
    main()
