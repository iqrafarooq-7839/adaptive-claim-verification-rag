"""Step 4 (proposed method, experiment E2): adaptive claim verification on HaluBench.

  python scripts/04_verify_halubench.py --config configs/free_gpu.yaml
About 10-20 minutes on a free T4 (it also runs on CPU, more slowly). No API key or gated model needed.

Outputs outputs/verifier/halubench_results.json (B1/B2/B3, timing, calibration, ablations, sweeps)
and the fitted calibrator (outputs/verifier/calibrator.pkl) reused by step 5.

To try a stronger verifier, change one flag, e.g.
  --nli-model MoritzLaurer/DeBERTa-v3-large-mnli-fever-anli-ling-wanli --tag large
(results then go to halubench_results_large.json so runs can be compared).
"""

import argparse
import pickle
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv import sync  # noqa: E402
from acv.data import load_halubench, split_dev_test  # noqa: E402
from acv.experiments import run_verifier_experiment  # noqa: E402
from acv.utils import device_name, gpu_summary, load_config, set_seed, write_json  # noqa: E402
from acv.verifier import NLIVerifier  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--per-source", type=int, default=None)
    ap.add_argument("--nli-model", default=None)
    ap.add_argument("--embedder", default=None)
    ap.add_argument("--premise-sentences", type=int, default=None)
    ap.add_argument("--tag", default="", help="suffix for the output files of a variant run")
    args = ap.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    vc = cfg["verifier"]
    if args.nli_model:
        vc["nli_model"] = args.nli_model
    if args.embedder:
        vc["embedder"] = args.embedder
    if args.premise_sentences:
        vc["premise_sentences"] = args.premise_sentences
    print(f"GPU: {gpu_summary()}")
    rows = load_halubench(cfg["halubench"]["hf_name"], args.per_source or cfg["halubench"]["per_source"],
                          cfg["seed"], data_dir=cfg["paths"]["data_dir"])
    dev, test = split_dev_test(rows, vc["dev_fraction"], cfg["seed"])
    print(f"HaluBench: {len(rows)} answers -> dev {len(dev)}, test {len(test)}")

    from sentence_transformers import SentenceTransformer

    emb_model = SentenceTransformer(vc["embedder"], device=device_name())

    def embed_fn(texts):
        return emb_model.encode(list(texts), batch_size=128, normalize_embeddings=True, convert_to_numpy=True,
                                show_progress_bar=False)

    nli = NLIVerifier(vc["nli_model"], batch_size=vc["nli_batch_size"])

    artifacts = {}
    res = run_verifier_experiment(dev, test, embed_fn, nli, cfg, artifacts=artifacts)
    res["models"] = {"embedder": vc["embedder"], "nli": vc["nli_model"], "device": gpu_summary(),
                     "premise_sentences": vc["premise_sentences"]}
    out = Path(cfg["paths"]["out_dir"]) / "verifier"
    suffix = f"_{args.tag}" if args.tag else ""
    write_json(out / f"halubench_results{suffix}.json", res)
    for k in ("B1_cheap", "B2_uniform_nli", "B3_adaptive"):
        r = res[k]
        print(f"{k:16s} F1={r['f1']:.3f} [{r['f1_ci'][0]:.3f}, {r['f1_ci'][1]:.3f}] "
              f"P={r['precision']:.3f} R={r['recall']:.3f} AUROC={r['auroc']:.3f} NLI-call rate={r['call_rate']:.2f}")
    print("per-source F1 (B3):", {s: round(v["f1"], 3) for s, v in res["per_source_B3"].items()})
    print("timing:", res["timing_verification_only"])
    with open(out / f"calibrator{suffix}.pkl", "wb") as fh:
        pickle.dump({"calibrator": artifacts["calibrator"], "tau": artifacts["tau"], "theta": artifacts["theta"],
                     "embedder": vc["embedder"], "nli_model": vc["nli_model"],
                     "premise_sentences": vc["premise_sentences"]}, fh)
    sync.push(cfg, "verifier on HaluBench finished")
    print(f"saved {out / f'halubench_results{suffix}.json'}")


if __name__ == "__main__":
    main()
