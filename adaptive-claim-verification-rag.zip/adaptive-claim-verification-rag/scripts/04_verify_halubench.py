"""Step 4 (proposed method, experiment E2): adaptive claim verification on HaluBench.

  python scripts/04_verify_halubench.py
Outputs outputs/verifier/halubench_results.json (B1/B2/B3, timing, calibration, ablations, sweeps)
and the fitted calibrator (outputs/verifier/calibrator.pkl) reused by step 5.
"""

import argparse
import pickle
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.data import load_halubench, split_dev_test  # noqa: E402
from acv.experiments import run_verifier_experiment  # noqa: E402
from acv.utils import device_name, load_config, set_seed, write_json  # noqa: E402
from acv.verifier import NLIVerifier  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--per-source", type=int, default=None)
    args = ap.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    vc = cfg["verifier"]
    rows = load_halubench(cfg["halubench"]["hf_name"], args.per_source or cfg["halubench"]["per_source"], cfg["seed"])
    dev, test = split_dev_test(rows, vc["dev_fraction"], cfg["seed"])
    print(f"HaluBench: {len(rows)} answers -> dev {len(dev)}, test {len(test)}")

    from sentence_transformers import SentenceTransformer

    emb_model = SentenceTransformer(vc["embedder"], device=device_name())
    embed_fn = lambda texts: emb_model.encode(list(texts), batch_size=64, normalize_embeddings=True,
                                              convert_to_numpy=True)
    nli = NLIVerifier(vc["nli_model"], batch_size=vc["nli_batch_size"])

    res = run_verifier_experiment(dev, test, embed_fn, nli, cfg)
    res["models"] = {"embedder": vc["embedder"], "nli": vc["nli_model"], "device": device_name()}
    out = Path(cfg["paths"]["out_dir"]) / "verifier"
    write_json(out / "halubench_results.json", res)
    for k in ("B1_cheap", "B2_uniform_nli", "B3_adaptive"):
        r = res[k]
        print(f"{k:16s} F1={r['f1']:.3f} [{r['f1_ci'][0]:.3f}, {r['f1_ci'][1]:.3f}] "
              f"P={r['precision']:.3f} R={r['recall']:.3f} AUROC={r['auroc']:.3f} NLI-call rate={r['call_rate']:.2f}")
    print("timing:", res["timing_verification_only"])
    print(f"saved {out / 'halubench_results.json'}")

    # Refit the calibrator on all HaluBench answers' single-claim dev data for transfer to HotpotQA
    from acv.experiments import single_claim_training_data
    from acv.verifier import AdaptiveVerifier, Calibrator, CheapScorer

    ver = AdaptiveVerifier(CheapScorer(embed_fn), Calibrator("logistic"), None, m=vc["premise_sentences"])
    items = [ver.prepare(r["id"], r["question"], r["answer"], r["passage"], meta={"unsupported": r["unsupported"]})
             for r in dev]
    X, y = single_claim_training_data(items)
    ver.calibrator.fit(X, y)
    with open(out / "calibrator.pkl", "wb") as fh:
        pickle.dump({"calibrator": ver.calibrator, "tau": res["selection"]["tau"],
                     "theta": res["selection"]["theta"]}, fh)


if __name__ == "__main__":
    main()
