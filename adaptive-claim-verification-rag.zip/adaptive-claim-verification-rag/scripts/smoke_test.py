"""End-to-end smoke test on synthetic data with toy models (no downloads, CPU only, under a minute).

  python scripts/smoke_test.py
It checks that every stage runs and writes outputs_smoke/. The numbers are meaningless.
"""

import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.data import build_sentence_corpus, split_dev_test  # noqa: E402
from acv.experiments import run_verifier_experiment  # noqa: E402
from acv.metrics import answer_metrics  # noqa: E402
from acv.pipeline import HYBRID, SINGLE, run_methods  # noqa: E402
from acv.plotting import plot_cost_f1, plot_grouped_bars, plot_reliability, setup_style  # noqa: E402
from acv.retrieval import BM25Index, DenseIndex  # noqa: E402
from acv.toy import HashingEmbedder, LexicalNLI, lexical_rerank_scores  # noqa: E402
from acv.utils import ensure_dir, load_config, write_json  # noqa: E402

PEOPLE = ["Ada Brook", "Omar Haq", "Lena Voss", "Ravi Menon", "Tara Quinn", "Ivo Petrov", "Sara Malik",
          "Jon Eriks", "Mia Torres", "Ali Raza", "Nora Field", "Ken Ito"]
CITIES = [("Lahore", "Pakistan"), ("Porto", "Portugal"), ("Kyoto", "Japan"), ("Lyon", "France"),
          ("Graz", "Austria"), ("Cork", "Ireland"), ("Pune", "India"), ("Tartu", "Estonia")]


def synthetic_hotpot(n, rng):
    ex = []
    for i in range(n):
        person = PEOPLE[i % len(PEOPLE)] + f" {i}"
        city, country = CITIES[rng.randrange(len(CITIES))]
        year = rng.randint(1900, 1999)
        p1 = [f"{person} is a writer known for short stories.", f"{person} was born in {city} in {year}.",
              f"{person} later moved abroad."]
        p2 = [f"{city} is a city in {country}.", f"{city} has an old university.", f"{city} hosts a river festival."]
        ex.append({"id": f"q{i}", "question": f"In which country is the city where {person} was born?",
                   "answer": country, "type": "bridge", "level": "easy", "titles": [person, city, "Other"],
                   "sentences": [p1, p2, ["An unrelated paragraph sentence."]],
                   "sf_titles": [person, city], "sf_sent_ids": [1, 0]})
    return ex


def synthetic_halubench(n_per_source, rng):
    rows = []
    for s, src in enumerate(["DROP", "HaluEval", "RAGTruth", "FinanceBench", "PubMedQA", "CovidQA"]):
        for j in range(n_per_source):
            person = PEOPLE[(s + j) % len(PEOPLE)]
            city, country = CITIES[rng.randrange(len(CITIES))]
            year = rng.randint(1900, 1999)
            passage = (f"{person} founded a small press. {person} was born in {city} in {year}. "
                       f"{city} is located in {country}. The press published poetry.")
            unsupported = j % 2
            if unsupported:
                wrong_city = CITIES[(CITIES.index((city, country)) + 1) % len(CITIES)][0]
                answer = rng.choice([f"{person} was born in {wrong_city} in {year}.", str(year + 7)])
            else:
                answer = rng.choice([f"{person} was born in {city} in {year}.", str(year),
                                     f"The founder's birthplace was {city}, back in {year}."])
            rows.append({"id": f"{src}-{j}", "source": src, "passage": passage,
                         "question": f"When and where was {person} born?", "answer": answer,
                         "unsupported": unsupported})
    return rows


def main():
    rng = random.Random(0)
    cfg = load_config(Path(__file__).resolve().parents[1] / "configs" / "default.yaml")
    cfg["retrieval"]["candidate_depth"] = 20
    out = ensure_dir("outputs_smoke")

    # Retrieval with toy dense/rerank backends (BM25 is the real implementation)
    examples = synthetic_hotpot(60, rng)
    _, texts, qrels = build_sentence_corpus(examples, "supporting")
    emb = HashingEmbedder()

    def dense(doc_texts, queries, depth):
        return DenseIndex(emb(doc_texts), use_torch=False).search(emb(queries), depth)

    def bm25(doc_texts, queries, depth):
        return BM25Index(0.9, 0.4).fit(doc_texts).search(queries, depth)

    backends = {"bm25": bm25, "splade": bm25, "mpnet": dense, "mpnet_qa": dense, "contriever": dense,
                "reranker": lambda: lexical_rerank_scores}
    res = run_methods(texts, [e["id"] for e in examples], [e["question"] for e in examples], qrels,
                      list(SINGLE) + list(HYBRID), cfg, backends, log=lambda s: None)
    assert set(res) == set(SINGLE) | set(HYBRID)
    print("retrieval MAP@10:", {m: round(r["eval"]["mean"]["MAP@10"], 3) for m, r in res.items()})
    print("answer metrics:", answer_metrics(["Correct", "Hallucinated", "Insufficient Context", None, "Correct"]))

    # Proposed verifier experiment with toy models
    rows = synthetic_halubench(30, rng)
    dev, test = split_dev_test(rows, 0.3, 42)
    vres = run_verifier_experiment(dev, test, emb, LexicalNLI(), cfg, log=lambda s: None)
    for k in ("B1_cheap", "B2_uniform_nli", "B3_adaptive"):
        print(k, {m: round(vres[k][m], 3) for m in ("f1", "auroc", "call_rate")})
    print("timing:", vres["timing_verification_only"])
    print("ablations:", {k: round(v["f1"], 3) for k, v in vres["ablations"].items()})
    write_json(out / "smoke_verifier.json", vres)

    font = setup_style()
    sel = vres["selection"]
    chosen = next(r for r in vres["test_sweep"] if abs(r["theta"] - sel["theta"]) < 1e-9)
    plot_cost_f1(vres["test_sweep"], chosen, {"B1 Cheap only": (0.0, vres["B1_cheap"]["f1"]),
                                              "B2 Uniform NLI": (1.0, vres["B2_uniform_nli"]["f1"])},
                 str(out / "fig_cost_f1.pdf"))
    plot_reliability({"Raw similarity": vres["calibration"]["curve_raw"],
                      "Calibrated": vres["calibration"]["curve_calibrated"]}, str(out / "fig_reliability.pdf"))
    plot_grouped_bars(["BM25", "Hybrid"], {"Reported": [0.3, 0.35], "Reproduced": [0.31, 0.36]}, "NDCG@10",
                      str(out / "fig_bars.pdf"))
    print(f"figures written with font '{font}' to {out}/")
    print("SMOKE TEST PASSED")


if __name__ == "__main__":
    main()
