"""Experiment E2 (second revision): the full HaluBench with every reviewer analysis.

  python scripts/08_halubench_v2.py --config configs/free_gpu.yaml                 # all ~14,900 answers
  python scripts/08_halubench_v2.py --config configs/free_gpu.yaml --per-source 200 # the 1,200-answer sample

What it measures (test split; every threshold, calibrator and gate is fitted on the dev split only):
  1. verifiers: DeBERTa-v3-base NLI (original), DeBERTa-v3-large NLI, MiniCheck and HHEM-2.1 on the full
     passage (chunked); each with a dev-calibrated threshold; flag-all reference; stand-alone detectors;
  2. cheap stage: original 4 features vs contradiction-sensitive features (small NLI on the best sentence,
     negation and number mismatch);
  3. escalation strategies at matched budgets: uncertainty (= confidence of the cheap model), random,
     low-support-first, disagreement between independent signals, uniform;
  4. confidently wrong cheap predictions and whether disagreement signals catch them;
  5. premise construction (top-1/2/4/8, evidence chain) and component ablations at matched budgets;
  6. why NLI rejects supported answers; error attribution per source; source-specific calibration;
  7. claim-level silver labels (open-weight LLM judge) for calibration and claim-level detection, plus a CSV
     for human annotation; LLM claim decomposition versus the rule-based extractor (and the 8-claim cap);
  8. the revised method (v2) and its comparison with uniform verification and stand-alone detectors.
Writes outputs/verifier/halubench_v2.json, outputs/verifier/v2_artifacts.pkl and claims_for_annotation.csv.
"""

import argparse
import csv
import gc
import json
import pickle
import random
import sys
import time
import traceback
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.claims import extract_claims, to_hypothesis  # noqa: E402
from acv.data import load_halubench, split_dev_test  # noqa: E402
from acv.metrics import auroc, bootstrap_ci, prf  # noqa: E402
from acv.utils import device_name, gpu_summary, load_config, set_seed, write_json  # noqa: E402
from acv.v2 import (EXT_FEATURES, FeatureCalibrator, NLIProbs, add_extended_features, apply_calibrator,  # noqa: E402
                    attribute_errors, best_threshold, budget_curve, build_premises, choose_tau_for,
                    claim_level_scores, ece, escalate_budget, ext_matrix, false_rejection_analysis, llm_decompose,
                    load_hhem, load_minicheck, macro_f1_by, make_item_from_claims, paired_bootstrap, pick_theta,
                    priorities, score_premises, single_claim_xy, theta_curve, answer_decisions, chunked_nli)
from acv.verifier import FEATURES, AdaptiveVerifier, Calibrator, CheapScorer, uncertainty  # noqa: E402

BUDGETS = [0.0, 0.03, 0.05, 0.07, 0.1, 0.15, 0.2, 0.3, 0.5, 0.75, 1.0]
THETAS = [float(x) for x in np.unique(np.round(np.r_[np.arange(0, 1.0001, 0.025), 0.99, 0.995, 0.999], 4))]
CAL_SETS = {"base4": list(FEATURES), "ext8": list(EXT_FEATURES),
            "no_small_nli": list(FEATURES) + ["neg_mismatch", "num_missing"],
            "no_neg_num": list(FEATURES) + ["small_entail", "small_contra"],
            "small_nli_only": ["small_entail", "small_contra"], "similarity_only": ["s_max"]}


def log(s):
    print(s, flush=True)


def free():
    gc.collect()
    try:
        import torch
        torch.cuda.empty_cache()
    except Exception:
        pass


def y_of(items):
    return np.asarray([int(it.meta["unsupported"]) for it in items])


def scores_with_ci(items, pred, risk):
    y = y_of(items); pred = np.asarray(pred)
    sc = prf(y, pred)
    sc["auroc"] = auroc(y, risk)
    sc["f1_ci"] = list(bootstrap_ci(lambda idx: prf(y[idx], pred[idx])["f1"], len(y), 1000, seed=42))
    sc["macro_f1_sources"] = macro_f1_by(items, pred)
    return sc


def uniform(items, v, tau):
    return answer_decisions(items, [np.ones(len(it.claims), bool) for it in items], v, tau)


def at_theta(items, v, tau, theta, strategy="uncertainty"):
    prio = priorities(items, strategy)
    esc = [p > theta for p in prio]
    pred, risk = answer_decisions(items, esc, v, tau)
    calls = sum(int(e.sum()) for e in esc)
    return pred, risk, esc, calls / max(1, sum(len(it.claims) for it in items))


def interp(curve, x, key="f1"):
    pts = sorted((r["call_rate"], r[key]) for r in curve)
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    return float(np.interp(x, xs, ys))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/free_gpu.yaml")
    ap.add_argument("--per-source", type=int, default=0, help="0 = all rows of HaluBench")
    ap.add_argument("--small-nli", default="cross-encoder/nli-MiniLM2-L6-H768")
    ap.add_argument("--large-nli", default="MoritzLaurer/DeBERTa-v3-large-mnli-fever-anli-ling-wanli")
    ap.add_argument("--minicheck", default="lytang/MiniCheck-DeBERTa-v3-Large")
    ap.add_argument("--skip", nargs="*", default=[], help="any of: large minicheck hhem judge decompose standalone")
    ap.add_argument("--label-claims-dev", type=int, default=300)
    ap.add_argument("--label-claims-test", type=int, default=600)
    ap.add_argument("--decompose-n", type=int, default=300)
    ap.add_argument("--judge-backend", default="hf")
    ap.add_argument("--max-answers", type=int, default=0, help="debugging: cap answers per split")
    args = ap.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    vc = cfg["verifier"]
    dev_name = device_name()
    out_dir = Path(cfg["paths"]["out_dir"]) / "verifier"
    out_dir.mkdir(parents=True, exist_ok=True)
    R = {"args": vars(args), "gpu": gpu_summary()}
    log(f"GPU: {R['gpu']}")
    T0 = time.time()

    rows = load_halubench(cfg["halubench"]["hf_name"], args.per_source or None, cfg["seed"],
                          data_dir=cfg["paths"]["data_dir"])
    dev, test = split_dev_test(rows, vc["dev_fraction"], cfg["seed"])
    if args.max_answers:
        dev, test = dev[:args.max_answers], test[:args.max_answers]
    R["n"] = {"dev": len(dev), "test": len(test), "test_unsupported": int(sum(r["unsupported"] for r in test)),
              "test_by_source": {s: sum(r["source"] == s for r in test) for s in sorted({r["source"] for r in test})}}
    log(f"HaluBench: dev {len(dev)}, test {len(test)} {R['n']['test_by_source']}")

    # ---- cheap stage ---------------------------------------------------------------------------
    from sentence_transformers import SentenceTransformer
    emb = SentenceTransformer(vc["embedder"], device=dev_name)
    embed_fn = lambda t: emb.encode(list(t), batch_size=256, normalize_embeddings=True,  # noqa: E731
                                    convert_to_numpy=True, show_progress_bar=False)
    ver = AdaptiveVerifier(CheapScorer(embed_fn), Calibrator("logistic"), None, m=vc["premise_sentences"])
    prep = lambda rs: [ver.prepare(r["id"], r["question"], r["answer"], r["passage"],  # noqa: E731
                                   meta={"unsupported": r["unsupported"], "source": r["source"]}) for r in rs]
    t0 = time.perf_counter()
    dev_items, test_items = prep(dev), prep(test)
    cheap_emb_s = (time.perf_counter() - t0) / max(1, len(dev_items) + len(test_items))
    small = NLIProbs(args.small_nli, batch_size=64)
    t0 = time.perf_counter()
    add_extended_features(dev_items + test_items, small)
    small_s = (time.perf_counter() - t0) / max(1, len(dev_items) + len(test_items))
    del small; free()
    R["cheap_seconds_per_answer"] = {"embedding_and_lexical": cheap_emb_s, "small_nli": small_s}
    ncl = np.asarray([len(it.claims) for it in test_items])
    ncand = np.asarray([len(extract_claims(r["answer"], max_claims=1000)) for r in test])
    R["claims"] = {"mean": float(ncl.mean()), "share_single": float((ncl == 1).mean()), "share_none": float((ncl == 0).mean()),
                   "share_over_cap_8": float((ncand > 8).mean()), "n_over_cap_8": int((ncand > 8).sum()),
                   "by_source_mean": {s: float(np.mean([len(it.claims) for it in test_items if it.meta["source"] == s]))
                                      for s in R["n"]["test_by_source"]}}
    log(f"claims: {R['claims']}  cheap s/answer: {R['cheap_seconds_per_answer']}")

    X, yc = single_claim_xy(dev_items)
    cals = {name: FeatureCalibrator(cols).fit(X, yc) for name, cols in CAL_SETS.items()}
    cals["raw_similarity"] = Calibrator("identity")
    p_by = {}
    for name, cal in cals.items():
        if name == "raw_similarity":
            for it in dev_items + test_items:
                it.p = cal.predict(it.phi) if it.claims else np.zeros(0)
        else:
            apply_calibrator(dev_items + test_items, cal)
        p_by[name] = ([it.p.copy() for it in dev_items], [it.p.copy() for it in test_items])

    def use_cal(name):
        for it, p in zip(dev_items, p_by[name][0]):
            it.p = p
        for it, p in zip(test_items, p_by[name][1]):
            it.p = p

    # claim-level quality of the cheap stage on single-claim test answers (claim label = answer label)
    Xt, yt = single_claim_xy(test_items)
    R["cheap_stage"] = {}
    for name in cals:
        use_cal(name)
        ps = np.asarray([it.p[0] for it in test_items if len(it.claims) == 1])
        pred_b1, risk_b1 = answer_decisions(test_items, [np.zeros(len(it.claims), bool) for it in test_items],
                                            [np.zeros(len(it.claims)) for it in test_items], 0.5)
        R["cheap_stage"][name] = {"single_claim_auroc": auroc(yt, ps), "single_claim_ece": ece(ps, yt),
                                  "B1": scores_with_ci(test_items, pred_b1, risk_b1)}
        log(f"[cheap {name}] AUROC(single-claim)={R['cheap_stage'][name]['single_claim_auroc']:.3f} "
            f"ECE={R['cheap_stage'][name]['single_claim_ece']:.3f} B1 F1={R['cheap_stage'][name]['B1']['f1']:.3f}")
    use_cal("base4")

    # ---- verifiers --------------------------------------------------------------------------------
    V = {}          # name -> (v_dev, v_test)
    sec_per_call = {}
    prem = {}
    for strat in ("top1", "top2", "top4", "top8", "chain"):
        prem[strat] = (build_premises(dev_items, strat), build_premises(test_items, strat))

    def run_nli(model, tag, strategies):
        nli = NLIProbs(model, batch_size=vc["nli_batch_size"] * 2)
        for st in strategies:
            v_dev = score_premises(dev_items, prem[st][0], nli)
            calls0, s0 = nli.calls, nli.seconds
            v_test = score_premises(test_items, prem[st][1], nli)
            V[f"{tag}@{st}"] = (v_dev, v_test)
            sec_per_call[f"{tag}@{st}"] = (nli.seconds - s0) / max(1, nli.calls - calls0)
            log(f"[verifier] {tag}@{st}: {sec_per_call[f'{tag}@{st}'] * 1000:.1f} ms per claim")
        del nli; free()

    run_nli(vc["nli_model"], "nli_base", ["top1", "top2", "top4", "top8", "chain"])
    if "large" not in args.skip:
        try:
            run_nli(args.large_nli, "nli_large", ["top4", "chain"])
        except Exception as e:
            log(f"[nli_large] FAILED: {e}")

    def run_chunked(tag, loader):
        try:
            sc = loader()
        except Exception as e:
            log(f"[{tag}] could not load: {e}")
            traceback.print_exc()
            return None
        full_dev = [[" ".join(it.ctx_sents)] * len(it.claims) for it in dev_items]
        full_test = [[" ".join(it.ctx_sents)] * len(it.claims) for it in test_items]
        v_dev = score_premises(dev_items, full_dev, sc)
        c0, s0 = sc.calls, sc.seconds
        v_test = score_premises(test_items, full_test, sc)
        V[f"{tag}@full"] = (v_dev, v_test)
        sec_per_call[f"{tag}@full"] = (sc.seconds - s0) / max(1, sc.calls - c0)
        log(f"[verifier] {tag}@full: {sec_per_call[f'{tag}@full'] * 1000:.1f} ms per claim")
        return sc

    standalone = {}

    def answer_level(tag, sc):
        def run(rs):
            hyps = [to_hypothesis(r["answer"], r["question"]) for r in rs]
            t0 = time.perf_counter()
            s = sc.entail_prob([r["passage"] for r in rs], hyps)
            return s, (time.perf_counter() - t0) / max(1, len(rs))
        s_dev, _ = run(dev)
        s_test, spa = run(test)
        y_dev = np.asarray([r["unsupported"] for r in dev])
        thr = best_threshold(s_dev, y_dev)
        pred = (s_test < thr).astype(int)
        res = scores_with_ci(test_items, pred, 1 - s_test)
        res.update(threshold=thr, seconds_per_answer=spa)
        standalone[tag] = {"res": res, "pred": pred}
        log(f"[standalone {tag}] F1={res['f1']:.3f} {res['f1_ci']} AUROC={res['auroc']:.3f} s/ans={spa:.3f}")

    for tag, loader in (("minicheck", lambda: load_minicheck(args.minicheck, dev_name)), ("hhem", lambda: load_hhem(dev_name))):
        if tag in args.skip:
            continue
        sc = run_chunked(tag, loader)
        if sc is not None and "standalone" not in args.skip:
            try:
                answer_level(tag, sc)
            except Exception as e:
                log(f"[standalone {tag}] FAILED: {e}")
        del sc; free()
    R["seconds_per_claim"] = sec_per_call

    # ---- per-verifier uniform and adaptive results (original cheap stage) ------------------------------
    y_test = y_of(test_items)
    R["flag_all"] = {**prf(y_test, np.ones(len(y_test), int)), "auroc": 0.5,
                     "macro_f1_sources": macro_f1_by(test_items, np.ones(len(y_test), int))}
    R["verifiers"] = {}
    taus = {}
    preds = {"flag_all": np.ones(len(y_test), int)}
    use_cal("base4")
    pred_b1, risk_b1 = answer_decisions(test_items, [np.zeros(len(it.claims), bool) for it in test_items],
                                        [np.zeros(len(it.claims)) for it in test_items], 0.5)
    preds["B1"] = np.asarray(pred_b1)
    for name, (v_dev, v_test) in V.items():
        tau = choose_tau_for(dev_items, v_dev, vc["tau_grid"] if name.startswith("nli") else
                             [round(x, 2) for x in np.arange(0.05, 0.96, 0.05)])
        taus[name] = tau
        p2, r2 = uniform(test_items, v_test, tau)
        dev_curve = theta_curve(dev_items, v_dev, tau, THETAS)
        th = pick_theta(dev_curve, vc["cost_weight"])["theta"]
        p3, r3, _, cr = at_theta(test_items, v_test, tau, th)
        R["verifiers"][name] = {"tau": tau, "theta": th, "B2": scores_with_ci(test_items, p2, r2),
                                "B3": {**scores_with_ci(test_items, p3, r3), "call_rate": cr},
                                "test_curve": theta_curve(test_items, v_test, tau, THETAS),
                                "seconds_per_claim": sec_per_call.get(name)}
        preds[f"B2:{name}"] = np.asarray(p2); preds[f"B3:{name}"] = np.asarray(p3)
        log(f"[{name}] tau={tau} B2 F1={R['verifiers'][name]['B2']['f1']:.3f} AUROC={R['verifiers'][name]['B2']['auroc']:.3f}"
            f" | B3(theta={th}) F1={R['verifiers'][name]['B3']['f1']:.3f} calls={cr:.3f}")
    R["standalone"] = {k: v["res"] for k, v in standalone.items()}
    for k, v in standalone.items():
        preds[f"standalone:{k}"] = v["pred"]

    # best verifier by dev-set F1 of uniform verification
    def dev_f1(name):
        v_dev = V[name][0]
        p, _ = uniform(dev_items, v_dev, taus[name])
        return prf(y_of(dev_items), p)["f1"]
    best = max(V, key=dev_f1)
    R["best_verifier"] = best
    log(f"best verifier on dev: {best}")

    # ---- NLI false rejections ----------------------------------------------------------------------------
    R["false_rejections"] = {}
    for name in [n for n in V if n.endswith("@top4") or n == best]:
        st = name.split("@")[1]
        ps = prem[st][1] if st in prem else [[" ".join(it.ctx_sents)] * len(it.claims) for it in test_items]
        R["false_rejections"][name] = false_rejection_analysis(test_items, V[name][1], ps, taus[name])
        log(f"[false rejections {name}] {R['false_rejections'][name]}")

    # ---- premise construction (NLI models) ---------------------------------------------------------------
    R["premise"] = {}
    for name in V:
        if not name.startswith("nli"):
            continue
        r = R["verifiers"][name]
        R["premise"][name] = {"B2_f1": r["B2"]["f1"], "B2_auroc": r["B2"]["auroc"], "B3_f1": r["B3"]["f1"],
                              "f1_at_7pct": interp(r["test_curve"], 0.07), "f1_at_30pct": interp(r["test_curve"], 0.30)}

    # ---- cheap-stage variants and escalation strategies at matched budgets --------------------------------
    R["budget_curves"] = {}
    for vname in dict.fromkeys(["nli_base@top4", best]):
        if vname not in V:
            continue
        v_test, tau = V[vname][1], taus[vname]
        for cname in ("base4", "ext8"):
            use_cal(cname)
            for strat in ("uncertainty", "random", "low_support", "disagreement"):
                seeds = (0, 1, 2, 3, 4) if strat == "random" else (0,)
                key = f"{vname}|{cname}|{strat}"
                R["budget_curves"][key] = budget_curve(test_items, v_test, tau, strat, BUDGETS, seeds,
                                                       sec_per_call.get(vname, 0.0), cheap_emb_s + (small_s if cname == "ext8" else 0))
                log(f"[budget {key}] " + " ".join(f"{r['budget']:.2f}:{r['f1']:.3f}/{r['auroc']:.3f}" for r in R["budget_curves"][key]))

    # component ablations at matched budgets (uncertainty gate, best verifier, and NLI-base premises)
    R["ablations_matched"] = {}
    for cname in ("ext8", "base4", "no_small_nli", "no_neg_num", "small_nli_only", "similarity_only", "raw_similarity"):
        use_cal(cname)
        cur = budget_curve(test_items, V[best][1], taus[best], "uncertainty", BUDGETS)
        R["ablations_matched"][f"cheap={cname}|verifier={best}"] = cur
    use_cal("base4")
    for st in ("top1", "top2", "top4", "top8", "chain"):
        name = f"nli_base@{st}"
        R["ablations_matched"][f"cheap=base4|verifier={name}"] = budget_curve(test_items, V[name][1], taus[name],
                                                                             "uncertainty", BUDGETS)
    for k, cur in R["ablations_matched"].items():
        log(f"[ablation {k}] " + " ".join(f"{r['budget']:.2f}:{r['f1']:.3f}" for r in cur))

    # ---- confidently wrong cheap predictions ------------------------------------------------------------
    R["confident_errors"] = {}
    for cname in ("base4", "ext8"):
        use_cal(cname)
        single = [it for it in test_items if len(it.claims) == 1]
        p = np.asarray([it.p[0] for it in single]); y_sup = np.asarray([1 - int(it.meta["unsupported"]) for it in single])
        ext = np.asarray([ext_matrix(it)[0] for it in single])
        conf = np.abs(2 * p - 1) >= 0.5
        wrong = (p >= 0.5).astype(int) != y_sup
        s_small = (1 + ext[:, 4] - ext[:, 5]) / 2
        dis = (np.abs(p - s_small) >= 0.5) | ((p >= 0.5) & (ext[:, 5] >= 0.5))
        R["confident_errors"][cname] = {
            "single_claim_answers": int(len(single)), "cheap_errors": int(wrong.sum()),
            "confident_errors": int((conf & wrong).sum()),
            "confident_error_share_of_errors": float((conf & wrong).sum() / max(1, wrong.sum())),
            "bypass_gate_at_theta_0.9": int((wrong & (uncertainty(p) <= 0.9)).sum()),
            "disagreement_flags_confident_errors": float(dis[conf & wrong].mean()) if (conf & wrong).any() else None,
            "disagreement_flags_confident_correct": float(dis[conf & ~wrong].mean()) if (conf & ~wrong).any() else None,
            "contradiction_flags_confident_errors": float((ext[:, 5] >= 0.5)[conf & wrong].mean()) if (conf & wrong).any() else None,
            "contradiction_flags_confident_correct": float((ext[:, 5] >= 0.5)[conf & ~wrong].mean()) if (conf & ~wrong).any() else None}
        log(f"[confident errors {cname}] {R['confident_errors'][cname]}")

    # ---- revised method v2: contradiction-aware cheap stage + disagreement gate + best verifier ------------
    use_cal("ext8")
    v_dev, v_test = V[best]
    tau = taus[best]
    dev_curve = theta_curve(dev_items, v_dev, tau, THETAS, "disagreement")
    th = pick_theta(dev_curve, vc["cost_weight"])["theta"]
    p_v2, r_v2, esc_v2, cr_v2 = at_theta(test_items, v_test, tau, th, "disagreement")
    preds["v2"] = np.asarray(p_v2)
    R["v2"] = {"verifier": best, "tau": tau, "theta": th, "calibrator": "ext8", "gate": "disagreement",
               "test": {**scores_with_ci(test_items, p_v2, r_v2), "call_rate": cr_v2},
               "test_curve": theta_curve(test_items, v_test, tau, THETAS, "disagreement"),
               "theta_by_lambda": {str(l): pick_theta(dev_curve, l)["theta"] for l in (0.0, 0.05, 0.1, 0.2, 0.3, 0.5)}}
    R["v2"]["test_at_lambda"] = {}
    for l, t in R["v2"]["theta_by_lambda"].items():
        pp, rr, _, cc = at_theta(test_items, v_test, tau, t, "disagreement")
        R["v2"]["test_at_lambda"][l] = {"theta": t, **{k: v for k, v in scores_with_ci(test_items, pp, rr).items()
                                                        if k in ("f1", "auroc", "precision", "recall")}, "call_rate": cc}
    n_claims_test = sum(len(it.claims) for it in test_items)
    R["v2"]["latency_s_per_answer"] = cheap_emb_s + small_s + cr_v2 * n_claims_test * sec_per_call.get(best, 0) / len(test_items)
    log(f"[v2] verifier={best} theta={th} F1={R['v2']['test']['f1']:.3f} AUROC={R['v2']['test']['auroc']:.3f} calls={cr_v2:.3f}")
    for l, r in R["v2"]["test_at_lambda"].items():
        log(f"    lambda={l} theta={r['theta']} F1={r['f1']:.3f} AUROC={r['auroc']:.3f} calls={r['call_rate']:.3f}")

    pb = {}
    for a, b in (("v2", f"B2:{best}"), ("v2", "flag_all"), ("v2", "B3:nli_base@top4"), (f"B2:{best}", "flag_all"),
                 (f"B2:nli_base@top4", "B3:nli_base@top4"), (f"B2:{best}", "B2:nli_base@top4")):
        if a in preds and b in preds:
            pb[f"{a} - {b}"] = paired_bootstrap(y_test, preds[a], preds[b])
    for k in standalone:
        pb[f"standalone:{k} - flag_all"] = paired_bootstrap(y_test, preds[f"standalone:{k}"], preds["flag_all"])
        pb[f"v2 - standalone:{k}"] = paired_bootstrap(y_test, preds["v2"], preds[f"standalone:{k}"])
    R["paired_bootstrap"] = pb
    for k, v in pb.items():
        log(f"[paired] {k}: {v}")

    # ---- per-source results and error attribution -----------------------------------------------------------
    R["per_source"] = {}
    for key in ("flag_all", "B1", "B3:nli_base@top4", f"B2:{best}", "v2") + tuple(f"standalone:{k}" for k in standalone):
        if key not in preds:
            continue
        R["per_source"][key] = {}
        for s in R["n"]["test_by_source"]:
            ix = [i for i, it in enumerate(test_items) if it.meta["source"] == s]
            R["per_source"][key][s] = prf(y_test[ix], preds[key][ix])
    R["errors"] = {}
    for cfg_name, cname, vname, strat, theta_used in (("B3_original", "base4", "nli_base@top4", "uncertainty",
                                                        R["verifiers"]["nli_base@top4"]["theta"]),
                                                       ("v2", "ext8", best, "disagreement", th)):
        use_cal(cname)
        v_t = V[vname][1]
        esc = [pr > theta_used for pr in priorities(test_items, strat)]
        st = vname.split("@")[1]
        ps = prem[st][1] if st in prem else [[" ".join(it.ctx_sents)] * len(it.claims) for it in test_items]
        errs = attribute_errors(test_items, esc, v_t, taus[vname], ps)
        table = {}
        for e in errs:
            table.setdefault(e["source"], {}).setdefault(e["stage"], 0)
            table[e["source"]][e["stage"]] += 1
        R["errors"][cfg_name] = {"by_source": table, "n_errors": len(errs), "examples": errs[:40]}
        log(f"[errors {cfg_name}] {table}")

    # source-specific calibration (fit on dev of that source; evaluated on unseen test answers)
    R["source_calibration"] = {}
    for cname in ("base4", "ext8"):
        use_cal(cname)
        glob_p = [it.p.copy() for it in test_items]
        for s in R["n"]["test_by_source"]:
            d_s = [it for it in dev_items if it.meta["source"] == s]
            Xs, ys = single_claim_xy(d_s)
            if len(ys) >= 30 and len(set(ys.tolist())) == 2:
                cs = FeatureCalibrator(CAL_SETS[cname]).fit(Xs, ys)
                for it in dev_items + test_items:
                    if it.meta["source"] == s and it.claims:
                        it.p = cs.predict(ext_matrix(it))
        v_dev, v_test = V[best]
        dc = theta_curve(dev_items, v_dev, taus[best], THETAS)
        t_s = pick_theta(dc, vc["cost_weight"])["theta"]
        ppp, rrr, _, ccc = at_theta(test_items, v_test, taus[best], t_s)
        R["source_calibration"][cname] = {"theta": t_s, "call_rate": ccc, **{k: v for k, v in scores_with_ci(test_items, ppp, rrr).items()}}
        use_cal(cname)
        dc = theta_curve(dev_items, v_dev, taus[best], THETAS)
        t_g = pick_theta(dc, vc["cost_weight"])["theta"]
        ppp, rrr, _, ccc = at_theta(test_items, v_test, taus[best], t_g)
        R["source_calibration"][cname + "_global"] = {"theta": t_g, "call_rate": ccc, **scores_with_ci(test_items, ppp, rrr)}
        log(f"[source calibration {cname}] per-source F1={R['source_calibration'][cname]['f1']:.3f} "
            f"macro={R['source_calibration'][cname]['macro_f1_sources']:.3f} | global F1={R['source_calibration'][cname + '_global']['f1']:.3f} "
            f"macro={R['source_calibration'][cname + '_global']['macro_f1_sources']:.3f}")
    use_cal("ext8")

    # ---- save artifacts for HotpotQA (script 10) ----------------------------------------------------------------
    with open(out_dir / "v2_artifacts.pkl", "wb") as fh:
        pickle.dump({"calibrators": {k: v for k, v in cals.items() if k != "raw_similarity"}, "taus": taus,
                     "theta_original": R["verifiers"]["nli_base@top4"]["theta"], "v2": {k: R["v2"][k] for k in ("verifier", "tau", "theta")},
                     "embedder": vc["embedder"], "small_nli": args.small_nli, "large_nli": args.large_nli,
                     "minicheck": args.minicheck}, fh)
    write_json(out_dir / "halubench_v2.json", R)
    log(f"[time] {(time.time() - T0) / 60:.1f} min before the LLM stage")

    # ---- LLM stage: claim-level silver labels and LLM claim decomposition --------------------------------------
    if "judge" not in args.skip:
        try:
            from acv.judge import make_judge
            judge = make_judge(cfg, args.judge_backend)
            rng = random.Random(cfg["seed"])

            def sample_claims(items, n):
                multi = [(it, i) for it in items if len(it.claims) > 1 for i in range(len(it.claims))]
                single = [(it, 0) for it in items if len(it.claims) == 1]
                rng.shuffle(multi); rng.shuffle(single)
                return multi[: n // 2] + single[: n - min(n // 2, len(multi))]

            lab = {}
            for split, items, n in (("dev", dev_items, args.label_claims_dev), ("test", test_items, args.label_claims_test)):
                pairs = sample_claims(items, n)
                res = judge.judge_claims([(" ".join(it.ctx_sents), it.claims[i]) for it, i in pairs])
                lab[split] = [(it, i, r["label"]) for (it, i), r in zip(pairs, res) if r["label"]]
                log(f"[claim labels] {split}: {len(lab[split])} labelled, unsupported share "
                    f"{np.mean([l == 'Unsupported' for _, _, l in lab[split]]):.3f}")
            # agreement of claim labels with answer labels for single-claim answers (sanity check of the judge)
            agree = [(int(l == "Unsupported") == int(it.meta["unsupported"])) for it, i, l in lab["test"] if len(it.claims) == 1]
            CL = {"n_dev": len(lab["dev"]), "n_test": len(lab["test"]), "judge": judge.model,
                  "judge_agreement_with_answer_label_single_claim": float(np.mean(agree)) if agree else None,
                  "unsupported_share_test": float(np.mean([l == "Unsupported" for _, _, l in lab["test"]]))}
            # calibration trained on claim-level labels vs on single-claim answer labels
            Xd = np.asarray([ext_matrix(it)[i] for it, i, _ in lab["dev"]]); yd = np.asarray([int(l == "Supported") for _, _, l in lab["dev"]])
            Xe = np.asarray([ext_matrix(it)[i] for it, i, _ in lab["test"]]); ye = np.asarray([int(l == "Supported") for _, _, l in lab["test"]])
            CL["calibration"] = {}
            for cname in ("base4", "ext8"):
                for train in ("answer_labels", "claim_labels"):
                    cal = cals[cname] if train == "answer_labels" else FeatureCalibrator(CAL_SETS[cname]).fit(Xd, yd)
                    pe = cal.predict(Xe)
                    CL["calibration"][f"{cname}|{train}"] = {"claim_auroc": auroc(ye, pe), "ece": ece(pe, ye),
                                                            **claim_level_scores(pe, 1 - ye, 0.5)}
            # claim-level detection of every verifier (threshold chosen on dev claim labels)
            CL["verifiers"] = {}
            idx_dev = {id(it): k for k, it in enumerate(dev_items)}; idx_test = {id(it): k for k, it in enumerate(test_items)}
            for name, (v_dev, v_test) in V.items():
                sd = [v_dev[idx_dev[id(it)]][i] for it, i, _ in lab["dev"]]
                se = [v_test[idx_test[id(it)]][i] for it, i, _ in lab["test"]]
                thr = best_threshold(sd, 1 - yd)
                CL["verifiers"][name] = {"threshold": thr, **claim_level_scores(se, 1 - ye, thr)}
            R["claim_level"] = CL
            log(f"[claim level] {json.dumps({k: v for k, v in CL.items() if k != 'verifiers'})[:1500]}")
            for name, r in CL["verifiers"].items():
                log(f"   claim-level {name}: F1={r['f1']:.3f} AUROC={r['auroc']:.3f}")
            # CSV for human annotation (judge label kept in a separate column the annotator should hide)
            with open(out_dir / "claims_for_annotation.csv", "w", newline="", encoding="utf-8") as fh:
                w = csv.writer(fh)
                w.writerow(["item_id", "source", "context", "claim", "your_label (Supported/Unsupported)", "judge_label_hidden"])
                for it, i, l in lab["test"][:150]:
                    w.writerow([it.uid, it.meta["source"], " ".join(it.ctx_sents)[:6000], it.claims[i], "", l])

            if "decompose" not in args.skip and args.decompose_n:
                cand = [it for it in test_items if len(it.claims) >= 2 or len(it.answer.split()) > 25]
                rng.shuffle(cand)
                sub = cand[: args.decompose_n]
                dec = llm_decompose(judge, [(it.question, it.answer) for it in sub])
                # label every LLM claim and every rule claim of the subset
                rule_pairs = [(" ".join(it.ctx_sents), c) for it in sub for c in it.claims]
                llm_pairs = [(" ".join(it.ctx_sents), c) for it, cs in zip(sub, dec) for c in cs]
                rule_lab = judge.judge_claims(rule_pairs); llm_lab = judge.judge_claims(llm_pairs)
                R["decomposition"] = {"n_answers": len(sub), "rule_claims_mean": float(np.mean([len(it.claims) for it in sub])),
                                      "llm_claims_mean": float(np.mean([len(c) for c in dec])),
                                      "llm_empty": int(sum(not c for c in dec)),
                                      "rule_unsupported_claim_share": float(np.mean([r["label"] == "Unsupported" for r in rule_lab if r["label"]])),
                                      "llm_unsupported_claim_share": float(np.mean([r["label"] == "Unsupported" for r in llm_lab if r["label"]])),
                                      "examples": [{"answer": it.answer[:600], "rule": it.claims, "llm": c} for it, c in zip(sub[:8], dec[:8])]}
                del judge; free()
                # answer-level detection on the subset with each extractor (best verifier, uniform)
                emb2 = SentenceTransformer(vc["embedder"], device=dev_name)
                sc2 = CheapScorer(lambda t: emb2.encode(list(t), batch_size=256, normalize_embeddings=True,
                                                        convert_to_numpy=True, show_progress_bar=False))
                llm_items = [make_item_from_claims(sc2, it.uid, it.question, c, it.ctx_sents, it.meta, it.answer)
                             for it, c in zip(sub, dec)]
                add_extended_features(llm_items, None)
                apply_calibrator(llm_items, cals["ext8"])
                vname = best
                if vname.startswith("minicheck"):
                    scorer = load_minicheck(args.minicheck, dev_name)
                elif vname.startswith("hhem"):
                    scorer = load_hhem(dev_name)
                else:
                    scorer = NLIProbs(args.large_nli if vname.startswith("nli_large") else vc["nli_model"])
                st = vname.split("@")[1]
                pr_llm = (build_premises(llm_items, st) if st != "full" else
                          [[" ".join(it.ctx_sents)] * len(it.claims) for it in llm_items])
                v_llm = score_premises(llm_items, pr_llm, scorer)
                idx = [idx_test[id(it)] for it in sub]
                v_rule = [V[vname][1][k] for k in idx]
                y_sub = [int(it.meta["unsupported"]) for it in sub]
                for tag, its, vv in (("rule", sub, v_rule), ("llm", llm_items, v_llm)):
                    pp, rr = uniform(its, vv, taus[vname])
                    R["decomposition"][f"{tag}_uniform_{vname}"] = {**prf(y_sub, pp), "auroc": auroc(y_sub, rr)}
                # cap analysis: unsupported answers whose only rejected claims lie beyond the 8-claim cap
                capped = [it for it in test_items if len(extract_claims(it.answer, max_claims=1000)) > 8]
                R["decomposition"]["cap"] = {"answers_over_cap": len(capped),
                                             "unsupported_over_cap": int(sum(int(it.meta["unsupported"]) for it in capped))}
                if capped:
                    full_items = [make_item_from_claims(sc2, it.uid, it.question, extract_claims(it.answer, max_claims=1000),
                                                        it.ctx_sents, it.meta, it.answer) for it in capped]
                    pr_f = (build_premises(full_items, st) if st != "full" else
                            [[" ".join(it.ctx_sents)] * len(it.claims) for it in full_items])
                    v_f = score_premises(full_items, pr_f, scorer)
                    missed = 0
                    for it, vv in zip(full_items, v_f):
                        if int(it.meta["unsupported"]) and (vv[:8] >= taus[vname]).all() and (vv[8:] < taus[vname]).any():
                            missed += 1
                    R["decomposition"]["cap"]["unsupported_caught_only_beyond_cap"] = missed
                log(f"[decomposition] {json.dumps({k: v for k, v in R['decomposition'].items() if k != 'examples'})}")
        except Exception as e:
            log(f"[LLM stage] FAILED: {e}")
            traceback.print_exc()

    R["minutes_total"] = (time.time() - T0) / 60
    write_json(out_dir / "halubench_v2.json", R)
    log(f"saved {out_dir / 'halubench_v2.json'} ({R['minutes_total']:.1f} min)")


if __name__ == "__main__":
    main()
