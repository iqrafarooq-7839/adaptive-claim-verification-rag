"""Additional experiments requested in review (HaluBench, same sample and dev/test split as step 4).

  python scripts/07_revision_experiments.py --config configs/free_gpu.yaml

Adds, on top of 04_verify_halubench.py:
  * a "flag every answer" reference baseline;
  * F1 versus NLI-call-rate curves over a fine theta grid for B3 and every ablation;
  * a paired bootstrap of F1 differences (B2 - B3 and others);
  * results split by the number of claims per answer;
  * token-length statistics (how often the NLI input or the full passage exceeds 512 tokens);
  * two detectors trained for factual consistency, MiniCheck (DeBERTa-v3-large) and Vectara HHEM-2.1-open,
    used (a) as stand-alone answer-level detectors and (b) as the verifier inside the adaptive gate,
    reading the full passage in chunks instead of a truncated premise.
Writes outputs/verifier/revision_results.json and prints every number used in the paper.
"""

import argparse
import sys
import time
import traceback
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.claims import to_hypothesis  # noqa: E402
from acv.data import load_halubench, split_dev_test  # noqa: E402
from acv.experiments import answer_scores, choose_tau, single_claim_training_data, with_ci  # noqa: E402
from acv.metrics import auroc, mcnemar_exact, prf  # noqa: E402
from acv.utils import device_name, gpu_summary, load_config, set_seed, split_sentences, write_json  # noqa: E402
from acv.verifier import (AdaptiveVerifier, Calibrator, CheapScorer, NLIVerifier, build_premise,  # noqa: E402
                          evaluate_offline)

THETA_FINE = [float(x) for x in np.unique(np.round(np.r_[np.arange(0, 1.0001, 0.025), 0.99, 0.995, 0.999], 4))]
LAMBDAS = [0.0, 0.05, 0.1, 0.2, 0.3, 0.5]


def labels(items):
    return np.asarray([int(it.meta["unsupported"]) for it in items])


def sweep(items, tau, grid=THETA_FINE):
    out = []
    for th in grid:
        sc = answer_scores(items, evaluate_offline(items, "adaptive", th, tau))
        out.append({"theta": th, "f1": sc["f1"], "precision": sc["precision"], "recall": sc["recall"],
                    "auroc": sc["auroc"], "call_rate": sc["call_rate"]})
    return out


def pick(sw, lam):
    return min(sw, key=lambda r: (1 - r["f1"]) + lam * r["call_rate"])


def paired_bootstrap(y, a, b, n_boot=2000, seed=42):
    """F1(a) - F1(b) on the same resampled answers; percentile CI and two-sided bootstrap p-value."""
    y, a, b = (np.asarray(x, dtype=int) for x in (y, a, b))
    rng = np.random.default_rng(seed)
    d = []
    for _ in range(n_boot):
        idx = rng.integers(0, len(y), len(y))
        d.append(prf(y[idx], a[idx])["f1"] - prf(y[idx], b[idx])["f1"])
    d = np.asarray(d)
    p = 2 * min((d <= 0).mean(), (d >= 0).mean())
    return {"diff": float(prf(y, a)["f1"] - prf(y, b)["f1"]), "ci": [float(np.percentile(d, 2.5)),
            float(np.percentile(d, 97.5))], "p_value": float(min(1.0, p))}


def set_v(items, vs):
    for it, v in zip(items, vs):
        it.v = None if v is None else np.asarray(v, dtype=float)


def evaluate_verifier(name, dev_items, test_items, cfg, log):
    """Same protocol as step 4 for whatever is currently in it.v: tau and theta chosen on dev only."""
    vc = cfg["verifier"]
    tau = choose_tau(dev_items, vc["tau_grid"])
    dev_sw = sweep(dev_items, tau)
    theta = pick(dev_sw, vc["cost_weight"])["theta"]
    b2 = evaluate_offline(test_items, "nli", theta, tau)
    b3 = evaluate_offline(test_items, "adaptive", theta, tau)
    res = {"tau": tau, "theta": theta,
           "B2": with_ci(test_items, b2), "B3": with_ci(test_items, b3),
           "test_sweep": sweep(test_items, tau), "dev_sweep": dev_sw,
           "theta_by_lambda": {str(l): pick(dev_sw, l)["theta"] for l in LAMBDAS},
           "pred_B2": b2["pred"], "pred_B3": b3["pred"]}
    res["test_at_lambda"] = {}
    for l, th in res["theta_by_lambda"].items():
        sc = answer_scores(test_items, evaluate_offline(test_items, "adaptive", th, tau))
        res["test_at_lambda"][l] = {"theta": th, "f1": sc["f1"], "auroc": sc["auroc"], "call_rate": sc["call_rate"]}
    log(f"[{name}] tau={tau:.2f} theta*={theta:.3f} | B2 F1={res['B2']['f1']:.3f} AUROC={res['B2']['auroc']:.3f} "
        f"| B3 F1={res['B3']['f1']:.3f} AUROC={res['B3']['auroc']:.3f} calls={res['B3']['call_rate']:.3f}")
    for l, r in res["test_at_lambda"].items():
        log(f"    lambda={l:<5} theta={r['theta']:.3f} test F1={r['f1']:.3f} AUROC={r['auroc']:.3f} calls={r['call_rate']:.3f}")
    return res


class ChunkedPairScorer:
    """Scores (document, claim) pairs with a model of limited input length: the document is split into
    sentence chunks that fit the budget together with the claim; the support score is the maximum over
    chunks (the aggregation used by MiniCheck)."""

    def __init__(self, tokenizer, score_fn, max_tokens, batch_size=16):
        self.tok, self.score_fn, self.max_tokens, self.bs = tokenizer, score_fn, max_tokens, batch_size
        self.calls = 0
        self.chunk_calls = 0

    def chunks(self, doc, claim):
        budget = max(64, self.max_tokens - len(self.tok.encode(claim, add_special_tokens=False)) - 8)
        out, cur, n = [], [], 0
        for s in split_sentences(doc) or [doc]:
            k = len(self.tok.encode(s, add_special_tokens=False))
            if cur and n + k > budget:
                out.append(" ".join(cur)); cur, n = [], 0
            cur.append(s); n += k
        if cur:
            out.append(" ".join(cur))
        return out or [""]

    def entail_prob(self, docs, claims):
        pairs, owner = [], []
        for i, (d, c) in enumerate(zip(docs, claims)):
            for ch in self.chunks(d, c):
                pairs.append((ch, c)); owner.append(i)
        scores = []
        for s in range(0, len(pairs), self.bs):
            scores.extend(self.score_fn(pairs[s:s + self.bs]))
        best = np.zeros(len(docs))
        for i, sc in zip(owner, scores):
            best[i] = max(best[i], float(sc))
        self.calls += len(docs); self.chunk_calls += len(pairs)
        return best


def load_minicheck(name, device):
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    tok = AutoTokenizer.from_pretrained(name)
    model = AutoModelForSequenceClassification.from_pretrained(name).to(device).eval()
    sup = 1  # MiniCheck classifiers: label 1 = supported
    labels_ = {i: str(l).lower() for i, l in model.config.id2label.items()}
    for i, l in labels_.items():
        if "support" in l or "entail" in l:
            sup = i

    def score(pairs):
        with torch.no_grad():
            enc = tok([p[0] for p in pairs], [p[1] for p in pairs], truncation="only_first", max_length=512,
                      padding=True, return_tensors="pt").to(device)
            return torch.softmax(model(**enc).logits.float(), -1)[:, sup].cpu().numpy().tolist()

    return ChunkedPairScorer(tok, score, 512, batch_size=16), {"labels": labels_, "support_index": sup}


def load_hhem(device):
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    model = AutoModelForSequenceClassification.from_pretrained("vectara/hallucination_evaluation_model",
                                                               trust_remote_code=True).to(device).eval()
    tok = AutoTokenizer.from_pretrained("google/flan-t5-base")

    def score(pairs):
        with torch.no_grad():
            out = model.predict(list(pairs))
        return [float(x) for x in (out.cpu().numpy() if hasattr(out, "cpu") else np.asarray(out))]

    return ChunkedPairScorer(tok, score, 1024, batch_size=4), {}


def standalone(name, scorer, dev_rows, test_rows, log):
    """Answer-level detector: one (passage, answer) pair per answer; threshold chosen on dev for F1."""
    def run(rows):
        hyps = [to_hypothesis(r["answer"], r["question"]) for r in rows]
        t0 = time.perf_counter()
        s = scorer.entail_prob([r["passage"] for r in rows], hyps)
        return s, (time.perf_counter() - t0) / max(1, len(rows))

    s_dev, _ = run(dev_rows)
    s_test, spa = run(test_rows)
    y_dev = np.asarray([r["unsupported"] for r in dev_rows]); y_test = np.asarray([r["unsupported"] for r in test_rows])
    grid = np.unique(np.r_[np.linspace(0.01, 0.99, 99), np.quantile(s_dev, np.linspace(0.01, 0.99, 99))])
    thr = max(grid, key=lambda t: prf(y_dev, (s_dev < t).astype(int))["f1"])
    pred = (s_test < thr).astype(int)
    out = {**prf(y_test, pred), "auroc": auroc(y_test, 1 - s_test), "threshold": float(thr),
           "seconds_per_answer": float(spa), "pred": pred.tolist(), "dev_auroc": auroc(y_dev, 1 - s_dev)}
    from acv.metrics import bootstrap_ci
    out["f1_ci"] = list(bootstrap_ci(lambda idx: prf(y_test[idx], pred[idx])["f1"], len(y_test), 1000, seed=42))
    log(f"[{name} answer-level] P={out['precision']:.3f} R={out['recall']:.3f} F1={out['f1']:.3f} "
        f"[{out['f1_ci'][0]:.3f}, {out['f1_ci'][1]:.3f}] AUROC={out['auroc']:.3f} thr={thr:.3f} s/ans={spa:.3f}")
    return out


def by_claim_count(items, tau, theta, log, extra=None):
    y = labels(items)
    n = np.asarray([len(it.claims) for it in items])
    groups = {"0": n == 0, "1": n == 1, "2-3": (n >= 2) & (n <= 3), "4-8": n >= 4}
    preds = {"flag_all": np.ones(len(items), int),
             "B1": np.asarray(evaluate_offline(items, "cheap", theta, tau)["pred"]),
             "B2": np.asarray(evaluate_offline(items, "nli", theta, tau)["pred"]),
             "B3": np.asarray(evaluate_offline(items, "adaptive", theta, tau)["pred"])}
    preds.update(extra or {})
    # share of supported claims-of-supported-answers that the NLI verifier rejects (claim-level false alarms)
    out = {}
    for g, mask in groups.items():
        if mask.sum() == 0:
            continue
        row = {"answers": int(mask.sum()), "unsupported_share": float(y[mask].mean())}
        for k, p in preds.items():
            p = np.asarray(p)
            sc = prf(y[mask], p[mask])
            row[k] = {"flag_rate": float(p[mask].mean()), "f1": sc["f1"], "precision": sc["precision"],
                      "recall": sc["recall"],
                      "false_alarm_rate": float(p[mask & (y == 0)].mean()) if (mask & (y == 0)).any() else None}
        sup_claims = [v for it, m in zip(items, mask) if m and int(it.meta["unsupported"]) == 0 and it.v is not None
                      for v in it.v]
        row["B2_claim_rejection_rate_in_supported_answers"] = float(np.mean(np.asarray(sup_claims) < tau)) if sup_claims else None
        out[g] = row
        log(f"  claims={g:<4} n={row['answers']:4d} unsup={row['unsupported_share']:.3f} " + " ".join(
            f"{k}:flag={row[k]['flag_rate']:.2f},FA={row[k]['false_alarm_rate'] if row[k]['false_alarm_rate'] is None else round(row[k]['false_alarm_rate'], 2)},F1={row[k]['f1']:.3f}"
            for k in preds) + f" | B2 claim-reject(supported)={row['B2_claim_rejection_rate_in_supported_answers']}")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/free_gpu.yaml")
    ap.add_argument("--minicheck", default="lytang/MiniCheck-DeBERTa-v3-Large")
    ap.add_argument("--skip-hhem", action="store_true")
    args = ap.parse_args()
    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    vc = cfg["verifier"]
    dev_name = device_name()
    log = lambda s: print(s, flush=True)  # noqa: E731
    log(f"GPU: {gpu_summary()}")

    rows = load_halubench(cfg["halubench"]["hf_name"], cfg["halubench"]["per_source"], cfg["seed"],
                          data_dir=cfg["paths"]["data_dir"])
    dev, test = split_dev_test(rows, vc["dev_fraction"], cfg["seed"])
    y_test = np.asarray([r["unsupported"] for r in test])
    log(f"HaluBench: dev {len(dev)}, test {len(test)}, unsupported share in test {y_test.mean():.3f}")
    R = {"n": {"dev": len(dev), "test": len(test), "unsupported_test": int(y_test.sum())}}

    fa = prf(y_test, np.ones(len(y_test), int))
    R["flag_all"] = {**fa, "auroc": 0.5}
    log(f"[flag-all] P={fa['precision']:.3f} R={fa['recall']:.3f} F1={fa['f1']:.3f}")

    from sentence_transformers import SentenceTransformer
    emb = SentenceTransformer(vc["embedder"], device=dev_name)
    embed_fn = lambda t: emb.encode(list(t), batch_size=128, normalize_embeddings=True,  # noqa: E731
                                    convert_to_numpy=True, show_progress_bar=False)
    nli = NLIVerifier(vc["nli_model"], batch_size=vc["nli_batch_size"])
    cal = Calibrator("logistic")
    ver = AdaptiveVerifier(CheapScorer(embed_fn), cal, nli, m=vc["premise_sentences"])
    prep = lambda rs: [ver.prepare(r["id"], r["question"], r["answer"], r["passage"],  # noqa: E731
                                   meta={"unsupported": r["unsupported"], "source": r["source"],
                                         "passage": r["passage"]}) for r in rs]
    dev_items, test_items = prep(dev), prep(test)
    X, yc = single_claim_training_data(dev_items)
    cal.fit(X, yc)
    ver.calibrate(dev_items); ver.calibrate(test_items)
    ncl = np.asarray([len(it.claims) for it in test_items])
    R["claims_per_answer"] = {"mean": float(ncl.mean()), "share_single": float((ncl == 1).mean()),
                              "share_multi": float((ncl >= 2).mean()), "share_none": float((ncl == 0).mean()),
                              "by_source_mean": {s: float(np.mean([len(it.claims) for it in test_items if it.meta["source"] == s]))
                                                 for s in sorted({it.meta["source"] for it in test_items})},
                              "calibration_examples": int(len(yc))}
    log(f"claims per test answer: {R['claims_per_answer']}")

    # ---- token lengths -------------------------------------------------------------------
    tok = nli.tok
    lens_pair, lens_doc = {}, {}
    for it in test_items:
        s = it.meta["source"]
        lens_doc.setdefault(s, []).append(len(tok.encode(it.meta["passage"])))
        for p, h in zip(it.premises, it.hypotheses):
            lens_pair.setdefault(s, []).append(len(tok.encode(p, h)))
    R["token_lengths"] = {s: {"passage_median": float(np.median(lens_doc[s])), "passage_share_over_512": float(np.mean(np.asarray(lens_doc[s]) > 512)),
                              "nli_input_median": float(np.median(lens_pair.get(s, [0]))),
                              "nli_input_share_over_512": float(np.mean(np.asarray(lens_pair.get(s, [0])) > 512))}
                          for s in sorted(lens_doc)}
    for s, v in R["token_lengths"].items():
        log(f"  tokens {s:<13} passage median={v['passage_median']:.0f} >512={v['passage_share_over_512']:.2f} | "
            f"NLI input (top-4 premise) median={v['nli_input_median']:.0f} >512={v['nli_input_share_over_512']:.3f}")

    # ---- base verifier (reproduces step 4) -----------------------------------------------------
    t0 = time.perf_counter(); ver.score_all_nli(dev_items); ver.score_all_nli(test_items)
    log(f"NLI scoring {time.perf_counter() - t0:.1f}s")
    v_base = ([it.v for it in dev_items], [it.v for it in test_items])
    base = evaluate_verifier("DeBERTa-base NLI, top-4 premise", dev_items, test_items, cfg, log)
    tau, theta = base["tau"], base["theta"]
    b1 = evaluate_offline(test_items, "cheap", theta, tau)
    R["B1"] = with_ci(test_items, b1)
    R["base"] = base
    log(f"[B1] F1={R['B1']['f1']:.3f} AUROC={R['B1']['auroc']:.3f}")

    # ---- paired bootstrap ------------------------------------------------------------------
    R["paired_bootstrap"] = {"B2_minus_B3": paired_bootstrap(y_test, base["pred_B2"], base["pred_B3"]),
                             "B3_minus_B1": paired_bootstrap(y_test, base["pred_B3"], b1["pred"]),
                             "flagall_minus_B2": paired_bootstrap(y_test, np.ones(len(y_test), int), base["pred_B2"]),
                             "mcnemar_B2_B3": mcnemar_exact(y_test, base["pred_B2"], base["pred_B3"])}
    for k, v in R["paired_bootstrap"].items():
        log(f"[paired] {k}: {v}")

    # ---- ablation curves -------------------------------------------------------------------
    curves = {"full": base["test_sweep"]}
    abl_sel = {}
    for name, calib in (("raw_similarity", Calibrator("identity")),
                        ("similarity_only", Calibrator("logistic", features=("s_max",))),
                        ("without_entity_number", Calibrator("logistic", features=("s_max", "s_top3", "lex_cov")))):
        if calib.mode == "logistic":
            calib.fit(X, yc)
        saved = [(it.p) for it in dev_items + test_items]
        for it in dev_items + test_items:
            it.p = calib.predict(it.phi) if it.claims else np.zeros(0)
        curves[name] = sweep(test_items, tau)
        th = pick(sweep(dev_items, tau), vc["cost_weight"])["theta"]
        abl_sel[name] = {"theta": th, **answer_scores(test_items, evaluate_offline(test_items, "adaptive", th, tau))}
        abl_sel[name].pop("calls", None)
        for it, p in zip(dev_items + test_items, saved):
            it.p = p
    # single-sentence premise
    for its in (dev_items, test_items):
        for it in its:
            it.meta["prem4"] = it.premises
            it.premises = [build_premise(it.ctx_sents, it.sims[i], 1) for i in range(len(it.claims))]
        ver.score_all_nli(its)
    curves["single_sentence_premise"] = sweep(test_items, tau)
    m1 = evaluate_verifier("DeBERTa-base NLI, m=1", dev_items, test_items, cfg, log)
    abl_sel["single_sentence_premise_own_selection"] = {"theta": m1["theta"], "tau": m1["tau"], "B3": m1["B3"], "B2": m1["B2"]}
    for its in (dev_items, test_items):
        for it in its:
            it.premises = it.meta.pop("prem4")
    set_v(dev_items, v_base[0]); set_v(test_items, v_base[1])
    R["ablation_curves"] = curves
    R["ablation_selected"] = abl_sel
    for k, c in curves.items():
        log(f"[curve {k}] " + " ".join(f"({r['theta']:.3f}:{r['call_rate']:.2f},{r['f1']:.3f})" for r in c))

    # ---- external detectors ------------------------------------------------------------------
    R["detectors"] = {}
    extra_preds = {}
    def minicheck_any():
        last = None
        for nm in (args.minicheck, "lytang/MiniCheck-RoBERTa-Large"):
            try:
                sc, info = load_minicheck(nm, dev_name)
                info["model"] = nm
                log(f"[MiniCheck] using {nm}")
                return sc, info
            except Exception as e:  # try the next checkpoint
                log(f"[MiniCheck] could not load {nm}: {e}")
                last = e
        raise last

    loaders = [("MiniCheck", minicheck_any)]
    if not args.skip_hhem:
        loaders.append(("HHEM-2.1", lambda: load_hhem(dev_name)))
    for name, loader in loaders:
        try:
            scorer, info = loader()
            d = {"info": info, "answer_level": standalone(name, scorer, dev, test, log)}
            extra_preds[f"{name}_answer"] = d["answer_level"]["pred"]
            # as verifier inside the adaptive gate: each claim against the full passage (chunked)
            t0 = time.perf_counter()
            for its in (dev_items, test_items):
                prem, hyp, own = [], [], []
                for k, it in enumerate(its):
                    for i in range(len(it.claims)):
                        prem.append(it.meta["passage"]); hyp.append(it.hypotheses[i]); own.append((k, i))
                v = scorer.entail_prob(prem, hyp)
                for it in its:
                    it.v = np.zeros(len(it.claims))
                for (k, i), val in zip(own, v):
                    its[k].v[i] = val
            secs = time.perf_counter() - t0
            ev = evaluate_verifier(f"{name} as verifier (full passage)", dev_items, test_items, cfg, log)
            ev["seconds_all_claims_dev_test"] = secs
            ev["chunk_calls"] = scorer.chunk_calls
            ev["claim_count"] = by_claim_count(test_items, ev["tau"], ev["theta"], log)
            d["as_verifier"] = ev
            d["paired_bootstrap"] = {"B3_minus_answer_level": paired_bootstrap(y_test, ev["pred_B3"], d["answer_level"]["pred"]),
                                     "answer_level_minus_base_B3": paired_bootstrap(y_test, d["answer_level"]["pred"], base["pred_B3"]),
                                     "B3_minus_base_B3": paired_bootstrap(y_test, ev["pred_B3"], base["pred_B3"])}
            for k, v in d["paired_bootstrap"].items():
                log(f"[paired {name}] {k}: {v}")
            R["detectors"][name] = d
            del scorer
            import torch
            torch.cuda.empty_cache()
        except Exception as e:  # keep the rest of the results
            log(f"[{name}] FAILED: {e}")
            traceback.print_exc()
            R["detectors"][name] = {"error": repr(e)}
        set_v(dev_items, v_base[0]); set_v(test_items, v_base[1])

    # ---- split by number of claims (base verifier) ---------------------------------------------
    log("[by number of claims, DeBERTa-base NLI]")
    R["by_claim_count"] = by_claim_count(test_items, tau, theta, log, extra_preds)

    for k in ("pred_B2", "pred_B3"):
        base.pop(k, None)
    for d in R["detectors"].values():
        if "as_verifier" in d:
            for k in ("pred_B2", "pred_B3"):
                d["as_verifier"].pop(k, None)
    out = Path(cfg["paths"]["out_dir"]) / "verifier" / "revision_results.json"
    write_json(out, R)
    log(f"saved {out}")


if __name__ == "__main__":
    main()
