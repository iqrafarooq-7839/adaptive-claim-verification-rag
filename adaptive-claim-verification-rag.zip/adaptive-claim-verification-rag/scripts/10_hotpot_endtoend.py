"""Experiment E3 (end to end): verify generated HotpotQA answers under sparse, dense and hybrid retrieval.

Needs the judged generations of steps 2-3 (outputs/generation/<model>__<retriever>_judged.jsonl):
  python scripts/01_retrieval.py --config configs/free_gpu.yaml --max-queries 1200 --methods bm25 contriever hybrid_li_rerank
  python scripts/02_generate.py  --config configs/free_gpu.yaml --model qwen3_4b --retrievers bm25 contriever hybrid_li_rerank
  python scripts/03_judge.py     --config configs/free_gpu.yaml --backend hf
  python scripts/10_hotpot_endtoend.py --config configs/free_gpu.yaml --artifacts outputs/verifier/v2_artifacts.pkl

For every run (generator x retriever) it reports, before and after applying the verifier:
  * answer accuracy, hallucination and refusal rates (LLM judge), and accuracy / coverage after abstaining
    on answers the verifier flags;
  * claim-level faithfulness (share of supported claims, claim-level LLM judge on a subset) before, and of the
    claims kept after removing flagged claims; recall of unsupported claims and false removal of supported ones;
  * unsupported-claim and hallucinated-answer detection (P/R/F1/AUROC) of the original method (B3), uniform
    verification (B2), the revised method (v2) and the cheap stage (B1);
  * verification cost (verifier calls and seconds per answer);
  * LLM claim decomposition versus the rule-based extractor on a subset.
Thresholds come from HaluBench (transfer, --artifacts) and, in-domain, from a dev split of the claim labels.
Writes outputs/verifier/hotpot_endtoend.json.
"""

import argparse
import gc
import json
import pickle
import random
import sys
import time
import traceback
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from acv.claims import extract_claims  # noqa: E402
from acv.metrics import auroc, prf  # noqa: E402
from acv.utils import device_name, gpu_summary, load_config, read_jsonl, set_seed, write_json  # noqa: E402
from acv.v2 import (EXT_FEATURES, FeatureCalibrator, NLIProbs, add_extended_features, answer_decisions,  # noqa: E402
                    apply_calibrator, best_threshold, build_premises, claim_level_scores, ext_matrix, llm_decompose,
                    escalate_budget, load_hhem, load_minicheck, make_item_from_claims, priorities,
                    score_premises)
from acv.verifier import FEATURES, AdaptiveVerifier, Calibrator, CheapScorer  # noqa: E402


def log(s):
    print(s, flush=True)


def free():
    gc.collect()
    try:
        import torch
        torch.cuda.empty_cache()
    except Exception:
        pass


def load_scorer(name, args, vc, dev_name):
    if name.startswith("minicheck"):
        return load_minicheck(args.minicheck, dev_name)
    if name.startswith("hhem"):
        return load_hhem(dev_name)
    return NLIProbs(args.large_nli if name.startswith("nli_large") else vc["nli_model"], batch_size=64)


def premises_for(items, name):
    st = name.split("@")[1]
    return [[" ".join(it.ctx_sents)] * len(it.claims) for it in items] if st == "full" else build_premises(items, st)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/free_gpu.yaml")
    ap.add_argument("--artifacts", default=None, help="v2_artifacts.pkl from script 08")
    ap.add_argument("--v2-verifier", default=None, help="override, e.g. hhem@full")
    ap.add_argument("--claim-judge-n", type=int, default=250, help="answers per run labelled claim by claim")
    ap.add_argument("--decompose-n", type=int, default=100)
    ap.add_argument("--small-nli", default="cross-encoder/nli-MiniLM2-L6-H768")
    ap.add_argument("--large-nli", default="MoritzLaurer/DeBERTa-v3-large-mnli-fever-anli-ling-wanli")
    ap.add_argument("--minicheck", default="lytang/MiniCheck-DeBERTa-v3-Large")
    ap.add_argument("--judge-backend", default="hf")
    ap.add_argument("--inputs", nargs="*", default=None)
    args = ap.parse_args()

    cfg = load_config(args.config)
    set_seed(cfg["seed"])
    vc = cfg["verifier"]
    dev_name = device_name()
    out_dir = Path(cfg["paths"]["out_dir"])
    files = [Path(p) for p in args.inputs] if args.inputs else sorted((out_dir / "generation").glob("*_judged.jsonl"))
    if not files:
        raise SystemExit("no *_judged.jsonl files: run scripts/02_generate.py and scripts/03_judge.py first")
    art = None
    if args.artifacts and Path(args.artifacts).exists():
        with open(args.artifacts, "rb") as fh:
            art = pickle.load(fh)
    v2_name = args.v2_verifier or (art["v2"]["verifier"] if art else "hhem@full")
    R = {"gpu": gpu_summary(), "v2_verifier": v2_name, "transfer_artifacts": bool(art), "runs": {}}
    T0 = time.time()
    rng = random.Random(cfg["seed"])

    from sentence_transformers import SentenceTransformer
    emb = SentenceTransformer(vc["embedder"], device=dev_name)
    embed_fn = lambda t: emb.encode(list(t), batch_size=256, normalize_embeddings=True,  # noqa: E731
                                    convert_to_numpy=True, show_progress_bar=False)
    ver = AdaptiveVerifier(CheapScorer(embed_fn), Calibrator("logistic"), None, m=vc["premise_sentences"])

    runs = {}
    for f in files:
        rows = [r for r in read_jsonl(f) if r.get("judge_label")]
        t0 = time.perf_counter()
        items = [ver.prepare(r["id"], r["question"], r["output"], r["contexts"],
                             meta={"label": r["judge_label"], "gold": r["gold"], "type": r.get("type"),
                                   "unsupported": int(r["judge_label"] == "Hallucinated")}) for r in rows]
        runs[f.stem.replace("_judged", "")] = {"items": items, "cheap_s": (time.perf_counter() - t0) / max(1, len(items))}
    all_items = [it for r in runs.values() for it in r["items"]]
    small = NLIProbs(args.small_nli, batch_size=64)
    t0 = time.perf_counter()
    add_extended_features(all_items, small)
    small_s = (time.perf_counter() - t0) / max(1, len(all_items))
    del small; free()

    # verifier scores for every claim: original (nli_base@top4) and v2 verifier
    names = list(dict.fromkeys(["nli_base@top4", v2_name]))
    V, secs = {}, {}
    for name in names:
        try:
            sc = load_scorer(name, args, vc, dev_name)
        except Exception as e:
            log(f"[{name}] could not load: {e}")
            continue
        for rn, r in runs.items():
            s0 = getattr(sc, "seconds", 0.0); c0 = getattr(sc, "calls", 0)
            V[(rn, name)] = score_premises(r["items"], premises_for(r["items"], name), sc)
            secs[(rn, name)] = (getattr(sc, "seconds", 0.0) - s0) / max(1, getattr(sc, "calls", 0) - c0)
        del sc; free()

    # claim-level judge labels and LLM decomposition (subset of attempted answers per run)
    labels, decomp = {}, {}
    try:
        from acv.judge import make_judge
        judge = make_judge(cfg, args.judge_backend)
        for rn, r in runs.items():
            att = [it for it in r["items"] if it.meta["label"] != "Insufficient Context" and it.claims]
            sub = rng.sample(att, min(args.claim_judge_n, len(att)))
            res = judge.judge_claims([(" ".join(it.ctx_sents), c) for it in sub for c in it.claims])
            k = 0
            for it in sub:
                it.meta["claim_labels"] = [res[k + i]["label"] for i in range(len(it.claims))]
                k += len(it.claims)
            labels[rn] = sub
            dsub = sub[: args.decompose_n]
            dec = llm_decompose(judge, [(it.question, it.answer) for it in dsub])
            lab_llm = judge.judge_claims([(" ".join(it.ctx_sents), c) for it, cs in zip(dsub, dec) for c in cs])
            k = 0
            out = []
            for it, cs in zip(dsub, dec):
                out.append((it, cs, [lab_llm[k + i]["label"] for i in range(len(cs))]))
                k += len(cs)
            decomp[rn] = out
            log(f"[labels {rn}] {sum(len(it.claims) for it in sub)} claims labelled; decomposed {len(dsub)} answers")
        del judge; free()
    except Exception as e:
        log(f"[judge stage] FAILED: {e}")
        traceback.print_exc()

    # calibrators and thresholds: HaluBench transfer and in-domain (dev split of the labelled answers)
    lab_items = [it for sub in labels.values() for it in sub]
    rng.shuffle(lab_items)
    dev_ids = {id(it) for it in lab_items[: int(0.3 * len(lab_items))]}
    Xd, yd = [], []
    for it in lab_items:
        if id(it) in dev_ids:
            for i, l in enumerate(it.meta.get("claim_labels", [])):
                if l:
                    Xd.append(ext_matrix(it)[i]); yd.append(int(l == "Supported"))
    configs = {}
    if art:
        configs["transfer"] = {"cal_orig": art["calibrators"]["base4"], "cal_v2": art["calibrators"]["ext8"],
                               "tau_orig": art["taus"]["nli_base@top4"], "theta_orig": art["theta_original"],
                               "tau_v2": art["v2"]["tau"], "theta_v2": art["v2"]["theta"]}
    if len(set(yd)) == 2 and len(yd) >= 40:
        Xd, yd = np.asarray(Xd), np.asarray(yd)
        cal_o = FeatureCalibrator(list(FEATURES)).fit(Xd, yd)
        cal_v = FeatureCalibrator(list(EXT_FEATURES)).fit(Xd, yd)
        dv = [it for it in lab_items if id(it) in dev_ids]
        thr = {}
        for name in names:
            sc, yy = [], []
            for it in dv:
                rn = next(k for k, r in runs.items() if any(x is it for x in r["items"]))
                vv = V.get((rn, name))
                if vv is None:
                    continue
                idx = next(j for j, x in enumerate(runs[rn]["items"]) if x is it)
                for i, l in enumerate(it.meta["claim_labels"]):
                    if l:
                        sc.append(vv[idx][i]); yy.append(int(l == "Unsupported"))
            thr[name] = best_threshold(sc, yy) if sc else 0.5
        configs["in_domain"] = {"cal_orig": cal_o, "cal_v2": cal_v, "tau_orig": thr.get("nli_base@top4", 0.5),
                                "theta_orig": art["theta_original"] if art else 0.9, "tau_v2": thr.get(v2_name, 0.5),
                                "theta_v2": art["v2"]["theta"] if art else 0.9}
    R["configs"] = {k: {kk: vv for kk, vv in c.items() if not kk.startswith("cal")} for k, c in configs.items()}

    for cfg_name, c in configs.items():
        for rn, r in runs.items():
            items = r["items"]
            entry = R["runs"].setdefault(rn, {})
            n = len(items)
            labs = [it.meta["label"] for it in items]
            before = {"n": n, "accuracy": labs.count("Correct") / n, "hallucination_rate": labs.count("Hallucinated") / n,
                      "refusal_rate": labs.count("Insufficient Context") / n,
                      "claims_per_answer": float(np.mean([len(it.claims) for it in items]))}
            entry["before"] = before
            res = {}
            methods = {"B1": ("orig", "cheap"), "B2": ("orig", "uniform"), "B3": ("orig", "adaptive"),
                       "B2_v2verifier": ("v2", "uniform"), "v2": ("v2", "adaptive_dis")}
            for b in (0.1, 0.3, 0.5):
                for st in ("uncertainty", "random", "disagreement"):
                    methods[f"budget{int(b * 100)}_{st}"] = ("v2", f"budget:{st}:{b}")
            for mname, (which, mode) in methods.items():
                vname = "nli_base@top4" if which == "orig" else v2_name
                if (rn, vname) not in V:
                    continue
                apply_calibrator(items, c["cal_orig"] if which == "orig" else c["cal_v2"])
                vv = V[(rn, vname)]
                tau = c["tau_orig"] if which == "orig" else c["tau_v2"]
                if mode == "cheap":
                    esc = [np.zeros(len(it.claims), bool) for it in items]
                elif mode.startswith("budget:"):
                    _, st, b = mode.split(":")
                    esc = escalate_budget(items, priorities(items, st, 0), float(b))
                elif mode == "uniform":
                    esc = [np.ones(len(it.claims), bool) for it in items]
                else:
                    strat = "uncertainty" if mode == "adaptive" else "disagreement"
                    th = c["theta_orig"] if which == "orig" else c["theta_v2"]
                    esc = [p > th for p in priorities(items, strat)]
                pred, risk = answer_decisions(items, esc, vv, tau)
                flags = [np.where(e, v < tau, it.p < 0.5) if it.claims else np.zeros(0, bool)
                         for it, e, v in zip(items, esc, vv)]
                att = [i for i, it in enumerate(items) if it.meta["label"] != "Insufficient Context" and it.claims]
                y_ans = [int(items[i].meta["label"] == "Hallucinated") for i in att]
                det = {**prf(y_ans, [pred[i] for i in att]), "auroc": auroc(y_ans, [risk[i] for i in att])}
                kept = [i for i in range(n) if not pred[i]]
                after = {"coverage": len(kept) / n,
                         "accuracy_on_answered": (sum(items[i].meta["label"] == "Correct" for i in kept) / max(1, len(kept))),
                         "hallucination_rate_on_answered": (sum(items[i].meta["label"] == "Hallucinated" for i in kept) / max(1, len(kept))),
                         "accuracy_all": sum(items[i].meta["label"] == "Correct" for i in kept) / n}
                # claim level, on the labelled subset
                ys, ps, ss, keep_sup, keep_all = [], [], [], 0, 0
                for it, fl, e, v in zip(items, flags, esc, vv):
                    for i, l in enumerate(it.meta.get("claim_labels", []) or []):
                        if not l:
                            continue
                        ys.append(int(l == "Unsupported")); ps.append(int(fl[i]))
                        ss.append(1 - (v[i] if e[i] else it.p[i]))
                        if not fl[i]:
                            keep_all += 1; keep_sup += int(l == "Supported")
                claim = None
                if ys:
                    claim = {**prf(ys, ps), "auroc": auroc(ys, ss), "n_claims": len(ys),
                             "faithfulness_before": 1 - float(np.mean(ys)),
                             "faithfulness_after": keep_sup / max(1, keep_all),
                             "unsupported_removed": float(np.mean([p for y, p in zip(ys, ps) if y])) if any(ys) else None,
                             "supported_removed": float(np.mean([p for y, p in zip(ys, ps) if not y])) if not all(ys) else None}
                calls = sum(int(e.sum()) for e in esc)
                ncl = sum(len(it.claims) for it in items)
                cost = {"call_rate": calls / max(1, ncl), "calls_per_answer": calls / n,
                        "seconds_per_answer": r["cheap_s"] + (small_s if which == "v2" else 0) +
                        calls * secs.get((rn, vname), 0) / n}
                res[mname] = {"answer_detection": det, "after": after, "claim_level": claim, "cost": cost}
                log(f"[{cfg_name} {rn} {mname}] ans F1={det['f1']:.3f} AUROC={det['auroc']:.3f} | acc answered="
                    f"{after['accuracy_on_answered']:.3f} cov={after['coverage']:.3f} | claim F1="
                    f"{(claim or {}).get('f1', float('nan')):.3f} faith {((claim or {}).get('faithfulness_before') or 0):.3f}->"
                    f"{((claim or {}).get('faithfulness_after') or 0):.3f} | calls/ans={cost['calls_per_answer']:.2f}")
            entry[cfg_name] = res

    # LLM decomposition vs rule-based extraction (claim-level faithfulness and counts)
    R["decomposition"] = {}
    for rn, rowsd in decomp.items():
        rule_lab = [l for it, _, _ in rowsd for l in it.meta.get("claim_labels", []) if l]
        llm_lab = [l for _, _, ls in rowsd for l in ls if l]
        R["decomposition"][rn] = {"answers": len(rowsd),
                                  "rule_claims_per_answer": float(np.mean([len(it.claims) for it, _, _ in rowsd])) if rowsd else 0,
                                  "llm_claims_per_answer": float(np.mean([len(cs) for _, cs, _ in rowsd])) if rowsd else 0,
                                  "rule_unsupported_share": float(np.mean([l == "Unsupported" for l in rule_lab])) if rule_lab else None,
                                  "llm_unsupported_share": float(np.mean([l == "Unsupported" for l in llm_lab])) if llm_lab else None,
                                  "rule_over_cap": int(sum(len(extract_claims(it.answer, max_claims=1000)) > 8 for it, _, _ in rowsd)),
                                  "examples": [{"answer": it.answer[:500], "rule": it.claims, "llm": cs} for it, cs, _ in rowsd[:4]]}
        log(f"[decomposition {rn}] {json.dumps({k: v for k, v in R['decomposition'][rn].items() if k != 'examples'})}")
    R["minutes"] = (time.time() - T0) / 60
    write_json(out_dir / "verifier" / "hotpot_endtoend.json", R)
    log(f"saved {out_dir / 'verifier' / 'hotpot_endtoend.json'} ({R['minutes']:.1f} min)")


if __name__ == "__main__":
    main()
